######################################################################################
###  FILE NAME      : final.tcl
###  DEPARTMENT     : Beihang University
###  AUTHOR         : Jianlei Yang
###  AUTHOR'S EMAIL : jianlei@buaa.edu.cn
######################################################################################

######################################################################################
###  Common Settings 
######################################################################################
file mkdir ./work
define_design_lib WORK -path ./work
set PROJ_ROOT ../../rtl
set TEST_RTL /lustre/S/chengshuyao/Qimeng_3_SoC/SoC/syn/soc_top_syn_2026/test_rtl/input_verilog
set GTECH_RTL /lustre/S/chengshuyao/Qimeng_3_SoC/SoC/syn/soc_top_syn_2026/test_rtl/gtech
set hdlin_while_loop_iterations 6000

######################################################################################
###  Deisign and Clock 
######################################################################################
set ACTIVE_DESIGN      "cpu_top"
set CLK_NAME       	"aclk"
set CLK_NAME_CPU       "cpu_clk"
set CLK_NAME_SOC       "soc_clk"
set CLK_NAME_SDIO      "sdio_clk"
set CLK_NAME_RMII      "rmii_ref_clk"
set CLK_NAME_25M       "clk_25m"

######################################################################################
###  PDK Libraries 
######################################################################################
# set LIB_DIR /opt/PDK/SMIC180/SCC018UG/liberty/1.8v
#set LIB_PATH "/tools/PDK/TSMCHOME/digital/Front_End/timing_power_noise/NLDM/tcbn65gplus_200a"
#set IO_PATH "/tools/PDK/TSMCHOME/digital/Front_End/timing_power_noise/NLDM/tpfn65gpgv2od3_200c"
#set SRAM_PATH "../sram/db"
#set PLL_PATH "/tools/PDK/TCI-TN65GP-GPMPLL_files1"
#set search_path [list  $PROJ_ROOT/modules/pulp-axi/include $PROJ_ROOT/modules/pulp-common_cells/include $PROJ_ROOT/modules/loongson-blocks/include $PROJ_ROOT/top $PROJ_ROOT/i2c-slave]
#
#/share/personal/S/chengshuyao/SMIC12_PDK/2026_Q2/9T_std_cell/SCC12NSFE_90SDB_9TC20_RVT_V1P0F/Liberty/0.8v/scc12nsfe_90sdb_9tc20_rvt_ssg_v0p72_-40c_ccs.db  dw_foundation.sldb /centos7/eda-tools/eda-software/SMIC12_PDK/2026_Q2/9T_std_cell/SCC12NSFE_90SDB_9TC20_LVT_V1P0F/Liberty/0.9v/scc12nsfe_90sdb_9tc20_lvt_ssg_v0p81_-40c_ccs.db
 #../SPC28NHKCPD18RNP_ss_V0p81_125C.db
#set link_library      {/centos7/eda-tools/eda-software/SMIC28_PDK/std_cell/SCC28NHKCP_HSC30P140_LVT_V0p2/liberty/0.9v/scc28nhkcp_hsc30p140_lvt_tt_v0p9_25c_basic.db}
#set target_library    {/centos7/eda-tools/eda-software/SMIC28_PDK/std_cell/SCC28NHKCP_HSC30P140_LVT_V0p2/liberty/0.9v/scc28nhkcp_hsc30p140_lvt_tt_v0p9_25c_basic.db}
#set link_library      {/nfs_global/S/chengshuyao/smic_28/SCC28NHKCP_HSC30P140_LVT_V0p2/liberty/1.0v/scc28nhkcp_hsc30p140_lvt_ff_v1p05_0c_basic.db}
#set target_library    {/nfs_global/S/chengshuyao/smic_28/SCC28NHKCP_HSC30P140_LVT_V0p2/liberty/1.0v/scc28nhkcp_hsc30p140_lvt_ff_v1p05_0c_basic.db}
#set link_library      {/centos7/eda-tools/eda-software/standard_cell/smic12/SCC12NSFE_96SDB_7P5TC24_ULVT_V1P1D/Liberty/0.9v/scc12nsfe_96sdb_7p5tc24_ulvt_ffgs_v0p99_0c_ccs.db }
#set target_library    {/centos7/eda-tools/eda-software/standard_cell/smic12/SCC12NSFE_96SDB_7P5TC24_ULVT_V1P1D/Liberty/0.9v/scc12nsfe_96sdb_7p5tc24_ulvt_ffgs_v0p99_0c_ccs.db }
#set link_library      {/share/personal/S/chengshuyao/SMIC12_PDK/2026_Q2/9T_std_cell/SCC12NSFE_90SDB_9TC20_RVT_V1P0F/Liberty/0.9v/scc12nsfe_90sdb_9tc20_rvt_tt_v0p9_25c_ccs.db }
#set target_library    {/share/personal/S/chengshuyao/SMIC12_PDK/2026_Q2/9T_std_cell/SCC12NSFE_90SDB_9TC20_RVT_V1P0F/Liberty/0.9v/scc12nsfe_90sdb_9tc20_rvt_tt_v0p9_25c_ccs.db }
#set target_library    {/centos7/eda-tools/eda-software/SMIC12_PDK/2026_Q2/9T_std_cell/SCC12NSFE_90SDB_9TC20_LVT_V1P0F/Liberty/0.8v/scc12nsfe_90sdb_9tc20_lvt_tt_v0p8_25c_ccs.db    /share/personal/S/chengshuyao/SMIC12_PDK/2026_Q2/IO/SPC12NSFED18RN_V1p1/syn/1p8v/SPC12NSFED18RN_ss_V0p72_-40C.db  /share/personal/S/chengshuyao/SMIC12_PDK/2026_Q2/PLL/PLLSM14FFLAFRACG/lib/PLLSM14FFLAFRACG_ssg_0p72v_m40c_cmax.db }
#set link_library    {/centos7/eda-tools/eda-software/SMIC12_PDK/2026_Q2/9T_std_cell/SCC12NSFE_90SDB_9TC20_LVT_V1P0F/Liberty/0.8v/scc12nsfe_90sdb_9tc20_lvt_tt_v0p8_25c_ccs.db  /share/personal/S/chengshuyao/SMIC12_PDK/2026_Q2/IO/SPC12NSFED18RN_V1p1/syn/1p8v/SPC12NSFED18RN_ss_V0p72_-40C.db  /share/personal/S/chengshuyao/SMIC12_PDK/2026_Q2/PLL/PLLSM14FFLAFRACG/lib/PLLSM14FFLAFRACG_ssg_0p72v_m40c_cmax.db }
#set target_library    {/centos7/eda-tools/eda-software/SMIC12_PDK/2026_Q2/9T_std_cell/SCC12NSFE_90SDB_9TC20_LVT_V1P0F/Liberty/0.8v/scc12nsfe_90sdb_9tc20_lvt_tt_v0p8_25c_ccs.db    /share/personal/S/chengshuyao/SMIC12_PDK/2026_Q2/IO/SPC12NSFED18RN_V1p1/syn/1p8v/SPC12NSFED18RN_ss_V0p72_-40C.db  /share/personal/S/chengshuyao/SMIC12_PDK/2026_Q2/PLL/PLLSM14FFLAFRACG/lib/PLLSM14FFLAFRACG_ssg_0p72v_m40c_cmax.db }

#Qimeng3
set link_library    	{/share/personal/S/chengshuyao/SMIC12_PDK/2026_Q2/9T_std_cell/SCC12NSFE_90SDB_9TC20_RVT_V1P0F/Liberty/0.8v/scc12nsfe_90sdb_9tc20_rvt_ssg_v0p72_-40c_ccs.db /centos7/eda-tools/eda-software/SMIC12_PDK/2026_Q2/9T_std_cell/SCC12NSFE_90SDB_9TC20_LVT_V1P0F/Liberty/0.8v/scc12nsfe_90sdb_9tc20_lvt_ssg_v0p72_-40c_ccs.db}
set target_library    	{/share/personal/S/chengshuyao/SMIC12_PDK/2026_Q2/9T_std_cell/SCC12NSFE_90SDB_9TC20_RVT_V1P0F/Liberty/0.8v/scc12nsfe_90sdb_9tc20_rvt_ssg_v0p72_-40c_ccs.db /centos7/eda-tools/eda-software/SMIC12_PDK/2026_Q2/9T_std_cell/SCC12NSFE_90SDB_9TC20_LVT_V1P0F/Liberty/0.8v/scc12nsfe_90sdb_9tc20_lvt_ssg_v0p72_-40c_ccs.db}

#set link_library    	{/centos7/eda-tools/eda-software/synopsys/tools/Synopsys2018/syn/O-2018.06-SP1/libraries/syn/gtech.db }
#set target_library    	{/centos7/eda-tools/eda-software/synopsys/tools/Synopsys2018/syn/O-2018.06-SP1/libraries/syn/gtech.db }

###set link_library    {../scc28nhkcp_hsc30p140_lvt_ssg_v0p81_-40c_basic.db   dw_foundation.sldb ../SPC28NHKCPD18RNP_ss_V0p81_125C.db  ../SPC28NHKCPD2OV3RNP_ss_V0p81_125C.db  ../PLLSM28.db  }
###set target_library  {../scc28nhkcp_hsc30p140_lvt_ssg_v0p81_-40c_basic.db                      ../SPC28NHKCPD18RNP_ss_V0p81_125C.db  ../SPC28NHKCPD2OV3RNP_ss_V0p81_125C.db  ../PLLSM28.db  }
###set link_library    {../scc28nhkcp_hsc30p140_lvt_ssg_v0p81_-40c_basic.db ../scc28nhkcp_hsc30p140_rvt_ssg_v0p81_-40c_basic.db  ../scc28nhkcp_hsc35p140_lvt_ssg_v0p81_-40c_basic.db ../scc28nhkcp_hsc35p140_rvt_ssg_v0p81_-40c_basic.db  ../scc28nhkcp_hsc35p140_hvt_ssg_v0p81_-40c_basic.db ../scc28nhkcp_hsc40p140_rvt_ssg_v0p81_-40c_basic.db ../scc28nhkcp_hsc40p140_lvt_ssg_v0p81_-40c_basic.db ../scc28nhkcp_hsc40p140_hvt_ssg_v0p81_-40c_basic.db dw_foundation.sldb SPC28NHKCPD18RNP_ss_V0p81_125C.db PLLSM28.db  }
###set target_library  {../scc28nhkcp_hsc30p140_lvt_ssg_v0p81_-40c_basic.db ../scc28nhkcp_hsc30p140_rvt_ssg_v0p81_-40c_basic.db  ../scc28nhkcp_hsc35p140_lvt_ssg_v0p81_-40c_basic.db ../scc28nhkcp_hsc35p140_rvt_ssg_v0p81_-40c_basic.db  ../scc28nhkcp_hsc35p140_hvt_ssg_v0p81_-40c_basic.db ../scc28nhkcp_hsc40p140_rvt_ssg_v0p81_-40c_basic.db ../scc28nhkcp_hsc40p140_lvt_ssg_v0p81_-40c_basic.db ../scc28nhkcp_hsc40p140_hvt_ssg_v0p81_-40c_basic.db                    SPC28NHKCPD18RNP_ss_V0p81_125C.db PLLSM28.db  }
#set link_library "  PLLSM28.db ../scc28nhkcp_hsc30p140_lvt_ssg_v0p81_-40c_basic.db ../scc28nhkcp_hsc30p140_rvt_ssg_v0p81_-40c_basic.db ../scc28nhkcp_hsc35p140_lvt_ssg_v0p81_-40c_basic.db ../scc28nhkcp_hsc35p140_rvt_ssg_v0p81_-40c_basic.db ../scc28nhkcp_hsc35p140_hvt_ssg_v0p81_-40c_basic.db ../scc28nhkcp_hsc40p140_lvt_ssg_v0p81_-40c_basic.db ../scc28nhkcp_hsc40p140_rvt_ssg_v0p81_-40c_basic.db ../scc28nhkcp_hsc40p140_hvt_ssg_v0p81_-40c_basic.db SPC28NHKCPD18RNP_ss_V0p81_125C.db SPC28NHKCPD2OV3RNP_ss_V0p81_125C.db"
#set target_library " PLLSM28.db ../scc28nhkcp_hsc30p140_lvt_ssg_v0p81_-40c_basic.db ../scc28nhkcp_hsc30p140_rvt_ssg_v0p81_-40c_basic.db ../scc28nhkcp_hsc35p140_lvt_ssg_v0p81_-40c_basic.db ../scc28nhkcp_hsc35p140_rvt_ssg_v0p81_-40c_basic.db ../scc28nhkcp_hsc35p140_hvt_ssg_v0p81_-40c_basic.db ../scc28nhkcp_hsc40p140_lvt_ssg_v0p81_-40c_basic.db ../scc28nhkcp_hsc40p140_rvt_ssg_v0p81_-40c_basic.db ../scc28nhkcp_hsc40p140_hvt_ssg_v0p81_-40c_basic.db SPC28NHKCPD18RNP_ss_V0p81_125C.db SPC28NHKCPD2OV3RNP_ss_V0p81_125C.db"
set symbol_library  {/home/eda/synopsys/icc_vI-2013.12/libraries/syn/generic.sdb}

######################################################################################
###  Local Defined
######################################################################################
set RESULTS_DIR	./results
set REPORTS_DIR	./reports
file mkdir $RESULTS_DIR
file mkdir $REPORTS_DIR

set out_netlist  "$RESULTS_DIR/$ACTIVE_DESIGN.v";
set out_db       "$RESULTS_DIR/$ACTIVE_DESIGN.db";
set out_sdf      "$RESULTS_DIR/$ACTIVE_DESIGN.sdf";
set out_sdc      "$RESULTS_DIR/$ACTIVE_DESIGN.sdc";
set out_spf      "$RESULTS_DIR/$ACTIVE_DESIGN.spf";
set out_ddc      "$RESULTS_DIR/$ACTIVE_DESIGN.ddc";
set out_svf      "$RESULTS_DIR/$ACTIVE_DESIGN.svf";

set timing_report        "$REPORTS_DIR/$ACTIVE_DESIGN\_timing.rpt"
set timing_max80_report  "$REPORTS_DIR/$ACTIVE_DESIGN\_timing_max80.rpt"
set timing_aclk_max_report "$REPORTS_DIR/$ACTIVE_DESIGN\_timing_aclk_max.rpt"
set timing_aclk_min_report "$REPORTS_DIR/$ACTIVE_DESIGN\_timing_aclk_min.rpt"
set timing_cpu_clk_max_report "$REPORTS_DIR/$ACTIVE_DESIGN\_timing_cpu_clk_max.rpt"
set timing_cpu_clk_min_report "$REPORTS_DIR/$ACTIVE_DESIGN\_timing_cpu_clk_min.rpt"
set timing_aclk_to_cpu_report "$REPORTS_DIR/$ACTIVE_DESIGN\_timing_aclk_to_cpu_clk.rpt"
set timing_cpu_to_aclk_report "$REPORTS_DIR/$ACTIVE_DESIGN\_timing_cpu_clk_to_aclk.rpt"
set area_report          "$REPORTS_DIR/$ACTIVE_DESIGN\_area.rpt"
set references_report    "$REPORTS_DIR/$ACTIVE_DESIGN\_references.rpt"
set cell_report          "$REPORTS_DIR/$ACTIVE_DESIGN\_cell.rpt"
set constraint_report    "$REPORTS_DIR/$ACTIVE_DESIGN\_constraint.rpt"
set constraint_hold_report "$REPORTS_DIR/$ACTIVE_DESIGN\_constraint_hold.rpt"
set clock_report         "$REPORTS_DIR/$ACTIVE_DESIGN\_clocks.rpt"
set qor_report           "$REPORTS_DIR/$ACTIVE_DESIGN\_qor.rpt"
set power_report         "$REPORTS_DIR/$ACTIVE_DESIGN\_power.rpt"
set check_syntax_report  "$REPORTS_DIR/$ACTIVE_DESIGN\_check_design.rpt"

define_user_attribute -type string -classes cell STOLEN_CDC
define_user_attribute -type int -classes net CDC_ASYNC

######################################################################################
###  Set Source Files
######################################################################################
#

#########
#read_verilog  ./adder.v
set search_path [concat [list ./src/include] $search_path]
set RTL_FILELIST ./filelist/rtl.f
set RTL_SRCS [list]
set fp [open $RTL_FILELIST r]
while {[gets $fp line] >= 0} {
    set line [string trim $line]
    if {$line == ""} {
        continue
    }
    if {[string match "#*" $line]} {
        continue
    }
    if {[string match "+incdir+*" $line]} {
        set incdir [string range $line 8 end]
        set search_path [concat [list ./$incdir] $search_path]
        continue
    }
    if {[string match "*.vh" $line]} {
        continue
    }
    lappend RTL_SRCS ./$line
}
close $fp
analyze -format sverilog $RTL_SRCS
###[list \
###/nfs_global/S/chengshuyao/Qimeng_3_SoC/rtl/include/sim_cfg.svh \
###/nfs_global/S/chengshuyao/Qimeng_3_SoC/rtl/dispatch/dispatch.sv \
###/nfs_global/S/chengshuyao/Qimeng_3_SoC/rtl/prf/prf.sv \
###/nfs_global/S/chengshuyao/Qimeng_3_SoC/rtl/idu/idu.sv \
###/nfs_global/S/chengshuyao/Qimeng_3_SoC/rtl/rename/rename.sv \
###/nfs_global/S/chengshuyao/Qimeng_3_SoC/rtl/rob/rob.sv \
###/nfs_global/S/chengshuyao/Qimeng_3_SoC/rtl/back_end_top/back_end_top.sv \
###/nfs_global/S/chengshuyao/Qimeng_3_SoC/rtl/csr/csr.sv \
###/nfs_global/S/chengshuyao/Qimeng_3_SoC/rtl/exu/exu.sv \
###/nfs_global/S/chengshuyao/Qimeng_3_SoC/rtl/isu/isu.sv \
###/nfs_global/S/chengshuyao/Qimeng_3_SoC/rtl/pre_idu_queue/pre_idu_queue.sv
###]
#################
######################################################################################
###  Analyze & Elaborate
######################################################################################
elaborate $ACTIVE_DESIGN 
current_design $ACTIVE_DESIGN
link 
uniquify
check_design > ./check_design.log

######################################################################################
###  Clock Setup
######################################################################################
#
#

set AXI_CLK_PERIOD 1.000
set AXI_SUBSYSTEM_FREQ_DIV 16
set CPU_CLK_PERIOD [expr {$AXI_CLK_PERIOD * $AXI_SUBSYSTEM_FREQ_DIV}]
set SOC_CLK_PERIOD 7.5
set CLK_NAME_SOC_PORT sdram_CLK

create_clock -period $AXI_CLK_PERIOD -name $CLK_NAME [get_ports $CLK_NAME]
create_clock -period $CPU_CLK_PERIOD -name $CLK_NAME_CPU [get_ports $CLK_NAME_CPU]
# aclk/cpu_clk are synchronous integer-related clocks. Do not mark them async;
# later real AXI/LLC CDC-style handshakes should add multicycle constraints
# only where the RTL explicitly holds signals on cpu_clk boundaries.
set_input_delay  0.0 -clock $CLK_NAME [remove_from_collection [all_inputs] [get_ports [list $CLK_NAME $CLK_NAME_CPU]]]
set_output_delay 0.0 -clock $CLK_NAME [all_outputs]
# 25MHz Input clock
#################create_clock -period 40 -waveform [list 0 20] -name $CLK_NAME_25M [get_ports clk_25m]
#################set_clock_latency -source 1 [get_clocks $CLK_NAME_25M]
#################set_clock_latency 1 [get_clocks $CLK_NAME_25M]
#################set_clock_uncertainty 0.6 [get_clocks $CLK_NAME_25M]
#################set_clock_transition 0.3 [get_clocks $CLK_NAME_25M]
#################set_dont_touch_network [get_clocks $CLK_NAME_25M]
#################
################## CPU runs at 300MHz
#################create_clock -period 1.00 -name $CLK_NAME_CPU [get_pins CPU_PLL/FOUT1PH0]
#################set_clock_latency -source 0 [get_clocks $CLK_NAME_CPU]
#################set_clock_latency 0 [get_clocks $CLK_NAME_CPU]
#################set_clock_uncertainty 0.2 [get_clocks $CLK_NAME_CPU]
#################set_clock_transition 0 [get_clocks $CLK_NAME_CPU]
#################set_dont_touch_network [get_clocks $CLK_NAME_CPU]
#################
#################
################## SoC runs at 133MHz
#################create_clock -period $SOC_CLK_PERIOD -name $CLK_NAME_SOC [get_pins SOC_PLL/FOUT1PH0]
#################set_clock_latency -source 1 [get_clocks $CLK_NAME_SOC]
#################set_clock_latency 1 [get_clocks $CLK_NAME_SOC]
#################set_clock_uncertainty 0.5 [get_clocks $CLK_NAME_SOC]
#################set_clock_transition 0.3 [get_clocks $CLK_NAME_SOC]
#################set_dont_touch_network [get_clocks $CLK_NAME_SOC]
#################
#################create_generated_clock -name $CLK_NAME_SOC_PORT -source [get_pins  SOC_PLL/FOUT1PH0] -master_clock $CLK_NAME_SOC -divide_by 1 [get_ports sdram_CLK]
#################
#################create_clock -period 20 -waveform [list 0 10] -name $CLK_NAME_RMII [get_ports $CLK_NAME_RMII]
#################
###################create_generated_clock -name rmii2mac_tx_clk -source [get_pins -of [get_cells -hierarchical rmii2mac_tx_clk_bi] -filter {@name =~ clocked_on}] -divide_by 2 [get_pins -of [get_cells -hierarchical rmii2mac_tx_clk_bi] -filter {@name =~ Q}] -master_clock $CLK_NAME_RMII
###################create_generated_clock -name rmii2mac_rx_clk -invert -source [get_pins -of [get_cells -hierarchical rmii2mac_rx_clk_bi] -filter {@name =~ clocked_on}] -divide_by 2 [get_pins -of [get_cells -hierarchical rmii2mac_rx_clk_bi] -filter {@name =~ Q}] -master_clock $CLK_NAME_RMII
#################
#################create_generated_clock -name $CLK_NAME_SDIO -source [get_pins soc/sdc/inst/clock_divider0/CLK] -divide_by 2 [get_pins soc/sdc/inst/clock_divider0/SD_CLK_O_reg/Q]
#################set_dont_touch_network [get_clocks $CLK_NAME_SDIO]
#################
#################set_drive 0 [list $CLK_NAME_25M $CLK_NAME_RMII]
#################
#################set i_min_delay 1.0
#################set i_max_delay 3.0
#################set o_delay 1.0
#################set tran_delay 0.3
#################set_false_path -to [get_ports {UART_* i2cm_* CDBUS_tx CDBUS_tx_en MD* gpio soc_rstn cpu_rstn cpu_grst}]
#################set_false_path -from [get_ports {UART_* i2cm_* CDBUS_rx MDIO gpio}]
#################
#################set_input_delay -min $i_min_delay -clock [get_clocks $CLK_NAME_SOC_PORT] [get_ports -filter "@port_direction == in || @port_direction == inout" {SPI_* sdram_*}]
#################set_input_delay -max $i_max_delay -clock [get_clocks $CLK_NAME_SOC_PORT] [get_ports -filter "@port_direction == in || @port_direction == inout" {SPI_* sdram_*}]
#################set_output_delay -max $o_delay -clock [get_clocks $CLK_NAME_SOC_PORT] [get_ports -filter "@port_direction == out || @port_direction == inout" {SPI_* sdram_*}]
#################set_input_delay -min $i_min_delay -clock [get_clocks $CLK_NAME_RMII] [get_ports {rmii_rxd rmii_crs_rxdv rmii_rx_err}]
#################set_input_delay -max $i_max_delay -clock [get_clocks $CLK_NAME_RMII] [get_ports {rmii_rxd rmii_crs_rxdv rmii_rx_err}]
#################set_output_delay -max $o_delay -clock [get_clocks $CLK_NAME_RMII] [get_ports {rmii_txd rmii_tx_en}]
#################
#################set_input_delay -min $i_min_delay -clock [get_clocks $CLK_NAME_25M] [get_ports {i2c_scl i2c_sda ctrl_rstn sys_rstn}]
#################set_input_delay -max $i_max_delay -clock [get_clocks $CLK_NAME_25M] [get_ports {i2c_scl i2c_sda ctrl_rstn sys_rstn}]
#################set_output_delay -max $o_delay -clock [get_clocks $CLK_NAME_25M] [get_ports {i2c_sda}]
#################
#################set_input_delay -min $i_min_delay -clock [get_clocks $CLK_NAME_SDIO] [get_ports {SD_CMD SD_DAT}]
#################set_input_delay -max $i_max_delay -clock [get_clocks $CLK_NAME_SDIO] [get_ports {SD_CMD SD_DAT}]
#################set_output_delay -max $o_delay -clock [get_clocks $CLK_NAME_SDIO] [get_ports {SD_CMD SD_DAT SD_CLK}]
#################
#################source scripts/all/cdc.tcl
#################source scripts/all/cdc_fifo.tcl
#################current_instance
#################
#################set_svf $out_svf

#set_dont_touch RISCV_mmu_human
#set_dont_touch RISCV_mmu_train

set_fix_multiple_port_nets -all -buffer_constant -feedthrough
#set_dont_use [get_lib_cells */*VO* */*V1_* */*V20* */*V24* */*V32* */*MUX2NV1* */SED* */DEL* */*LANO* */*CLK* */*PULL*]
#set_dont_use [get_lib_cells */*V0*]
#set_dont_use [get_lib_cells */*V1*]
#set_dont_use [get_lib_cells */*V20*]
#set_dont_use [get_lib_cells */*V24*]
#set_dont_use [get_lib_cells */*V32*]
#set_dont_use [get_lib_cells */*MUX2NV1*]
set_dont_use [get_lib_cells */SED*]
set_dont_use [get_lib_cells */DEL*]
set_dont_use [get_lib_cells */*LANQ*]
set_dont_use [get_lib_cells */*CLK*]
set_dont_use [get_lib_cells */*PULL*]


######################################################################################
###  Compile
######################################################################################
 compile_ultra -retime 
#compile
#-map_effort low -area_effort low 
#ungroup -flatten -all
#compile_ultra



change_names -rules verilog -hierarchy
set_svf -off

check_timing > tim_chk.log
check_design > des_chk.log
#compile -boundary_optimization -map_effort low

######################################################################################
###  Reports (Timing, Area ...)
######################################################################################
#remove_unconnected_ports [get_cells -hier {*}]
##change_names -hierarchy -rules TAN_RULE
# report_timing -delay max -max_paths 1 > $timing_report
report_clocks > $clock_report
report_qor > $qor_report
report_constraint -all_violators -max_delay -verbose > $constraint_report
report_constraint -all_violators -min_delay -verbose > $constraint_hold_report
report_timing -delay max -max_path 80 > $timing_max80_report
report_timing -delay max -group $CLK_NAME -max_path 80 > $timing_aclk_max_report
report_timing -delay min -group $CLK_NAME -max_path 80 > $timing_aclk_min_report
report_timing -delay max -group $CLK_NAME_CPU -max_path 80 > $timing_cpu_clk_max_report
report_timing -delay min -group $CLK_NAME_CPU -max_path 80 > $timing_cpu_clk_min_report
report_timing -delay max -from [get_clocks $CLK_NAME] -to [get_clocks $CLK_NAME_CPU] -max_path 80 > $timing_aclk_to_cpu_report
report_timing -delay max -from [get_clocks $CLK_NAME_CPU] -to [get_clocks $CLK_NAME] -max_path 80 > $timing_cpu_to_aclk_report
report_area > $area_report
#report_reference > $references_report
report_cell [get_cells -hier *] > $cell_report
#report_power -analysis_effort high -verbose > $power_report
#check_design > $check_syntax_report

######################################################################################
###  Write Files (Netlist Output)
######################################################################################
#change_names -rule verilog -hier
write -format verilog -hierarchy -output $out_netlist
write -format ddc -hierarchy -output $out_ddc
write_sdf -version 1.0 $out_sdf
write_sdc  $out_sdc
write_parasitics -output $out_spf


##compile
##change_names -rules verilog -hierarchy
##set_svf -off
##
##check_timing > tim_chk.log
##check_design > des_chk.log
###compile -boundary_optimization -map_effort low
##
########################################################################################
#####  Reports (Timing, Area ...)
########################################################################################
###remove_unconnected_ports [get_cells -hier {*}]
####change_names -hierarchy -rules TAN_RULE
### report_timing -delay max -max_paths 1 > $timing_report
##report_timing -delay max -max_path 80 > $timing_max80_report
##report_area > $area_report
###report_reference > $references_report
##report_cell [get_cells -hier *] > $cell_report
###report_constraint -all_violators -verbose > $constraint_report
##report_power -analysis_effort high -verbose > $power_report
###check_design > $check_syntax_report
##
########################################################################################
#####  Write Files (Netlist Output)
########################################################################################
###change_names -rule verilog -hier
##write -format verilog -hierarchy -output $out_netlist
##write -format ddc -hierarchy -output $out_ddc
##write_sdf -version 1.0 $out_sdf
##write_sdc  $out_sdc
##write_parasitics -output $out_spf
##
##
