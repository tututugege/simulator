#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
TOP="${TOP:-cpu_top}"
FPGA_KB_LLC="${FPGA_KB_LLC:-0}"

mkdir -p "${ROOT_DIR}/logs" "${ROOT_DIR}/reports" "${ROOT_DIR}/results"

rtl_files=()
while IFS= read -r raw_line; do
    line="${raw_line%%#*}"
    line="${line#"${line%%[![:space:]]*}"}"
    line="${line%"${line##*[![:space:]]}"}"
    [[ -z "${line}" ]] && continue
    [[ "${line}" == +incdir+* ]] && continue
    rtl_files+=("${ROOT_DIR}/${line}")
done < "${ROOT_DIR}/filelist/rtl.f"

log_file="${ROOT_DIR}/logs/yosys_${TOP}_fpga${FPGA_KB_LLC}.log"
netlist_file="${ROOT_DIR}/results/${TOP}_yosys_fpga${FPGA_KB_LLC}.v"
stat_file="${ROOT_DIR}/reports/${TOP}_yosys_fpga${FPGA_KB_LLC}_stat.rpt"

yosys_cmd="read_verilog -sv -I ${ROOT_DIR}/src/include ${rtl_files[*]}; "
if [[ "${FPGA_KB_LLC}" != "0" ]]; then
    yosys_cmd+="chparam -set FPGA_KB_LLC ${FPGA_KB_LLC} ${TOP}; "
fi
yosys_cmd+="hierarchy -check -top ${TOP}; synth -top ${TOP}; stat; write_verilog -noattr ${netlist_file}"

yosys -l "${log_file}" -p "${yosys_cmd}" | tee "${stat_file}"
