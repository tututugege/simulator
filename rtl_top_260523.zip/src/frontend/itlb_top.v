`timescale 1ns / 1ps
`include "axi_llc_params.vh"
`include "qm3_cpu_params.vh"

// ITLB shell.
//
// TODO:
// 1. Implement trained/generated ITLB lookup and miss control logic.
// 2. Add explicit TLB regfile/template lookup and write ports.
// 3. Implement PTW request/response handling for ITLB misses.
// 4. Implement flush and refill/writeback behavior.
//
// The lookup side is a single ICache-facing port. PTW memory/walk ports follow
// simulator PtwMemPortCombIn/Out and PtwWalkPortCombIn/Out naming.
module itlb_top #(
    parameter ADDR_BITS              = `AXI_LLC_ADDR_BITS,
    parameter DATA_BITS              = `QM3_DATA_BITS,
    parameter CSR_BITS               = `QM3_CSR_BITS,
    parameter PRIVILEGE_BITS         = `QM3_PRIVILEGE_BITS,
    parameter PTW_ACCESS_TYPE_BITS   = `QM3_PTW_ACCESS_TYPE_BITS,
    parameter PTW_LEVEL_BITS         = `QM3_PTW_LEVEL_BITS,
    parameter PTE_BITS               = `QM3_PTE_BITS,
    parameter MMU_RESULT_BITS        = `QM3_MMU_RESULT_BITS,
    parameter ITLB_ENTRIES           = `QM3_ITLB_ENTRIES
) (
    input                                   clk,
    input                                   rst_n,
    input                                   reset,
    input                                   flush,

    // CsrStatusIO context from backend CSR state.
    input      [CSR_BITS-1:0]               csr_status_sstatus,
    input      [CSR_BITS-1:0]               csr_status_mstatus,
    input      [CSR_BITS-1:0]               csr_status_satp,
    input      [PRIVILEGE_BITS-1:0]         csr_status_privilege,

    // Single lookup request from icache_top.
    input                                   icache_itlb_req_valid,
    input      [ADDR_BITS-1:0]              icache_itlb_req_vaddr,

    // Lookup response back to icache_top.
    output                                  itlb_icache_resp_valid,
    output     [ADDR_BITS-1:0]              itlb_icache_resp_paddr,
    output     [MMU_RESULT_BITS-1:0]        itlb_icache_resp_result,

    // ITLB PtwMemPortCombIn to mem_subsystem_top.
    output                                  itlb_ptw_mem_req_valid,
    output     [ADDR_BITS-1:0]              itlb_ptw_mem_req_addr,
    output                                  itlb_ptw_mem_resp_consumed,

    // ITLB PtwMemPortCombOut from mem_subsystem_top.
    input                                   itlb_ptw_mem_req_ready,
    input                                   itlb_ptw_mem_resp_valid,
    input      [DATA_BITS-1:0]              itlb_ptw_mem_resp_data,

    // ITLB PtwWalkPortCombIn to mem_subsystem_top.
    output                                  itlb_walk_req_valid,
    output     [ADDR_BITS-1:0]              itlb_walk_req_vaddr,
    output     [CSR_BITS-1:0]               itlb_walk_req_satp,
    output     [PTW_ACCESS_TYPE_BITS-1:0]   itlb_walk_req_access_type,
    output                                  itlb_walk_resp_consumed,
    output                                  itlb_walk_flush,

    // ITLB PtwWalkPortCombOut from mem_subsystem_top.
    input                                   itlb_walk_req_ready,
    input                                   itlb_walk_resp_valid,
    input                                   itlb_walk_resp_fault,
    input      [ADDR_BITS-1:0]              itlb_walk_resp_vaddr,
    input      [PTE_BITS-1:0]               itlb_walk_resp_leaf_pte,
    input      [PTW_LEVEL_BITS-1:0]         itlb_walk_resp_leaf_level
);

    assign itlb_icache_resp_valid      = 1'b0;
    assign itlb_icache_resp_paddr      = {ADDR_BITS{1'b0}};
    assign itlb_icache_resp_result     = {MMU_RESULT_BITS{1'b0}};

    assign itlb_ptw_mem_req_valid      = 1'b0;
    assign itlb_ptw_mem_req_addr       = {ADDR_BITS{1'b0}};
    assign itlb_ptw_mem_resp_consumed  = 1'b0;

    assign itlb_walk_req_valid         = 1'b0;
    assign itlb_walk_req_vaddr         = {ADDR_BITS{1'b0}};
    assign itlb_walk_req_satp          = csr_status_satp;
    assign itlb_walk_req_access_type   = {PTW_ACCESS_TYPE_BITS{1'b0}};
    assign itlb_walk_resp_consumed     = 1'b0;
    assign itlb_walk_flush             = flush;

endmodule
