`timescale 1ns / 1ps
`include "axi_llc_params.vh"
`include "qm3_cpu_params.vh"

// ICache shell.
//
// TODO:
// 1. Implement the trained/generated ICache control and refill state machine.
// 2. Add explicit ICache data/tag/meta lookup template ports.
// 3. Implement ICache-to-ITLB lookup handling.
// 4. Implement ICache-to-DCache coherent probe handling.
// 5. Implement ICache-to-LLC refill requests, responses, and mapped-window
//    address-mode bypass decisions.
//
// External names follow simulator/front-end/front_IO.h icache_in/icache_out,
// FrontTop.ICacheMemPortReq/Resp, and axi-interconnect-kit ReadMasterReq/Resp.
// The ITLB is intentionally a separate frontend submodule.
module icache_top #(
    parameter RESET_PC               = 32'h8000_0000,
    parameter FETCH_WIDTH            = `QM3_FETCH_WIDTH,
    parameter PC_BITS                = `QM3_PC_BITS,
    parameter INST_BITS              = `QM3_INST_BITS,
    parameter ADDR_BITS              = `AXI_LLC_ADDR_BITS,
    parameter DATA_BITS              = `QM3_DATA_BITS,
    parameter CSR_BITS               = `QM3_CSR_BITS,
    parameter PRIVILEGE_BITS         = `QM3_PRIVILEGE_BITS,
    parameter ID_BITS                = `AXI_LLC_ID_BITS,
    parameter MODE_BITS              = `AXI_LLC_MODE_BITS,
    parameter READ_RESP_BITS         = `AXI_LLC_READ_RESP_BITS,
    parameter MMU_RESULT_BITS        = `QM3_MMU_RESULT_BITS
) (
    input                                   aclk,
    input                                   aresetn,
    input                                   reset,

    // icache_in fields in C++ declaration order.
    input                                   refetch,
    input                                   itlb_flush,
    input                                   fence_i,
    input                                   invalidate_req,
    input                                   icache_read_valid,
    input      [PC_BITS-1:0]                fetch_address,
    input                                   icache_read_valid_2,
    input      [PC_BITS-1:0]                fetch_address_2,
    input      [CSR_BITS-1:0]               csr_status_sstatus,
    input      [CSR_BITS-1:0]               csr_status_mstatus,
    input      [CSR_BITS-1:0]               csr_status_satp,
    input      [PRIVILEGE_BITS-1:0]         csr_status_privilege,
    input                                   run_comb_only,
    input      [MODE_BITS-1:0]              mode,

    // icache_out functional fields in C++ declaration order. Perf fields are
    // intentionally omitted from this training-facing RTL boundary.
    output                                  icache_read_ready,
    output                                  icache_read_complete,
    output                                  icache_read_ready_2,
    output                                  icache_read_complete_2,
    output     [FETCH_WIDTH*INST_BITS-1:0]  fetch_group,
    output     [FETCH_WIDTH-1:0]            page_fault_inst,
    output     [FETCH_WIDTH-1:0]            inst_valid,
    output     [FETCH_WIDTH*INST_BITS-1:0]  fetch_group_2,
    output     [FETCH_WIDTH-1:0]            page_fault_inst_2,
    output     [FETCH_WIDTH-1:0]            inst_valid_2,
    output     [PC_BITS-1:0]                fetch_pc,
    output     [PC_BITS-1:0]                fetch_pc_2,

    // ICache -> ITLB single lookup port.
    output                                  icache_itlb_req_valid,
    output     [ADDR_BITS-1:0]              icache_itlb_req_vaddr,
    input                                   itlb_icache_resp_valid,
    input      [ADDR_BITS-1:0]              itlb_icache_resp_paddr,
    input      [MMU_RESULT_BITS-1:0]        itlb_icache_resp_result,

    // ReadMasterReq/Resp for ICache miss refill through mem_subsystem_top to
    // axi_subsystem_top MASTER_ICACHE.
    output                                  icache_llc_read_req_valid,
    input                                   icache_llc_read_req_ready,
    input                                   icache_llc_read_req_accepted,
    input      [ID_BITS-1:0]                icache_llc_read_req_accepted_id,
    output     [ADDR_BITS-1:0]              icache_llc_read_req_addr,
    output     [7:0]                        icache_llc_read_req_total_size,
    output     [ID_BITS-1:0]                icache_llc_read_req_id,
    output                                  icache_llc_read_req_bypass,
    input                                   icache_llc_read_resp_valid,
    output                                  icache_llc_read_resp_ready,
    input      [READ_RESP_BITS-1:0]         icache_llc_read_resp_data,
    input      [ID_BITS-1:0]                icache_llc_read_resp_id,

    // ICacheMemPortReq/Resp for coherent DCache word probe through
    // mem_subsystem_top/MemRouteBlock.
    output                                  icache_dcache_req_valid,
    output     [ADDR_BITS-1:0]              icache_dcache_req_addr,
    input                                   dcache_icache_resp_valid,
    input                                   dcache_icache_resp_miss,
    input      [DATA_BITS-1:0]              dcache_icache_resp_data
);

    // Interface-only shell. ICache-local bypass is not derived from LLC_OFF
    // mode; future logic should use the LLC mapped-window address policy.
    assign icache_read_ready          = 1'b0;
    assign icache_read_complete       = 1'b0;
    assign icache_read_ready_2        = 1'b0;
    assign icache_read_complete_2     = 1'b0;
    assign fetch_group                = {FETCH_WIDTH*INST_BITS{1'b0}};
    assign page_fault_inst            = {FETCH_WIDTH{1'b0}};
    assign inst_valid                 = {FETCH_WIDTH{1'b0}};
    assign fetch_pc                   = RESET_PC;
    assign fetch_group_2              = {FETCH_WIDTH*INST_BITS{1'b0}};
    assign page_fault_inst_2          = {FETCH_WIDTH{1'b0}};
    assign inst_valid_2               = {FETCH_WIDTH{1'b0}};
    assign fetch_pc_2                 = RESET_PC;

    assign icache_itlb_req_valid      = 1'b0;
    assign icache_itlb_req_vaddr      = {ADDR_BITS{1'b0}};

    assign icache_llc_read_req_valid  = 1'b0;
    assign icache_llc_read_req_addr   = {ADDR_BITS{1'b0}};
    assign icache_llc_read_req_total_size = 8'b0;
    assign icache_llc_read_req_id     = {ID_BITS{1'b0}};
    assign icache_llc_read_req_bypass = 1'b0;
    assign icache_llc_read_resp_ready = 1'b0;

    assign icache_dcache_req_valid    = 1'b0;
    assign icache_dcache_req_addr     = {ADDR_BITS{1'b0}};

endmodule
