`ifndef QM3_CPU_PARAMS_VH
`define QM3_CPU_PARAMS_VH

// Mirrors 3e13836/simulator/include/config.h.default.
//
// Keep this file as the single CPU-parameter source for the RTL shell. Earlier
// revisions selected default/small/medium/large by recursively including
// config/*.vh files; that made compile and synthesis flows sensitive to include
// ordering. The only supported CPU-scale profile here is the 3e13836 default.
// The FPGA-oriented small-LLC variant changes only AXI/LLC parameters and is
// selected by the cpu_top/axi_subsystem_top FPGA_KB_LLC parameter.

`ifndef QM3_CONFIG_NAME
`define QM3_CONFIG_NAME "3e13836-default"
`endif

`ifndef QM3_FETCH_WIDTH
`define QM3_FETCH_WIDTH              16
`endif
`ifndef QM3_DECODE_WIDTH
`define QM3_DECODE_WIDTH             8
`endif
`ifndef QM3_COMMIT_WIDTH
`define QM3_COMMIT_WIDTH             8
`endif

`ifndef QM3_ISSUE_WIDTH
`define QM3_ISSUE_WIDTH              24
`endif
`ifndef QM3_ALU_NUM
`define QM3_ALU_NUM                  8
`endif
`ifndef QM3_BRU_NUM
`define QM3_BRU_NUM                  4
`endif

`ifndef QM3_ROB_NUM
`define QM3_ROB_NUM                  512
`endif
`ifndef QM3_IDU_INST_BUFFER_SIZE
`define QM3_IDU_INST_BUFFER_SIZE     1024
`endif
`ifndef QM3_FTQ_SIZE
`define QM3_FTQ_SIZE                 512
`endif
`ifndef QM3_LDQ_SIZE
`define QM3_LDQ_SIZE                 512
`endif
`ifndef QM3_STQ_SIZE
`define QM3_STQ_SIZE                 512
`endif

`ifndef QM3_LSU_LDU_COUNT
`define QM3_LSU_LDU_COUNT            4
`endif
`ifndef QM3_LSU_STA_COUNT
`define QM3_LSU_STA_COUNT            4
`endif
`ifndef QM3_LSU_SDU_COUNT
`define QM3_LSU_SDU_COUNT            4
`endif
`ifndef QM3_LSU_LDU_WIDTH
`define QM3_LSU_LDU_WIDTH            2
`endif
`ifndef QM3_LOAD_WINDOWS_WIDTH
`define QM3_LOAD_WINDOWS_WIDTH       20
`endif
`ifndef QM3_STORE_WINDOWS_WIDTH
`define QM3_STORE_WINDOWS_WIDTH      20
`endif

`ifndef QM3_ITLB_ENTRIES
`define QM3_ITLB_ENTRIES             64
`endif
`ifndef QM3_DTLB_ENTRIES
`define QM3_DTLB_ENTRIES             64
`endif

`ifndef QM3_ICACHE_LINE_BYTES
`define QM3_ICACHE_LINE_BYTES        64
`endif
`ifndef QM3_ICACHE_SET_COUNT
`define QM3_ICACHE_SET_COUNT         64
`endif
`ifndef QM3_ICACHE_WAY_COUNT
`define QM3_ICACHE_WAY_COUNT         8
`endif

`ifndef QM3_DCACHE_LINE_BYTES
`define QM3_DCACHE_LINE_BYTES        64
`endif
`ifndef QM3_DCACHE_SET_COUNT
`define QM3_DCACHE_SET_COUNT         256
`endif
`ifndef QM3_DCACHE_WAY_COUNT
`define QM3_DCACHE_WAY_COUNT         4
`endif
`ifndef QM3_DCACHE_MSHR_ENTRIES
`define QM3_DCACHE_MSHR_ENTRIES      8
`endif
`ifndef QM3_DCACHE_WB_ENTRIES
`define QM3_DCACHE_WB_ENTRIES        8
`endif

`ifndef QM3_PC_BITS
`define QM3_PC_BITS                  32
`endif
`ifndef QM3_INST_BITS
`define QM3_INST_BITS                32
`endif
`ifndef QM3_DATA_BITS
`define QM3_DATA_BITS                32
`endif
`ifndef QM3_STRB_BITS
`define QM3_STRB_BITS                8
`endif

`ifndef QM3_TN_MAX
`define QM3_TN_MAX                   4
`endif
`ifndef QM3_TAGE_IDX_BITS
`define QM3_TAGE_IDX_BITS            12
`endif
`ifndef QM3_TAGE_TAG_BITS
`define QM3_TAGE_TAG_BITS            8
`endif
`ifndef QM3_PCPN_BITS
`define QM3_PCPN_BITS                3
`endif
`ifndef QM3_BR_TYPE_BITS
`define QM3_BR_TYPE_BITS             3
`endif
`ifndef QM3_BPU_SCL_META_NTABLE
`define QM3_BPU_SCL_META_NTABLE      8
`endif
`ifndef QM3_BPU_SCL_META_IDX_BITS
`define QM3_BPU_SCL_META_IDX_BITS    16
`endif
`ifndef QM3_BPU_SCL_META_SUM_BITS
`define QM3_BPU_SCL_META_SUM_BITS    16
`endif
`ifndef QM3_BPU_LOOP_META_IDX_BITS
`define QM3_BPU_LOOP_META_IDX_BITS   16
`endif
`ifndef QM3_BPU_LOOP_META_TAG_BITS
`define QM3_BPU_LOOP_META_TAG_BITS   16
`endif

`ifndef QM3_CSR_BITS
`define QM3_CSR_BITS                 32
`endif
`ifndef QM3_PRIVILEGE_BITS
`define QM3_PRIVILEGE_BITS           2
`endif

`ifndef QM3_LSU_REQ_ID_BITS
`define QM3_LSU_REQ_ID_BITS          32
`endif
`ifndef QM3_REPLAY_BITS
`define QM3_REPLAY_BITS              2
`endif
`ifndef QM3_MMU_RESULT_BITS
`define QM3_MMU_RESULT_BITS          2
`endif

`ifndef QM3_PTW_ACCESS_TYPE_BITS
`define QM3_PTW_ACCESS_TYPE_BITS     32
`endif
`ifndef QM3_PTW_LEVEL_BITS
`define QM3_PTW_LEVEL_BITS           8
`endif
`ifndef QM3_PTE_BITS
`define QM3_PTE_BITS                 32
`endif

`ifndef QM3_NUM_READ_MASTERS
`define QM3_NUM_READ_MASTERS         4
`endif
`ifndef QM3_NUM_WRITE_MASTERS
`define QM3_NUM_WRITE_MASTERS        2
`endif

`ifndef QM3_AXI_MASTER_ICACHE
`define QM3_AXI_MASTER_ICACHE        0
`endif
`ifndef QM3_AXI_MASTER_DCACHE_R
`define QM3_AXI_MASTER_DCACHE_R      1
`endif
`ifndef QM3_AXI_MASTER_UNCORE_LSU_R
`define QM3_AXI_MASTER_UNCORE_LSU_R  2
`endif
`ifndef QM3_AXI_MASTER_EXTRA_R
`define QM3_AXI_MASTER_EXTRA_R       3
`endif
`ifndef QM3_AXI_MASTER_DCACHE_W
`define QM3_AXI_MASTER_DCACHE_W      0
`endif
`ifndef QM3_AXI_MASTER_UNCORE_LSU_W
`define QM3_AXI_MASTER_UNCORE_LSU_W  1
`endif

`endif
