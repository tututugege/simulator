`timescale 1ns / 1ps
`include "axi_llc_params.vh"
`include "qm3_cpu_params.vh"

// Front-end shell.
//
// TODO:
// 1. Keep this wrapper as glue while replacing frontend_core_top, icache_top,
//    and itlb_top with real or generated RTL.
// 2. Add table/template interfaces below child tops rather than widening this
//    top-level frontend boundary.
//
// Interface names follow simulator/front-end/front_IO.h as closely as a flat
// RTL boundary allows. The ITLB is expected to live inside this module; only
// PTW memory/walk requests and refills leave this boundary.
module frontend_top #(
    parameter USE_TRAIN              = 0,
    parameter RESET_PC               = 32'h8000_0000,
    parameter FETCH_WIDTH            = `QM3_FETCH_WIDTH,
    parameter COMMIT_WIDTH           = `QM3_COMMIT_WIDTH,
    parameter ICACHE_LINE_BYTES      = `QM3_ICACHE_LINE_BYTES,
    parameter ICACHE_SET_COUNT       = `QM3_ICACHE_SET_COUNT,
    parameter ICACHE_WAY_COUNT       = `QM3_ICACHE_WAY_COUNT,
    parameter ITLB_ENTRIES           = `QM3_ITLB_ENTRIES,
    parameter TN_MAX                 = `QM3_TN_MAX,
    parameter PC_BITS                = `QM3_PC_BITS,
    parameter INST_BITS              = `QM3_INST_BITS,
    parameter ADDR_BITS              = `AXI_LLC_ADDR_BITS,
    parameter DATA_BITS              = `QM3_DATA_BITS,
    parameter CSR_BITS               = `QM3_CSR_BITS,
    parameter PRIVILEGE_BITS         = `QM3_PRIVILEGE_BITS,
    parameter ID_BITS                = `AXI_LLC_ID_BITS,
    parameter MODE_BITS              = `AXI_LLC_MODE_BITS,
    parameter READ_RESP_BITS         = `AXI_LLC_READ_RESP_BITS,
    parameter PCPN_BITS              = `QM3_PCPN_BITS,
    parameter BR_TYPE_BITS           = `QM3_BR_TYPE_BITS,
    parameter TAGE_IDX_BITS          = `QM3_TAGE_IDX_BITS,
    parameter TAGE_TAG_BITS          = `QM3_TAGE_TAG_BITS,
    parameter BPU_SCL_META_NTABLE    = `QM3_BPU_SCL_META_NTABLE,
    parameter BPU_SCL_META_IDX_BITS  = `QM3_BPU_SCL_META_IDX_BITS,
    parameter BPU_SCL_META_SUM_BITS  = `QM3_BPU_SCL_META_SUM_BITS,
    parameter BPU_LOOP_META_IDX_BITS = `QM3_BPU_LOOP_META_IDX_BITS,
    parameter BPU_LOOP_META_TAG_BITS = `QM3_BPU_LOOP_META_TAG_BITS,
    parameter PTW_ACCESS_TYPE_BITS   = `QM3_PTW_ACCESS_TYPE_BITS,
    parameter PTW_LEVEL_BITS         = `QM3_PTW_LEVEL_BITS,
    parameter PTE_BITS               = `QM3_PTE_BITS,
    parameter MMU_RESULT_BITS        = `QM3_MMU_RESULT_BITS
) (
    input                                   aclk,
    input                                   aresetn,

    // front_top_in.reset/global control from cpu_top.
    input                                   reset,
    // LLC/cache mode from cpu_top. LLC_OFF is handled inside the AXI/LLC
    // subsystem; future ICache-local bypass should follow LLC mapped-window
    // address-mode policy, not LLC_OFF.
    input      [MODE_BITS-1:0]              mode,

    // front_top_in branch redirect/control from backend_top.Back_out.
    input                                   refetch,
    input                                   itlb_flush,
    input                                   fence_i,
    input      [PC_BITS-1:0]                refetch_address,

    // front_top_in.CsrStatusIO from backend_top CSR state.
    input      [CSR_BITS-1:0]               csr_status_sstatus,
    input      [CSR_BITS-1:0]               csr_status_mstatus,
    input      [CSR_BITS-1:0]               csr_status_satp,
    input      [PRIVILEGE_BITS-1:0]         csr_status_privilege,

    // front_top_in FIFO_read_enable from backend consume/redirect decision.
    input                                   FIFO_read_enable,

    // front_top_in back2front_* branch-training metadata from backend commits.
    input      [COMMIT_WIDTH-1:0]           back2front_valid,
    input      [COMMIT_WIDTH*PC_BITS-1:0]   predict_base_pc,
    input      [COMMIT_WIDTH-1:0]           predict_dir,
    input      [COMMIT_WIDTH-1:0]           actual_dir,
    input      [COMMIT_WIDTH*BR_TYPE_BITS-1:0] actual_br_type,
    input      [COMMIT_WIDTH*PC_BITS-1:0]   actual_target,
    input      [COMMIT_WIDTH-1:0]           alt_pred,
    input      [COMMIT_WIDTH*PCPN_BITS-1:0] altpcpn,
    input      [COMMIT_WIDTH*PCPN_BITS-1:0] pcpn,
    input      [COMMIT_WIDTH*TN_MAX*TAGE_IDX_BITS-1:0] tage_idx,
    input      [COMMIT_WIDTH*TN_MAX*TAGE_TAG_BITS-1:0] tage_tag,
    input      [COMMIT_WIDTH-1:0]           sc_used,
    input      [COMMIT_WIDTH-1:0]           sc_pred,
    input      [COMMIT_WIDTH*BPU_SCL_META_SUM_BITS-1:0] sc_sum,
    input      [COMMIT_WIDTH*BPU_SCL_META_NTABLE*BPU_SCL_META_IDX_BITS-1:0] sc_idx,
    input      [COMMIT_WIDTH-1:0]           loop_used,
    input      [COMMIT_WIDTH-1:0]           loop_hit,
    input      [COMMIT_WIDTH-1:0]           loop_pred,
    input      [COMMIT_WIDTH*BPU_LOOP_META_IDX_BITS-1:0] loop_idx,
    input      [COMMIT_WIDTH*BPU_LOOP_META_TAG_BITS-1:0] loop_tag,

    // front_top_out FrontPreIO to backend_top.Back_in.
    output                                  FIFO_valid,
    output                                  commit_stall,
    output     [FETCH_WIDTH*PC_BITS-1:0]    pc,
    output     [FETCH_WIDTH*INST_BITS-1:0]  instructions,
    output     [FETCH_WIDTH-1:0]            inst_valid,
    output     [FETCH_WIDTH-1:0]            out_predict_dir,
    output     [PC_BITS-1:0]                predict_next_fetch_address,
    output     [FETCH_WIDTH-1:0]            out_alt_pred,
    output     [FETCH_WIDTH*PCPN_BITS-1:0]  out_altpcpn,
    output     [FETCH_WIDTH*PCPN_BITS-1:0]  out_pcpn,
    output     [FETCH_WIDTH-1:0]            page_fault_inst,
    output     [FETCH_WIDTH*TN_MAX*TAGE_IDX_BITS-1:0] out_tage_idx,
    output     [FETCH_WIDTH*TN_MAX*TAGE_TAG_BITS-1:0] out_tage_tag,
    output     [FETCH_WIDTH-1:0]            out_sc_used,
    output     [FETCH_WIDTH-1:0]            out_sc_pred,
    output     [FETCH_WIDTH*BPU_SCL_META_SUM_BITS-1:0] out_sc_sum,
    output     [FETCH_WIDTH*BPU_SCL_META_NTABLE*BPU_SCL_META_IDX_BITS-1:0] out_sc_idx,
    output     [FETCH_WIDTH-1:0]            out_loop_used,
    output     [FETCH_WIDTH-1:0]            out_loop_hit,
    output     [FETCH_WIDTH-1:0]            out_loop_pred,
    output     [FETCH_WIDTH*BPU_LOOP_META_IDX_BITS-1:0] out_loop_idx,
    output     [FETCH_WIDTH*BPU_LOOP_META_TAG_BITS-1:0] out_loop_tag,

    // ReadMasterReq/Resp for ICache miss refill through mem_subsystem_top to
    // axi_subsystem_top MASTER_ICACHE.
    output                                  icache_llc_read_req_valid,
    input                                   icache_llc_read_req_ready,
    input                                   icache_llc_read_req_accepted,
    input      [ID_BITS-1:0]                icache_llc_read_req_accepted_id,
    output     [ADDR_BITS-1:0]              icache_llc_read_req_addr,
    output     [7:0]                        icache_llc_read_req_total_size,
    output     [ID_BITS-1:0]                icache_llc_read_req_id,
    output                                  icache_llc_read_req_bypass,
    input                                   icache_llc_read_resp_valid,
    output                                  icache_llc_read_resp_ready,
    input      [READ_RESP_BITS-1:0]         icache_llc_read_resp_data,
    input      [ID_BITS-1:0]                icache_llc_read_resp_id,

    // ICacheMemPortReq to mem_subsystem_top/MemRouteBlock. This is the
    // ICache -> DCache coherent word probe generated on an ICache miss.
    output                                  icache_dcache_req_valid,
    output     [ADDR_BITS-1:0]              icache_dcache_req_addr,

    // ICacheMemPortResp from mem_subsystem_top/MemRouteBlock. This returns
    // the DCache probe result back to the ICache.
    input                                   dcache_icache_resp_valid,
    input                                   dcache_icache_resp_miss,
    input      [DATA_BITS-1:0]              dcache_icache_resp_data,

    // ITLB PtwMemPortCombIn to mem_subsystem_top.MemPtwBlock.
    output                                  itlb_ptw_mem_req_valid,
    output     [ADDR_BITS-1:0]              itlb_ptw_mem_req_addr,
    output                                  itlb_ptw_mem_resp_consumed,

    // ITLB PtwMemPortCombOut from mem_subsystem_top.MemPtwBlock.
    input                                   itlb_ptw_mem_req_ready,
    input                                   itlb_ptw_mem_resp_valid,
    input      [DATA_BITS-1:0]              itlb_ptw_mem_resp_data,

    // ITLB PtwWalkPortCombIn to mem_subsystem_top.MemPtwBlock.
    output                                  itlb_walk_req_valid,
    output     [ADDR_BITS-1:0]              itlb_walk_req_vaddr,
    output     [CSR_BITS-1:0]               itlb_walk_req_satp,
    output     [PTW_ACCESS_TYPE_BITS-1:0]   itlb_walk_req_access_type,
    output                                  itlb_walk_resp_consumed,
    output                                  itlb_walk_flush,

    // ITLB PtwWalkPortCombOut from mem_subsystem_top.MemPtwBlock.
    input                                   itlb_walk_req_ready,
    input                                   itlb_walk_resp_valid,
    input                                   itlb_walk_resp_fault,
    input      [ADDR_BITS-1:0]              itlb_walk_resp_vaddr,
    input      [PTE_BITS-1:0]               itlb_walk_resp_leaf_pte,
    input      [PTW_LEVEL_BITS-1:0]         itlb_walk_resp_leaf_level
);

    wire                                  icache_read_valid;
    wire [PC_BITS-1:0]                    fetch_address;
    wire                                  icache_read_valid_2;
    wire [PC_BITS-1:0]                    fetch_address_2;
    wire                                  icache_invalidate_req;
    wire                                  icache_run_comb_only;
    wire                                  icache_read_ready;
    wire                                  icache_read_complete;
    wire                                  icache_read_ready_2;
    wire                                  icache_read_complete_2;
    wire [FETCH_WIDTH*INST_BITS-1:0]      icache_fetch_group;
    wire [FETCH_WIDTH-1:0]                icache_page_fault_inst;
    wire [FETCH_WIDTH-1:0]                icache_inst_valid;
    wire [PC_BITS-1:0]                    icache_fetch_pc;
    wire [FETCH_WIDTH*INST_BITS-1:0]      icache_fetch_group_2;
    wire [FETCH_WIDTH-1:0]                icache_page_fault_inst_2;
    wire [FETCH_WIDTH-1:0]                icache_inst_valid_2;
    wire [PC_BITS-1:0]                    icache_fetch_pc_2;

    wire                                  icache_itlb_req_valid;
    wire [ADDR_BITS-1:0]                  icache_itlb_req_vaddr;
    wire                                  itlb_icache_resp_valid;
    wire [ADDR_BITS-1:0]                  itlb_icache_resp_paddr;
    wire [MMU_RESULT_BITS-1:0]            itlb_icache_resp_result;

    frontend_core_top #(
        .USE_TRAIN(USE_TRAIN),
        .RESET_PC(RESET_PC),
        .FETCH_WIDTH(FETCH_WIDTH),
        .COMMIT_WIDTH(COMMIT_WIDTH),
        .TN_MAX(TN_MAX),
        .PC_BITS(PC_BITS),
        .INST_BITS(INST_BITS),
        .CSR_BITS(CSR_BITS),
        .PRIVILEGE_BITS(PRIVILEGE_BITS),
        .PCPN_BITS(PCPN_BITS),
        .BR_TYPE_BITS(BR_TYPE_BITS),
        .TAGE_IDX_BITS(TAGE_IDX_BITS),
        .TAGE_TAG_BITS(TAGE_TAG_BITS),
        .BPU_SCL_META_NTABLE(BPU_SCL_META_NTABLE),
        .BPU_SCL_META_IDX_BITS(BPU_SCL_META_IDX_BITS),
        .BPU_SCL_META_SUM_BITS(BPU_SCL_META_SUM_BITS),
        .BPU_LOOP_META_IDX_BITS(BPU_LOOP_META_IDX_BITS),
        .BPU_LOOP_META_TAG_BITS(BPU_LOOP_META_TAG_BITS)
    ) u_frontend_core_top (
        .aclk(aclk),
        .aresetn(aresetn),
        .reset(reset),
        .refetch(refetch),
        .itlb_flush(itlb_flush),
        .fence_i(fence_i),
        .refetch_address(refetch_address),
        .csr_status_sstatus(csr_status_sstatus),
        .csr_status_mstatus(csr_status_mstatus),
        .csr_status_satp(csr_status_satp),
        .csr_status_privilege(csr_status_privilege),
        .FIFO_read_enable(FIFO_read_enable),
        .back2front_valid(back2front_valid),
        .predict_base_pc(predict_base_pc),
        .predict_dir(predict_dir),
        .actual_dir(actual_dir),
        .actual_br_type(actual_br_type),
        .actual_target(actual_target),
        .alt_pred(alt_pred),
        .altpcpn(altpcpn),
        .pcpn(pcpn),
        .tage_idx(tage_idx),
        .tage_tag(tage_tag),
        .sc_used(sc_used),
        .sc_pred(sc_pred),
        .sc_sum(sc_sum),
        .sc_idx(sc_idx),
        .loop_used(loop_used),
        .loop_hit(loop_hit),
        .loop_pred(loop_pred),
        .loop_idx(loop_idx),
        .loop_tag(loop_tag),
        .icache_read_valid(icache_read_valid),
        .fetch_address(fetch_address),
        .icache_read_valid_2(icache_read_valid_2),
        .fetch_address_2(fetch_address_2),
        .icache_invalidate_req(icache_invalidate_req),
        .icache_run_comb_only(icache_run_comb_only),
        .icache_read_ready(icache_read_ready),
        .icache_read_complete(icache_read_complete),
        .icache_read_ready_2(icache_read_ready_2),
        .icache_read_complete_2(icache_read_complete_2),
        .icache_fetch_group(icache_fetch_group),
        .icache_page_fault_inst(icache_page_fault_inst),
        .icache_inst_valid(icache_inst_valid),
        .icache_fetch_pc(icache_fetch_pc),
        .icache_fetch_group_2(icache_fetch_group_2),
        .icache_page_fault_inst_2(icache_page_fault_inst_2),
        .icache_inst_valid_2(icache_inst_valid_2),
        .icache_fetch_pc_2(icache_fetch_pc_2),
        .FIFO_valid(FIFO_valid),
        .commit_stall(commit_stall),
        .pc(pc),
        .instructions(instructions),
        .inst_valid(inst_valid),
        .out_predict_dir(out_predict_dir),
        .predict_next_fetch_address(predict_next_fetch_address),
        .out_alt_pred(out_alt_pred),
        .out_altpcpn(out_altpcpn),
        .out_pcpn(out_pcpn),
        .page_fault_inst(page_fault_inst),
        .out_tage_idx(out_tage_idx),
        .out_tage_tag(out_tage_tag),
        .out_sc_used(out_sc_used),
        .out_sc_pred(out_sc_pred),
        .out_sc_sum(out_sc_sum),
        .out_sc_idx(out_sc_idx),
        .out_loop_used(out_loop_used),
        .out_loop_hit(out_loop_hit),
        .out_loop_pred(out_loop_pred),
        .out_loop_idx(out_loop_idx),
        .out_loop_tag(out_loop_tag)
    );

    icache_top #(
        .RESET_PC(RESET_PC),
        .FETCH_WIDTH(FETCH_WIDTH),
        .PC_BITS(PC_BITS),
        .INST_BITS(INST_BITS),
        .ADDR_BITS(ADDR_BITS),
        .DATA_BITS(DATA_BITS),
        .CSR_BITS(CSR_BITS),
        .PRIVILEGE_BITS(PRIVILEGE_BITS),
        .ID_BITS(ID_BITS),
        .MODE_BITS(MODE_BITS),
        .READ_RESP_BITS(READ_RESP_BITS),
        .MMU_RESULT_BITS(MMU_RESULT_BITS)
    ) u_icache_top (
        .aclk(aclk),
        .aresetn(aresetn),
        .reset(reset),
        .mode(mode),
        .refetch(refetch),
        .itlb_flush(itlb_flush),
        .fence_i(fence_i),
        .invalidate_req(icache_invalidate_req),
        .run_comb_only(icache_run_comb_only),
        .icache_read_valid(icache_read_valid),
        .fetch_address(fetch_address),
        .icache_read_valid_2(icache_read_valid_2),
        .fetch_address_2(fetch_address_2),
        .csr_status_sstatus(csr_status_sstatus),
        .csr_status_mstatus(csr_status_mstatus),
        .csr_status_satp(csr_status_satp),
        .csr_status_privilege(csr_status_privilege),
        .icache_read_ready(icache_read_ready),
        .icache_read_complete(icache_read_complete),
        .icache_read_ready_2(icache_read_ready_2),
        .icache_read_complete_2(icache_read_complete_2),
        .fetch_group(icache_fetch_group),
        .page_fault_inst(icache_page_fault_inst),
        .inst_valid(icache_inst_valid),
        .fetch_pc(icache_fetch_pc),
        .fetch_group_2(icache_fetch_group_2),
        .page_fault_inst_2(icache_page_fault_inst_2),
        .inst_valid_2(icache_inst_valid_2),
        .fetch_pc_2(icache_fetch_pc_2),
        .icache_itlb_req_valid(icache_itlb_req_valid),
        .icache_itlb_req_vaddr(icache_itlb_req_vaddr),
        .itlb_icache_resp_valid(itlb_icache_resp_valid),
        .itlb_icache_resp_paddr(itlb_icache_resp_paddr),
        .itlb_icache_resp_result(itlb_icache_resp_result),
        .icache_llc_read_req_valid(icache_llc_read_req_valid),
        .icache_llc_read_req_ready(icache_llc_read_req_ready),
        .icache_llc_read_req_accepted(icache_llc_read_req_accepted),
        .icache_llc_read_req_accepted_id(icache_llc_read_req_accepted_id),
        .icache_llc_read_req_addr(icache_llc_read_req_addr),
        .icache_llc_read_req_total_size(icache_llc_read_req_total_size),
        .icache_llc_read_req_id(icache_llc_read_req_id),
        .icache_llc_read_req_bypass(icache_llc_read_req_bypass),
        .icache_llc_read_resp_valid(icache_llc_read_resp_valid),
        .icache_llc_read_resp_ready(icache_llc_read_resp_ready),
        .icache_llc_read_resp_data(icache_llc_read_resp_data),
        .icache_llc_read_resp_id(icache_llc_read_resp_id),
        .icache_dcache_req_valid(icache_dcache_req_valid),
        .icache_dcache_req_addr(icache_dcache_req_addr),
        .dcache_icache_resp_valid(dcache_icache_resp_valid),
        .dcache_icache_resp_miss(dcache_icache_resp_miss),
        .dcache_icache_resp_data(dcache_icache_resp_data)
    );

    itlb_top #(
        .ADDR_BITS(ADDR_BITS),
        .DATA_BITS(DATA_BITS),
        .CSR_BITS(CSR_BITS),
        .PRIVILEGE_BITS(PRIVILEGE_BITS),
        .PTW_ACCESS_TYPE_BITS(PTW_ACCESS_TYPE_BITS),
        .PTW_LEVEL_BITS(PTW_LEVEL_BITS),
        .PTE_BITS(PTE_BITS),
        .MMU_RESULT_BITS(MMU_RESULT_BITS),
        .ITLB_ENTRIES(ITLB_ENTRIES)
    ) u_itlb_top (
        .clk(aclk),
        .rst_n(aresetn),
        .reset(reset),
        .flush(itlb_flush),
        .csr_status_sstatus(csr_status_sstatus),
        .csr_status_mstatus(csr_status_mstatus),
        .csr_status_satp(csr_status_satp),
        .csr_status_privilege(csr_status_privilege),
        .icache_itlb_req_valid(icache_itlb_req_valid),
        .icache_itlb_req_vaddr(icache_itlb_req_vaddr),
        .itlb_icache_resp_valid(itlb_icache_resp_valid),
        .itlb_icache_resp_paddr(itlb_icache_resp_paddr),
        .itlb_icache_resp_result(itlb_icache_resp_result),
        .itlb_ptw_mem_req_valid(itlb_ptw_mem_req_valid),
        .itlb_ptw_mem_req_addr(itlb_ptw_mem_req_addr),
        .itlb_ptw_mem_resp_consumed(itlb_ptw_mem_resp_consumed),
        .itlb_ptw_mem_req_ready(itlb_ptw_mem_req_ready),
        .itlb_ptw_mem_resp_valid(itlb_ptw_mem_resp_valid),
        .itlb_ptw_mem_resp_data(itlb_ptw_mem_resp_data),
        .itlb_walk_req_valid(itlb_walk_req_valid),
        .itlb_walk_req_vaddr(itlb_walk_req_vaddr),
        .itlb_walk_req_satp(itlb_walk_req_satp),
        .itlb_walk_req_access_type(itlb_walk_req_access_type),
        .itlb_walk_resp_consumed(itlb_walk_resp_consumed),
        .itlb_walk_flush(itlb_walk_flush),
        .itlb_walk_req_ready(itlb_walk_req_ready),
        .itlb_walk_resp_valid(itlb_walk_resp_valid),
        .itlb_walk_resp_fault(itlb_walk_resp_fault),
        .itlb_walk_resp_vaddr(itlb_walk_resp_vaddr),
        .itlb_walk_resp_leaf_pte(itlb_walk_resp_leaf_pte),
        .itlb_walk_resp_leaf_level(itlb_walk_resp_leaf_level)
    );

endmodule
