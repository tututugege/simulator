`timescale 1ns / 1ps
`include "axi_llc_params.vh"
`include "qm3_cpu_params.vh"

// Backend non-LSU/non-DTLB shell.
//
// TODO:
// 1. Implement PreIduQueue, IDU, rename, dispatch, and issue logic.
// 2. Implement PRF, EXU, ROB, CSR, FTQ, and redirect/commit outputs.
// 3. Add table/template boundaries for ROB, PRF, rename maps, and other
//    backend state that should not be learned as flat combinational logic.
//
// This wrapper is reserved for PreIduQueue, IDU, rename, dispatch, issue,
// PRF, EXU, ROB, CSR, FTQ and related backend control logic.
module backend_core_top #(
    parameter FETCH_WIDTH            = `QM3_FETCH_WIDTH,
    parameter COMMIT_WIDTH           = `QM3_COMMIT_WIDTH,
    parameter TN_MAX                 = `QM3_TN_MAX,
    parameter PC_BITS                = `QM3_PC_BITS,
    parameter INST_BITS              = `QM3_INST_BITS,
    parameter CSR_BITS               = `QM3_CSR_BITS,
    parameter PRIVILEGE_BITS         = `QM3_PRIVILEGE_BITS,
    parameter PCPN_BITS              = `QM3_PCPN_BITS,
    parameter BR_TYPE_BITS           = `QM3_BR_TYPE_BITS,
    parameter TAGE_IDX_BITS          = `QM3_TAGE_IDX_BITS,
    parameter TAGE_TAG_BITS          = `QM3_TAGE_TAG_BITS,
    parameter BPU_SCL_META_NTABLE    = `QM3_BPU_SCL_META_NTABLE,
    parameter BPU_SCL_META_IDX_BITS  = `QM3_BPU_SCL_META_IDX_BITS,
    parameter BPU_SCL_META_SUM_BITS  = `QM3_BPU_SCL_META_SUM_BITS,
    parameter BPU_LOOP_META_IDX_BITS = `QM3_BPU_LOOP_META_IDX_BITS,
    parameter BPU_LOOP_META_TAG_BITS = `QM3_BPU_LOOP_META_TAG_BITS
) (
    input                                   aclk,
    input                                   aresetn,

    // FrontPreIO from frontend_top.front_top_out.
    input      [FETCH_WIDTH*INST_BITS-1:0]  front2pre_inst,
    input      [FETCH_WIDTH*PC_BITS-1:0]    front2pre_pc,
    input      [FETCH_WIDTH-1:0]            front2pre_valid,
    input                                   front2pre_front_stall,
    input      [FETCH_WIDTH-1:0]            front2pre_predict_dir,
    input      [FETCH_WIDTH-1:0]            front2pre_alt_pred,
    input      [FETCH_WIDTH*PCPN_BITS-1:0]  front2pre_altpcpn,
    input      [FETCH_WIDTH*PCPN_BITS-1:0]  front2pre_pcpn,
    input      [FETCH_WIDTH*PC_BITS-1:0]    front2pre_predict_next_fetch_address,
    input      [FETCH_WIDTH*TN_MAX*TAGE_IDX_BITS-1:0] front2pre_tage_idx,
    input      [FETCH_WIDTH*TN_MAX*TAGE_TAG_BITS-1:0] front2pre_tage_tag,
    input      [FETCH_WIDTH-1:0]            front2pre_sc_used,
    input      [FETCH_WIDTH-1:0]            front2pre_sc_pred,
    input      [FETCH_WIDTH*BPU_SCL_META_SUM_BITS-1:0] front2pre_sc_sum,
    input      [FETCH_WIDTH*BPU_SCL_META_NTABLE*BPU_SCL_META_IDX_BITS-1:0] front2pre_sc_idx,
    input      [FETCH_WIDTH-1:0]            front2pre_loop_used,
    input      [FETCH_WIDTH-1:0]            front2pre_loop_hit,
    input      [FETCH_WIDTH-1:0]            front2pre_loop_pred,
    input      [FETCH_WIDTH*BPU_LOOP_META_IDX_BITS-1:0] front2pre_loop_idx,
    input      [FETCH_WIDTH*BPU_LOOP_META_TAG_BITS-1:0] front2pre_loop_tag,
    input      [FETCH_WIDTH-1:0]            front2pre_page_fault_inst,

    // PreFrontIO to frontend_top.FIFO_read_enable generation.
    output     [FETCH_WIDTH-1:0]            pre2front_fire,
    output                                  pre2front_ready,

    // Back_out redirect/control to frontend_top.front_top_in.
    output                                  mispred,
    output                                  stall,
    output                                  flush,
    output                                  fence_i,
    output                                  itlb_flush,
    output     [PC_BITS-1:0]                redirect_pc,

    // Back_out commit/BPU update metadata to frontend_top.front_top_in.
    output     [COMMIT_WIDTH-1:0]           back2front_valid,
    output     [COMMIT_WIDTH*PC_BITS-1:0]   predict_base_pc,
    output     [COMMIT_WIDTH-1:0]           predict_dir,
    output     [COMMIT_WIDTH-1:0]           actual_dir,
    output     [COMMIT_WIDTH*BR_TYPE_BITS-1:0] actual_br_type,
    output     [COMMIT_WIDTH*PC_BITS-1:0]   actual_target,
    output     [COMMIT_WIDTH-1:0]           alt_pred,
    output     [COMMIT_WIDTH*PCPN_BITS-1:0] altpcpn,
    output     [COMMIT_WIDTH*PCPN_BITS-1:0] pcpn,
    output     [COMMIT_WIDTH*TN_MAX*TAGE_IDX_BITS-1:0] tage_idx,
    output     [COMMIT_WIDTH*TN_MAX*TAGE_TAG_BITS-1:0] tage_tag,
    output     [COMMIT_WIDTH-1:0]           sc_used,
    output     [COMMIT_WIDTH-1:0]           sc_pred,
    output     [COMMIT_WIDTH*BPU_SCL_META_SUM_BITS-1:0] sc_sum,
    output     [COMMIT_WIDTH*BPU_SCL_META_NTABLE*BPU_SCL_META_IDX_BITS-1:0] sc_idx,
    output     [COMMIT_WIDTH-1:0]           loop_used,
    output     [COMMIT_WIDTH-1:0]           loop_hit,
    output     [COMMIT_WIDTH-1:0]           loop_pred,
    output     [COMMIT_WIDTH*BPU_LOOP_META_IDX_BITS-1:0] loop_idx,
    output     [COMMIT_WIDTH*BPU_LOOP_META_TAG_BITS-1:0] loop_tag,

    // CsrStatusIO to frontend_top, DTLB, LSU, and mem_subsystem_top.
    output     [CSR_BITS-1:0]               csr_status_sstatus,
    output     [CSR_BITS-1:0]               csr_status_mstatus,
    output     [CSR_BITS-1:0]               csr_status_satp,
    output     [PRIVILEGE_BITS-1:0]         csr_status_privilege
);

    assign pre2front_fire                  = {FETCH_WIDTH{1'b0}};
    assign pre2front_ready                 = 1'b1;

    assign mispred                         = 1'b0;
    assign stall                           = 1'b0;
    assign flush                           = 1'b0;
    assign fence_i                         = 1'b0;
    assign itlb_flush                      = 1'b0;
    assign redirect_pc                     = {PC_BITS{1'b0}};

    assign back2front_valid                = {COMMIT_WIDTH{1'b0}};
    assign predict_base_pc                 = {COMMIT_WIDTH*PC_BITS{1'b0}};
    assign predict_dir                     = {COMMIT_WIDTH{1'b0}};
    assign actual_dir                      = {COMMIT_WIDTH{1'b0}};
    assign actual_br_type                  = {COMMIT_WIDTH*BR_TYPE_BITS{1'b0}};
    assign actual_target                   = {COMMIT_WIDTH*PC_BITS{1'b0}};
    assign alt_pred                        = {COMMIT_WIDTH{1'b0}};
    assign altpcpn                         = {COMMIT_WIDTH*PCPN_BITS{1'b0}};
    assign pcpn                            = {COMMIT_WIDTH*PCPN_BITS{1'b0}};
    assign tage_idx                        = {COMMIT_WIDTH*TN_MAX*TAGE_IDX_BITS{1'b0}};
    assign tage_tag                        = {COMMIT_WIDTH*TN_MAX*TAGE_TAG_BITS{1'b0}};
    assign sc_used                         = {COMMIT_WIDTH{1'b0}};
    assign sc_pred                         = {COMMIT_WIDTH{1'b0}};
    assign sc_sum                          = {COMMIT_WIDTH*BPU_SCL_META_SUM_BITS{1'b0}};
    assign sc_idx                          = {COMMIT_WIDTH*BPU_SCL_META_NTABLE*BPU_SCL_META_IDX_BITS{1'b0}};
    assign loop_used                       = {COMMIT_WIDTH{1'b0}};
    assign loop_hit                        = {COMMIT_WIDTH{1'b0}};
    assign loop_pred                       = {COMMIT_WIDTH{1'b0}};
    assign loop_idx                        = {COMMIT_WIDTH*BPU_LOOP_META_IDX_BITS{1'b0}};
    assign loop_tag                        = {COMMIT_WIDTH*BPU_LOOP_META_TAG_BITS{1'b0}};

    assign csr_status_sstatus              = {CSR_BITS{1'b0}};
    assign csr_status_mstatus              = {CSR_BITS{1'b0}};
    assign csr_status_satp                 = {CSR_BITS{1'b0}};
    assign csr_status_privilege            = {PRIVILEGE_BITS{1'b0}};

endmodule
