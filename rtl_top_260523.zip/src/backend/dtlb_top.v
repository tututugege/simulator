`timescale 1ns / 1ps
`include "axi_llc_params.vh"
`include "qm3_cpu_params.vh"

// DTLB shell.
//
// TODO:
// 1. Implement trained/generated multi-port DTLB lookup and miss control logic.
// 2. Add explicit TLB regfile/template lookup and write ports.
// 3. Implement PTW request/response handling for DTLB misses.
// 4. Implement flush and refill/writeback behavior.
//
// LSU lookup ports are parameterized by LSU load/store port count. PTW ports
// follow simulator PtwMemPortCombIn/Out and PtwWalkPortCombIn/Out naming.
module dtlb_top #(
    parameter ADDR_BITS              = `AXI_LLC_ADDR_BITS,
    parameter DATA_BITS              = `QM3_DATA_BITS,
    parameter CSR_BITS               = `QM3_CSR_BITS,
    parameter PRIVILEGE_BITS         = `QM3_PRIVILEGE_BITS,
    parameter LSU_LDU_COUNT          = `QM3_LSU_LDU_COUNT,
    parameter LSU_STA_COUNT          = `QM3_LSU_STA_COUNT,
    parameter MMU_RESULT_BITS        = `QM3_MMU_RESULT_BITS,
    parameter DTLB_ENTRIES           = `QM3_DTLB_ENTRIES,
    parameter PTW_ACCESS_TYPE_BITS   = `QM3_PTW_ACCESS_TYPE_BITS,
    parameter PTW_LEVEL_BITS         = `QM3_PTW_LEVEL_BITS,
    parameter PTE_BITS               = `QM3_PTE_BITS
) (
    input                                   clk,
    input                                   rst_n,
    input                                   flush,

    // LsuMMUIO request side from lsu_top, in C++ field order.
    input      [LSU_LDU_COUNT-1:0]          lsu_dtlb_ldq_req_valid,
    input      [LSU_LDU_COUNT*ADDR_BITS-1:0] lsu_dtlb_ldq_req_vaddr,
    input      [LSU_STA_COUNT-1:0]          lsu_dtlb_stq_req_valid,
    input      [LSU_STA_COUNT*ADDR_BITS-1:0] lsu_dtlb_stq_req_vaddr,
    input      [CSR_BITS-1:0]               csr_status_sstatus,
    input      [CSR_BITS-1:0]               csr_status_mstatus,
    input      [CSR_BITS-1:0]               csr_status_satp,
    input      [PRIVILEGE_BITS-1:0]         csr_status_privilege,

    // MMULsuIO response side to lsu_top, in C++ field order.
    output     [LSU_LDU_COUNT-1:0]          dtlb_lsu_ldq_resp_valid,
    output     [LSU_LDU_COUNT*ADDR_BITS-1:0] dtlb_lsu_ldq_resp_paddr,
    output     [LSU_LDU_COUNT*MMU_RESULT_BITS-1:0] dtlb_lsu_ldq_resp_result,
    output     [LSU_STA_COUNT-1:0]          dtlb_lsu_stq_resp_valid,
    output     [LSU_STA_COUNT*ADDR_BITS-1:0] dtlb_lsu_stq_resp_paddr,
    output     [LSU_STA_COUNT*MMU_RESULT_BITS-1:0] dtlb_lsu_stq_resp_result,

    // DTLB PtwMemPortCombIn to mem_subsystem_top.
    output                                  dtlb_ptw_mem_req_valid,
    output     [ADDR_BITS-1:0]              dtlb_ptw_mem_req_addr,
    output                                  dtlb_ptw_mem_resp_consumed,

    // DTLB PtwMemPortCombOut from mem_subsystem_top.
    input                                   dtlb_ptw_mem_req_ready,
    input                                   dtlb_ptw_mem_resp_valid,
    input      [DATA_BITS-1:0]              dtlb_ptw_mem_resp_data,

    // DTLB PtwWalkPortCombIn to mem_subsystem_top.
    output                                  dtlb_walk_req_valid,
    output     [ADDR_BITS-1:0]              dtlb_walk_req_vaddr,
    output     [CSR_BITS-1:0]               dtlb_walk_req_satp,
    output     [PTW_ACCESS_TYPE_BITS-1:0]   dtlb_walk_req_access_type,
    output                                  dtlb_walk_resp_consumed,
    output                                  dtlb_walk_flush,

    // DTLB PtwWalkPortCombOut from mem_subsystem_top.
    input                                   dtlb_walk_req_ready,
    input                                   dtlb_walk_resp_valid,
    input                                   dtlb_walk_resp_fault,
    input      [ADDR_BITS-1:0]              dtlb_walk_resp_vaddr,
    input      [PTE_BITS-1:0]               dtlb_walk_resp_leaf_pte,
    input      [PTW_LEVEL_BITS-1:0]         dtlb_walk_resp_leaf_level
);

    assign dtlb_lsu_ldq_resp_valid     = {LSU_LDU_COUNT{1'b0}};
    assign dtlb_lsu_ldq_resp_paddr     = {LSU_LDU_COUNT*ADDR_BITS{1'b0}};
    assign dtlb_lsu_ldq_resp_result    = {LSU_LDU_COUNT*MMU_RESULT_BITS{1'b0}};
    assign dtlb_lsu_stq_resp_valid     = {LSU_STA_COUNT{1'b0}};
    assign dtlb_lsu_stq_resp_paddr     = {LSU_STA_COUNT*ADDR_BITS{1'b0}};
    assign dtlb_lsu_stq_resp_result    = {LSU_STA_COUNT*MMU_RESULT_BITS{1'b0}};

    assign dtlb_ptw_mem_req_valid      = 1'b0;
    assign dtlb_ptw_mem_req_addr       = {ADDR_BITS{1'b0}};
    assign dtlb_ptw_mem_resp_consumed  = 1'b0;

    assign dtlb_walk_req_valid         = 1'b0;
    assign dtlb_walk_req_vaddr         = {ADDR_BITS{1'b0}};
    assign dtlb_walk_req_satp          = csr_status_satp;
    assign dtlb_walk_req_access_type   = {PTW_ACCESS_TYPE_BITS{1'b0}};
    assign dtlb_walk_resp_consumed     = 1'b0;
    assign dtlb_walk_flush             = flush;

endmodule
