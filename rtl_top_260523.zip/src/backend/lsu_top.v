`timescale 1ns / 1ps
`include "axi_llc_params.vh"
`include "qm3_cpu_params.vh"

// LSU shell.
//
// TODO:
// 1. Implement load/store queue state and LSU address/data pipeline.
// 2. Implement DTLB request issue and response handling.
// 3. Implement DCache request issue, replay handling, and response retirement.
// 4. Implement MMIO/peripheral request and response handling.
// 5. Add explicit table/template boundaries for LSU queues before training or
//    generating their internal RTL.
//
// The DTLB side mirrors simulator LsuMMUIO/MMULsuIO. The DCache and MMIO sides
// mirror LsuDcacheIO/DcacheLsuIO and PeripheralReqIO/RespIO.
module lsu_top #(
    parameter ADDR_BITS              = `AXI_LLC_ADDR_BITS,
    parameter DATA_BITS              = `QM3_DATA_BITS,
    parameter STRB_BITS              = `QM3_STRB_BITS,
    parameter CSR_BITS               = `QM3_CSR_BITS,
    parameter PRIVILEGE_BITS         = `QM3_PRIVILEGE_BITS,
    parameter LSU_LDU_COUNT          = `QM3_LSU_LDU_COUNT,
    parameter LSU_STA_COUNT          = `QM3_LSU_STA_COUNT,
    parameter LSU_LDU_WIDTH          = `QM3_LSU_LDU_WIDTH,
    parameter LSU_REQ_ID_BITS        = `QM3_LSU_REQ_ID_BITS,
    parameter REPLAY_BITS            = `QM3_REPLAY_BITS,
    parameter MMU_RESULT_BITS        = `QM3_MMU_RESULT_BITS
) (
    input                                   clk,
    input                                   rst_n,

    // LsuMMUIO request side to dtlb_top, in C++ field order.
    output     [LSU_LDU_COUNT-1:0]          lsu_dtlb_ldq_req_valid,
    output     [LSU_LDU_COUNT*ADDR_BITS-1:0] lsu_dtlb_ldq_req_vaddr,
    output     [LSU_STA_COUNT-1:0]          lsu_dtlb_stq_req_valid,
    output     [LSU_STA_COUNT*ADDR_BITS-1:0] lsu_dtlb_stq_req_vaddr,
    input      [CSR_BITS-1:0]               csr_status_sstatus,
    input      [CSR_BITS-1:0]               csr_status_mstatus,
    input      [CSR_BITS-1:0]               csr_status_satp,
    input      [PRIVILEGE_BITS-1:0]         csr_status_privilege,

    // MMULsuIO response side from dtlb_top, in C++ field order.
    input      [LSU_LDU_COUNT-1:0]          dtlb_lsu_ldq_resp_valid,
    input      [LSU_LDU_COUNT*ADDR_BITS-1:0] dtlb_lsu_ldq_resp_paddr,
    input      [LSU_LDU_COUNT*MMU_RESULT_BITS-1:0] dtlb_lsu_ldq_resp_result,
    input      [LSU_STA_COUNT-1:0]          dtlb_lsu_stq_resp_valid,
    input      [LSU_STA_COUNT*ADDR_BITS-1:0] dtlb_lsu_stq_resp_paddr,
    input      [LSU_STA_COUNT*MMU_RESULT_BITS-1:0] dtlb_lsu_stq_resp_result,

    // PeripheralReqIO to mem_subsystem_top/MMIO path.
    output                                  peripheral_req_is_mmio,
    output                                  peripheral_req_wen,
    output     [ADDR_BITS-1:0]              peripheral_req_mmio_addr,
    output     [DATA_BITS-1:0]              peripheral_req_mmio_wdata,
    output     [2:0]                        peripheral_req_mmio_fun3,

    // PeripheralRespIO from mem_subsystem_top/MMIO path.
    input                                   peripheral_resp_is_mmio,
    input                                   peripheral_resp_ready,
    input      [DATA_BITS-1:0]              peripheral_resp_mmio_rdata,

    // LsuDcacheIO.req_ports to mem_subsystem_top/RealDcache.
    output     [LSU_LDU_COUNT-1:0]          lsu2dcache_load_ports_valid,
    output     [LSU_LDU_COUNT*ADDR_BITS-1:0] lsu2dcache_load_ports_addr,
    output     [LSU_LDU_COUNT*LSU_REQ_ID_BITS-1:0] lsu2dcache_load_ports_req_id,
    output     [LSU_STA_COUNT-1:0]          lsu2dcache_store_ports_valid,
    output     [LSU_STA_COUNT*ADDR_BITS-1:0] lsu2dcache_store_ports_addr,
    output     [LSU_STA_COUNT*DATA_BITS-1:0] lsu2dcache_store_ports_data,
    output     [LSU_STA_COUNT*STRB_BITS-1:0] lsu2dcache_store_ports_strb,
    output     [LSU_STA_COUNT*LSU_REQ_ID_BITS-1:0] lsu2dcache_store_ports_req_id,
    output     [LSU_LDU_WIDTH:0]            lsu2dcache_icache_req,

    // DcacheLsuIO.resp_ports from mem_subsystem_top/RealDcache.
    input      [LSU_LDU_COUNT-1:0]          dcache2lsu_load_resps_valid,
    input      [LSU_LDU_COUNT*DATA_BITS-1:0] dcache2lsu_load_resps_data,
    input      [LSU_LDU_COUNT*LSU_REQ_ID_BITS-1:0] dcache2lsu_load_resps_req_id,
    input      [LSU_LDU_COUNT*REPLAY_BITS-1:0] dcache2lsu_load_resps_replay,
    input      [LSU_STA_COUNT-1:0]          dcache2lsu_store_resps_valid,
    input      [LSU_STA_COUNT*REPLAY_BITS-1:0] dcache2lsu_store_resps_replay,
    input      [LSU_STA_COUNT*LSU_REQ_ID_BITS-1:0] dcache2lsu_store_resps_req_id,
    input                                   dcache2lsu_mshr_fill
);

    assign lsu_dtlb_ldq_req_valid          = {LSU_LDU_COUNT{1'b0}};
    assign lsu_dtlb_ldq_req_vaddr          = {LSU_LDU_COUNT*ADDR_BITS{1'b0}};
    assign lsu_dtlb_stq_req_valid          = {LSU_STA_COUNT{1'b0}};
    assign lsu_dtlb_stq_req_vaddr          = {LSU_STA_COUNT*ADDR_BITS{1'b0}};

    assign peripheral_req_is_mmio          = 1'b0;
    assign peripheral_req_wen              = 1'b0;
    assign peripheral_req_mmio_addr        = {ADDR_BITS{1'b0}};
    assign peripheral_req_mmio_wdata       = {DATA_BITS{1'b0}};
    assign peripheral_req_mmio_fun3        = 3'b0;

    assign lsu2dcache_load_ports_valid     = {LSU_LDU_COUNT{1'b0}};
    assign lsu2dcache_load_ports_addr      = {LSU_LDU_COUNT*ADDR_BITS{1'b0}};
    assign lsu2dcache_load_ports_req_id    = {LSU_LDU_COUNT*LSU_REQ_ID_BITS{1'b0}};
    assign lsu2dcache_store_ports_valid    = {LSU_STA_COUNT{1'b0}};
    assign lsu2dcache_store_ports_addr     = {LSU_STA_COUNT*ADDR_BITS{1'b0}};
    assign lsu2dcache_store_ports_data     = {LSU_STA_COUNT*DATA_BITS{1'b0}};
    assign lsu2dcache_store_ports_strb     = {LSU_STA_COUNT*STRB_BITS{1'b0}};
    assign lsu2dcache_store_ports_req_id   = {LSU_STA_COUNT*LSU_REQ_ID_BITS{1'b0}};
    assign lsu2dcache_icache_req           = LSU_LDU_COUNT;

endmodule
