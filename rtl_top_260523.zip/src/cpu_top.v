`timescale 1ns / 1ps
`include "axi_llc_params.vh"
`include "qm3_cpu_params.vh"

// Top-level shell for the RTL CPU integration.
//
// TODO:
// 1. Replace submodule shells with completed frontend/backend/mem subsystem and
//    AXI/LLC RTL while preserving this SoC-facing boundary.
//
// External AXI connections:
//   - ddr_axi_*  connects to the DDR/SDRAM AXI4 slave fabric.
//   - mmio_axi_* connects to the peripheral/MMIO AXI4 slave fabric.
// Clock-domain convention:
//   - aclk    is the high-frequency AXI/LLC/DDR clock.
//   - cpu_clk is the low-frequency core clock for frontend/backend/mem
//     subsystem. The default simulator ratio is aclk:cpu_clk = 16:1.
// AxQOS/AxREGION are intentionally not exposed: the reference RISCV_cpu_top.v
// boundary does not have them, and the current AXI kit top does not require
// them.
module cpu_top #(
    parameter USE_TRAIN               = 0,
    parameter RESET_PC                = 32'h8000_0000,
    parameter EXT_INT_BITS            = 6,
    parameter PC_BITS                 = `QM3_PC_BITS,
    parameter INST_BITS               = `QM3_INST_BITS,
    parameter DATA_BITS               = `QM3_DATA_BITS,
    parameter STRB_BITS               = `QM3_STRB_BITS,
    parameter FETCH_WIDTH             = `QM3_FETCH_WIDTH,
    parameter DECODE_WIDTH            = `QM3_DECODE_WIDTH,
    parameter COMMIT_WIDTH            = `QM3_COMMIT_WIDTH,
    parameter ISSUE_WIDTH             = `QM3_ISSUE_WIDTH,
    parameter ALU_NUM                 = `QM3_ALU_NUM,
    parameter BRU_NUM                 = `QM3_BRU_NUM,
    parameter ROB_NUM                 = `QM3_ROB_NUM,
    parameter IDU_INST_BUFFER_SIZE    = `QM3_IDU_INST_BUFFER_SIZE,
    parameter FTQ_SIZE                = `QM3_FTQ_SIZE,
    parameter LDQ_SIZE                = `QM3_LDQ_SIZE,
    parameter STQ_SIZE                = `QM3_STQ_SIZE,
    parameter LOAD_WINDOWS_WIDTH      = `QM3_LOAD_WINDOWS_WIDTH,
    parameter STORE_WINDOWS_WIDTH     = `QM3_STORE_WINDOWS_WIDTH,
    parameter TN_MAX                  = `QM3_TN_MAX,
    parameter PCPN_BITS               = `QM3_PCPN_BITS,
    parameter BR_TYPE_BITS            = `QM3_BR_TYPE_BITS,
    parameter TAGE_IDX_BITS           = `QM3_TAGE_IDX_BITS,
    parameter TAGE_TAG_BITS           = `QM3_TAGE_TAG_BITS,
    parameter BPU_SCL_META_NTABLE     = `QM3_BPU_SCL_META_NTABLE,
    parameter BPU_SCL_META_IDX_BITS   = `QM3_BPU_SCL_META_IDX_BITS,
    parameter BPU_SCL_META_SUM_BITS   = `QM3_BPU_SCL_META_SUM_BITS,
    parameter BPU_LOOP_META_IDX_BITS  = `QM3_BPU_LOOP_META_IDX_BITS,
    parameter BPU_LOOP_META_TAG_BITS  = `QM3_BPU_LOOP_META_TAG_BITS,
    parameter CSR_BITS                = `QM3_CSR_BITS,
    parameter PRIVILEGE_BITS          = `QM3_PRIVILEGE_BITS,
    parameter LSU_LDU_COUNT           = `QM3_LSU_LDU_COUNT,
    parameter LSU_STA_COUNT           = `QM3_LSU_STA_COUNT,
    parameter LSU_SDU_COUNT           = `QM3_LSU_SDU_COUNT,
    parameter LSU_LDU_WIDTH           = `QM3_LSU_LDU_WIDTH,
    parameter LSU_REQ_ID_BITS         = `QM3_LSU_REQ_ID_BITS,
    parameter REPLAY_BITS             = `QM3_REPLAY_BITS,
    parameter MMU_RESULT_BITS         = `QM3_MMU_RESULT_BITS,
    parameter ITLB_ENTRIES            = `QM3_ITLB_ENTRIES,
    parameter DTLB_ENTRIES            = `QM3_DTLB_ENTRIES,
    parameter ICACHE_LINE_BYTES       = `QM3_ICACHE_LINE_BYTES,
    parameter ICACHE_SET_COUNT        = `QM3_ICACHE_SET_COUNT,
    parameter ICACHE_WAY_COUNT        = `QM3_ICACHE_WAY_COUNT,
    parameter DCACHE_LINE_BYTES       = `QM3_DCACHE_LINE_BYTES,
    parameter DCACHE_SET_COUNT        = `QM3_DCACHE_SET_COUNT,
    parameter DCACHE_WAY_COUNT        = `QM3_DCACHE_WAY_COUNT,
    parameter DCACHE_MSHR_ENTRIES     = `QM3_DCACHE_MSHR_ENTRIES,
    parameter DCACHE_WB_ENTRIES       = `QM3_DCACHE_WB_ENTRIES,
    parameter PTW_ACCESS_TYPE_BITS    = `QM3_PTW_ACCESS_TYPE_BITS,
    parameter PTW_LEVEL_BITS          = `QM3_PTW_LEVEL_BITS,
    parameter PTE_BITS                = `QM3_PTE_BITS,
    parameter ADDR_BITS               = `AXI_LLC_ADDR_BITS,
    parameter ID_BITS                 = `AXI_LLC_ID_BITS,
    parameter SLOT_ID_BITS            = `AXI_LLC_SLOT_ID_BITS,
    parameter MODE_BITS               = `AXI_LLC_MODE_BITS,
    parameter LINE_BYTES              = `AXI_LLC_LINE_BYTES,
    parameter LINE_BITS               = `AXI_LLC_LINE_BITS,
    parameter LINE_OFFSET_BITS        = `AXI_LLC_LINE_OFFSET_BITS,
    // 0: 3e13836 simulator default LLC (4 MiB, 16-way).
    // 1: shell-only FPGA profile (64 KiB, 4-way); CPU/cache widths stay at
    //    the 3e13836 default profile.
    parameter FPGA_KB_LLC             = 0,
    parameter SET_COUNT               = FPGA_KB_LLC ? `AXI_LLC_FPGA_SET_COUNT : `AXI_LLC_SET_COUNT,
    parameter SET_BITS                = FPGA_KB_LLC ? `AXI_LLC_FPGA_SET_BITS : `AXI_LLC_SET_BITS,
    parameter WAY_COUNT               = FPGA_KB_LLC ? `AXI_LLC_FPGA_WAY_COUNT : `AXI_LLC_WAY_COUNT,
    parameter WAY_BITS                = FPGA_KB_LLC ? `AXI_LLC_FPGA_WAY_BITS : `AXI_LLC_WAY_BITS,
    parameter META_BITS               = `AXI_LLC_META_BITS,
    parameter LLC_SIZE_BYTES          = FPGA_KB_LLC ? `AXI_LLC_FPGA_LLC_SIZE_BYTES : `AXI_LLC_LLC_SIZE_BYTES,
    parameter WINDOW_BYTES            = FPGA_KB_LLC ? `AXI_LLC_FPGA_WINDOW_BYTES : `AXI_LLC_WINDOW_BYTES,
    parameter WINDOW_WAYS             = FPGA_KB_LLC ? `AXI_LLC_FPGA_WINDOW_WAYS : `AXI_LLC_WINDOW_WAYS,
    parameter MMIO_BASE               = `AXI_LLC_MMIO_BASE,
    parameter MMIO_SIZE               = `AXI_LLC_MMIO_SIZE,
    parameter DDR_BASE                = 32'h4000_0000,
    parameter RESET_MODE              = 2'b01,
    parameter RESET_OFFSET            = {`AXI_LLC_ADDR_BITS{1'b0}},
    parameter AXI_SUBSYSTEM_FREQ_DIV  = `AXI_SUBSYSTEM_FREQ_DIV_DEFAULT,
    parameter USE_SMIC12_STORES       = 1,
    parameter TABLE_READ_LATENCY      = `AXI_LLC_TABLE_READ_LATENCY,
    parameter NUM_READ_MASTERS        = `QM3_NUM_READ_MASTERS,
    parameter NUM_WRITE_MASTERS       = `QM3_NUM_WRITE_MASTERS,
    parameter DDR_AXI_ID_BITS         = `AXI_LLC_AXI_ID_BITS,
    parameter DDR_AXI_DATA_BYTES      = `AXI_LLC_AXI_DATA_BYTES,
    parameter DDR_AXI_DATA_BITS       = `AXI_LLC_AXI_DATA_BITS,
    parameter DDR_AXI_STRB_BITS       = `AXI_LLC_AXI_STRB_BITS,
    parameter MMIO_AXI_ID_BITS        = `AXI_LLC_AXI_ID_BITS,
    parameter MMIO_AXI_DATA_BYTES     = 4,
    parameter MMIO_AXI_DATA_BITS      = 32,
    parameter MMIO_AXI_STRB_BITS      = 4,
    parameter READ_RESP_BYTES         = `AXI_LLC_READ_RESP_BYTES,
    parameter READ_RESP_BITS          = `AXI_LLC_READ_RESP_BITS
) (
    input      [EXT_INT_BITS-1:0]       ext_int,
    // High-frequency clock for AXI/LLC and external DDR/MMIO paths.
    input                               aclk,
    // Low-frequency clock for frontend/backend/mem subsystem.
    input                               cpu_clk,
    input                               aresetn,
    // AXI/LLC mode control.
    // 2'b01: LLC_ON, 2'b10: mapped-window mode, 2'b00/2'b11: LLC_OFF
    // inside the LLC subsystem. ICache/DCache-local bypass follows the
    // mapped-window address-mode policy, not LLC_OFF.
    input      [MODE_BITS-1:0]          mode,
    output                              global_reset,

    // DDR/SDRAM AXI4 master interface. Connect to the memory-controller path.
    // DDR write address channel.
    output                              ddr_axi_awvalid,
    input                               ddr_axi_awready,
    output     [DDR_AXI_ID_BITS-1:0]    ddr_axi_awid,
    output     [ADDR_BITS-1:0]          ddr_axi_awaddr,
    output     [7:0]                    ddr_axi_awlen,
    output     [2:0]                    ddr_axi_awsize,
    output     [1:0]                    ddr_axi_awburst,
    output                              ddr_axi_awlock,
    output     [3:0]                    ddr_axi_awcache,
    output     [2:0]                    ddr_axi_awprot,

    // DDR write data channel. AXI4 has no WID; add an AXI3 adapter outside
    // this top if a legacy slave still requires WID.
    output                              ddr_axi_wvalid,
    input                               ddr_axi_wready,
    output     [DDR_AXI_DATA_BITS-1:0]  ddr_axi_wdata,
    output     [DDR_AXI_STRB_BITS-1:0]  ddr_axi_wstrb,
    output                              ddr_axi_wlast,

    // DDR write response channel.
    input                               ddr_axi_bvalid,
    output                              ddr_axi_bready,
    input      [DDR_AXI_ID_BITS-1:0]    ddr_axi_bid,
    input      [1:0]                    ddr_axi_bresp,

    // DDR read address channel.
    output                              ddr_axi_arvalid,
    input                               ddr_axi_arready,
    output     [DDR_AXI_ID_BITS-1:0]    ddr_axi_arid,
    output     [ADDR_BITS-1:0]          ddr_axi_araddr,
    output     [7:0]                    ddr_axi_arlen,
    output     [2:0]                    ddr_axi_arsize,
    output     [1:0]                    ddr_axi_arburst,
    output                              ddr_axi_arlock,
    output     [3:0]                    ddr_axi_arcache,
    output     [2:0]                    ddr_axi_arprot,

    // DDR read data channel.
    input                               ddr_axi_rvalid,
    output                              ddr_axi_rready,
    input      [DDR_AXI_ID_BITS-1:0]    ddr_axi_rid,
    input      [DDR_AXI_DATA_BITS-1:0]  ddr_axi_rdata,
    input      [1:0]                    ddr_axi_rresp,
    input                               ddr_axi_rlast,

    // MMIO AXI4 master interface. Connect to the peripheral/MMIO path.
    // MMIO write address channel.
    output                              mmio_axi_awvalid,
    input                               mmio_axi_awready,
    output     [MMIO_AXI_ID_BITS-1:0]   mmio_axi_awid,
    output     [ADDR_BITS-1:0]          mmio_axi_awaddr,
    output     [7:0]                    mmio_axi_awlen,
    output     [2:0]                    mmio_axi_awsize,
    output     [1:0]                    mmio_axi_awburst,
    output                              mmio_axi_awlock,
    output     [3:0]                    mmio_axi_awcache,
    output     [2:0]                    mmio_axi_awprot,

    // MMIO write data channel. AXI4 has no WID.
    output                              mmio_axi_wvalid,
    input                               mmio_axi_wready,
    output     [MMIO_AXI_DATA_BITS-1:0] mmio_axi_wdata,
    output     [MMIO_AXI_STRB_BITS-1:0] mmio_axi_wstrb,
    output                              mmio_axi_wlast,

    // MMIO write response channel.
    input                               mmio_axi_bvalid,
    output                              mmio_axi_bready,
    input      [MMIO_AXI_ID_BITS-1:0]   mmio_axi_bid,
    input      [1:0]                    mmio_axi_bresp,

    // MMIO read address channel.
    output                              mmio_axi_arvalid,
    input                               mmio_axi_arready,
    output     [MMIO_AXI_ID_BITS-1:0]   mmio_axi_arid,
    output     [ADDR_BITS-1:0]          mmio_axi_araddr,
    output     [7:0]                    mmio_axi_arlen,
    output     [2:0]                    mmio_axi_arsize,
    output     [1:0]                    mmio_axi_arburst,
    output                              mmio_axi_arlock,
    output     [3:0]                    mmio_axi_arcache,
    output     [2:0]                    mmio_axi_arprot,

    // MMIO read data channel.
    input                               mmio_axi_rvalid,
    output                              mmio_axi_rready,
    input      [MMIO_AXI_ID_BITS-1:0]   mmio_axi_rid,
    input      [MMIO_AXI_DATA_BITS-1:0] mmio_axi_rdata,
    input      [1:0]                    mmio_axi_rresp,
    input                               mmio_axi_rlast
);

    localparam       AXI_LOCK_NORMAL        = 1'b0;
    localparam [3:0] AXI_CACHE_LEGACY_FIXED = 4'b0000;
    localparam [2:0] AXI_PROT_LEGACY_FIXED  = 3'b111;

    genvar fetch_idx;

    assign global_reset = ~aresetn;

    // The CPU-facing memory handshake wires below are driven/sampled in the
    // cpu_clk domain. axi_subsystem_top receives both clocks so its future
    // real implementation can hold those handshakes on low-frequency
    // boundaries while running LLC/DDR logic in the aclk domain.

    // ---------------------------------------------------------------------
    // Frontend <-> backend branch, fetch, and CSR wiring.
    // ---------------------------------------------------------------------
    wire                                  front_FIFO_valid;
    wire                                  front_commit_stall;
    wire [FETCH_WIDTH*PC_BITS-1:0]        front_pc;
    wire [FETCH_WIDTH*INST_BITS-1:0]      front_instructions;
    wire [FETCH_WIDTH-1:0]                front_inst_valid;
    wire [FETCH_WIDTH-1:0]                front_predict_dir;
    wire [PC_BITS-1:0]                    front_predict_next_fetch_address;
    wire [FETCH_WIDTH*PC_BITS-1:0]        front_predict_next_fetch_address_vec;
    wire [FETCH_WIDTH-1:0]                front_alt_pred;
    wire [FETCH_WIDTH*PCPN_BITS-1:0]      front_altpcpn;
    wire [FETCH_WIDTH*PCPN_BITS-1:0]      front_pcpn;
    wire [FETCH_WIDTH-1:0]                front2pre_valid;
    wire [FETCH_WIDTH-1:0]                front_page_fault_inst;
    wire [FETCH_WIDTH*TN_MAX*TAGE_IDX_BITS-1:0] front_tage_idx;
    wire [FETCH_WIDTH*TN_MAX*TAGE_TAG_BITS-1:0] front_tage_tag;
    wire [FETCH_WIDTH-1:0]                front_sc_used;
    wire [FETCH_WIDTH-1:0]                front_sc_pred;
    wire [FETCH_WIDTH*BPU_SCL_META_SUM_BITS-1:0] front_sc_sum;
    wire [FETCH_WIDTH*BPU_SCL_META_NTABLE*BPU_SCL_META_IDX_BITS-1:0] front_sc_idx;
    wire [FETCH_WIDTH-1:0]                front_loop_used;
    wire [FETCH_WIDTH-1:0]                front_loop_hit;
    wire [FETCH_WIDTH-1:0]                front_loop_pred;
    wire [FETCH_WIDTH*BPU_LOOP_META_IDX_BITS-1:0] front_loop_idx;
    wire [FETCH_WIDTH*BPU_LOOP_META_TAG_BITS-1:0] front_loop_tag;

    wire [FETCH_WIDTH-1:0]                pre2front_fire;
    wire                                  pre2front_ready;
    wire                                  backend_mispred;
    wire                                  backend_stall;
    wire                                  backend_flush;
    wire                                  backend_fence_i;
    wire                                  backend_itlb_flush;
    wire [PC_BITS-1:0]                    backend_redirect_pc;
    wire                                  front_refetch;
    wire                                  front_FIFO_read_enable;

    wire [COMMIT_WIDTH-1:0]               back2front_valid;
    wire [COMMIT_WIDTH*PC_BITS-1:0]       back_predict_base_pc;
    wire [COMMIT_WIDTH-1:0]               back_predict_dir;
    wire [COMMIT_WIDTH-1:0]               back_actual_dir;
    wire [COMMIT_WIDTH*BR_TYPE_BITS-1:0]  back_actual_br_type;
    wire [COMMIT_WIDTH*PC_BITS-1:0]       back_actual_target;
    wire [COMMIT_WIDTH-1:0]               back_alt_pred;
    wire [COMMIT_WIDTH*PCPN_BITS-1:0]     back_altpcpn;
    wire [COMMIT_WIDTH*PCPN_BITS-1:0]     back_pcpn;
    wire [COMMIT_WIDTH*TN_MAX*TAGE_IDX_BITS-1:0] back_tage_idx;
    wire [COMMIT_WIDTH*TN_MAX*TAGE_TAG_BITS-1:0] back_tage_tag;
    wire [COMMIT_WIDTH-1:0]               back_sc_used;
    wire [COMMIT_WIDTH-1:0]               back_sc_pred;
    wire [COMMIT_WIDTH*BPU_SCL_META_SUM_BITS-1:0] back_sc_sum;
    wire [COMMIT_WIDTH*BPU_SCL_META_NTABLE*BPU_SCL_META_IDX_BITS-1:0] back_sc_idx;
    wire [COMMIT_WIDTH-1:0]               back_loop_used;
    wire [COMMIT_WIDTH-1:0]               back_loop_hit;
    wire [COMMIT_WIDTH-1:0]               back_loop_pred;
    wire [COMMIT_WIDTH*BPU_LOOP_META_IDX_BITS-1:0] back_loop_idx;
    wire [COMMIT_WIDTH*BPU_LOOP_META_TAG_BITS-1:0] back_loop_tag;

    wire [CSR_BITS-1:0]                   csr_status_sstatus;
    wire [CSR_BITS-1:0]                   csr_status_mstatus;
    wire [CSR_BITS-1:0]                   csr_status_satp;
    wire [PRIVILEGE_BITS-1:0]             csr_status_privilege;

    generate
        for (fetch_idx = 0; fetch_idx < FETCH_WIDTH; fetch_idx = fetch_idx + 1) begin : gen_front2pre_valid
            if (fetch_idx == 0) begin : gen_first_fetch_slot
                assign front2pre_valid[fetch_idx] = front_FIFO_valid & front_inst_valid[fetch_idx];
            end else begin : gen_later_fetch_slot
                assign front2pre_valid[fetch_idx] =
                    front_FIFO_valid & front_inst_valid[fetch_idx] &
                    ~(|front_predict_dir[fetch_idx-1:0]);
            end
        end
    endgenerate

    assign front_predict_next_fetch_address_vec = {FETCH_WIDTH{front_predict_next_fetch_address}};
    assign front_refetch = backend_mispred | backend_flush;
    assign front_FIFO_read_enable = (~backend_stall) | backend_mispred | backend_flush;

    // ---------------------------------------------------------------------
    // Frontend <-> mem-subsystem storage-side refill/probe and PTW wiring.
    // ---------------------------------------------------------------------
    wire                                  icache_llc_read_req_valid;
    wire                                  icache_llc_read_req_ready;
    wire                                  icache_llc_read_req_accepted;
    wire [ID_BITS-1:0]                    icache_llc_read_req_accepted_id;
    wire [ADDR_BITS-1:0]                  icache_llc_read_req_addr;
    wire [7:0]                            icache_llc_read_req_total_size;
    wire [ID_BITS-1:0]                    icache_llc_read_req_id;
    wire                                  icache_llc_read_req_bypass;
    wire                                  icache_llc_read_resp_valid;
    wire                                  icache_llc_read_resp_ready;
    wire [READ_RESP_BITS-1:0]             icache_llc_read_resp_data;
    wire [ID_BITS-1:0]                    icache_llc_read_resp_id;

    wire                                  icache_dcache_req_valid;
    wire [ADDR_BITS-1:0]                  icache_dcache_req_addr;
    wire                                  dcache_icache_resp_valid;
    wire                                  dcache_icache_resp_miss;
    wire [DATA_BITS-1:0]                  dcache_icache_resp_data;

    wire                                  itlb_ptw_mem_req_valid;
    wire [ADDR_BITS-1:0]                  itlb_ptw_mem_req_addr;
    wire                                  itlb_ptw_mem_resp_consumed;
    wire                                  itlb_ptw_mem_req_ready;
    wire                                  itlb_ptw_mem_resp_valid;
    wire [DATA_BITS-1:0]                  itlb_ptw_mem_resp_data;
    wire                                  itlb_walk_req_valid;
    wire [ADDR_BITS-1:0]                  itlb_walk_req_vaddr;
    wire [CSR_BITS-1:0]                   itlb_walk_req_satp;
    wire [PTW_ACCESS_TYPE_BITS-1:0]        itlb_walk_req_access_type;
    wire                                  itlb_walk_resp_consumed;
    wire                                  itlb_walk_flush;
    wire                                  itlb_walk_req_ready;
    wire                                  itlb_walk_resp_valid;
    wire                                  itlb_walk_resp_fault;
    wire [ADDR_BITS-1:0]                  itlb_walk_resp_vaddr;
    wire [PTE_BITS-1:0]                   itlb_walk_resp_leaf_pte;
    wire [PTW_LEVEL_BITS-1:0]             itlb_walk_resp_leaf_level;

    wire                                  peripheral_req_is_mmio;
    wire                                  peripheral_req_wen;
    wire [ADDR_BITS-1:0]                  peripheral_req_mmio_addr;
    wire [DATA_BITS-1:0]                  peripheral_req_mmio_wdata;
    wire [2:0]                            peripheral_req_mmio_fun3;
    wire                                  peripheral_resp_is_mmio;
    wire                                  peripheral_resp_ready;
    wire [DATA_BITS-1:0]                  peripheral_resp_mmio_rdata;

    wire                                  dtlb_ptw_mem_req_valid;
    wire [ADDR_BITS-1:0]                  dtlb_ptw_mem_req_addr;
    wire                                  dtlb_ptw_mem_resp_consumed;
    wire                                  dtlb_ptw_mem_req_ready;
    wire                                  dtlb_ptw_mem_resp_valid;
    wire [DATA_BITS-1:0]                  dtlb_ptw_mem_resp_data;
    wire                                  dtlb_walk_req_valid;
    wire [ADDR_BITS-1:0]                  dtlb_walk_req_vaddr;
    wire [CSR_BITS-1:0]                   dtlb_walk_req_satp;
    wire [PTW_ACCESS_TYPE_BITS-1:0]       dtlb_walk_req_access_type;
    wire                                  dtlb_walk_resp_consumed;
    wire                                  dtlb_walk_flush;
    wire                                  dtlb_walk_req_ready;
    wire                                  dtlb_walk_resp_valid;
    wire                                  dtlb_walk_resp_fault;
    wire [ADDR_BITS-1:0]                  dtlb_walk_resp_vaddr;
    wire [PTE_BITS-1:0]                   dtlb_walk_resp_leaf_pte;
    wire [PTW_LEVEL_BITS-1:0]             dtlb_walk_resp_leaf_level;

    wire [LSU_LDU_COUNT-1:0]              lsu2dcache_load_ports_valid;
    wire [LSU_LDU_COUNT*ADDR_BITS-1:0]    lsu2dcache_load_ports_addr;
    wire [LSU_LDU_COUNT*LSU_REQ_ID_BITS-1:0] lsu2dcache_load_ports_req_id;
    wire [LSU_STA_COUNT-1:0]              lsu2dcache_store_ports_valid;
    wire [LSU_STA_COUNT*ADDR_BITS-1:0]    lsu2dcache_store_ports_addr;
    wire [LSU_STA_COUNT*DATA_BITS-1:0]    lsu2dcache_store_ports_data;
    wire [LSU_STA_COUNT*STRB_BITS-1:0]    lsu2dcache_store_ports_strb;
    wire [LSU_STA_COUNT*LSU_REQ_ID_BITS-1:0] lsu2dcache_store_ports_req_id;
    wire [LSU_LDU_WIDTH:0]                lsu2dcache_icache_req;
    wire [LSU_LDU_COUNT-1:0]              dcache2lsu_load_resps_valid;
    wire [LSU_LDU_COUNT*DATA_BITS-1:0]    dcache2lsu_load_resps_data;
    wire [LSU_LDU_COUNT*LSU_REQ_ID_BITS-1:0] dcache2lsu_load_resps_req_id;
    wire [LSU_LDU_COUNT*REPLAY_BITS-1:0]  dcache2lsu_load_resps_replay;
    wire [LSU_STA_COUNT-1:0]              dcache2lsu_store_resps_valid;
    wire [LSU_STA_COUNT*REPLAY_BITS-1:0]  dcache2lsu_store_resps_replay;
    wire [LSU_STA_COUNT*LSU_REQ_ID_BITS-1:0] dcache2lsu_store_resps_req_id;
    wire                                  dcache2lsu_mshr_fill;

    // ---------------------------------------------------------------------
    // Mem subsystem <-> AXI-subsystem upstream wiring.
    // ---------------------------------------------------------------------
    wire [NUM_READ_MASTERS-1:0]           read_req_valid;
    wire [NUM_READ_MASTERS-1:0]           read_req_ready;
    wire [NUM_READ_MASTERS-1:0]           read_req_accepted;
    wire [NUM_READ_MASTERS*ID_BITS-1:0]   read_req_accepted_id;
    wire [NUM_READ_MASTERS*ADDR_BITS-1:0] read_req_addr;
    wire [NUM_READ_MASTERS*8-1:0]         read_req_total_size;
    wire [NUM_READ_MASTERS*ID_BITS-1:0]   read_req_id;
    wire [NUM_READ_MASTERS-1:0]           read_req_bypass;
    wire [NUM_READ_MASTERS-1:0]           read_resp_valid;
    wire [NUM_READ_MASTERS-1:0]           read_resp_ready;
    wire [NUM_READ_MASTERS*READ_RESP_BITS-1:0] read_resp_data;
    wire [NUM_READ_MASTERS*ID_BITS-1:0]   read_resp_id;

    wire [NUM_WRITE_MASTERS-1:0]          write_req_valid;
    wire [NUM_WRITE_MASTERS-1:0]          write_req_ready;
    wire [NUM_WRITE_MASTERS-1:0]          write_req_accepted;
    wire [NUM_WRITE_MASTERS*ADDR_BITS-1:0] write_req_addr;
    wire [NUM_WRITE_MASTERS*LINE_BITS-1:0] write_req_wdata;
    wire [NUM_WRITE_MASTERS*LINE_BYTES-1:0] write_req_wstrb;
    wire [NUM_WRITE_MASTERS*8-1:0]        write_req_total_size;
    wire [NUM_WRITE_MASTERS*ID_BITS-1:0]  write_req_id;
    wire [NUM_WRITE_MASTERS-1:0]          write_req_bypass;
    wire [NUM_WRITE_MASTERS-1:0]          write_resp_valid;
    wire [NUM_WRITE_MASTERS-1:0]          write_resp_ready;
    wire [NUM_WRITE_MASTERS*ID_BITS-1:0]  write_resp_id;
    wire [NUM_WRITE_MASTERS*2-1:0]        write_resp_code;

    frontend_top #(
        .USE_TRAIN(USE_TRAIN),
        .RESET_PC(RESET_PC),
        .FETCH_WIDTH(FETCH_WIDTH),
        .COMMIT_WIDTH(COMMIT_WIDTH),
        .ICACHE_LINE_BYTES(ICACHE_LINE_BYTES),
        .ICACHE_SET_COUNT(ICACHE_SET_COUNT),
        .ICACHE_WAY_COUNT(ICACHE_WAY_COUNT),
        .ITLB_ENTRIES(ITLB_ENTRIES),
        .TN_MAX(TN_MAX),
        .PC_BITS(PC_BITS),
        .INST_BITS(INST_BITS),
        .ADDR_BITS(ADDR_BITS),
        .DATA_BITS(DATA_BITS),
        .ID_BITS(ID_BITS),
        .MODE_BITS(MODE_BITS),
        .READ_RESP_BITS(READ_RESP_BITS),
        .CSR_BITS(CSR_BITS),
        .PRIVILEGE_BITS(PRIVILEGE_BITS),
        .PCPN_BITS(PCPN_BITS),
        .BR_TYPE_BITS(BR_TYPE_BITS),
        .TAGE_IDX_BITS(TAGE_IDX_BITS),
        .TAGE_TAG_BITS(TAGE_TAG_BITS),
        .BPU_SCL_META_NTABLE(BPU_SCL_META_NTABLE),
        .BPU_SCL_META_IDX_BITS(BPU_SCL_META_IDX_BITS),
        .BPU_SCL_META_SUM_BITS(BPU_SCL_META_SUM_BITS),
        .BPU_LOOP_META_IDX_BITS(BPU_LOOP_META_IDX_BITS),
        .BPU_LOOP_META_TAG_BITS(BPU_LOOP_META_TAG_BITS),
        .PTW_ACCESS_TYPE_BITS(PTW_ACCESS_TYPE_BITS),
        .PTW_LEVEL_BITS(PTW_LEVEL_BITS),
        .PTE_BITS(PTE_BITS),
        .MMU_RESULT_BITS(MMU_RESULT_BITS)
    ) u_frontend_top (
        .aclk(cpu_clk),
        .aresetn(aresetn),
        .reset(global_reset),
        .mode(mode),
        .refetch(front_refetch),
        .itlb_flush(backend_itlb_flush),
        .fence_i(backend_fence_i),
        .refetch_address(backend_redirect_pc),
        .csr_status_sstatus(csr_status_sstatus),
        .csr_status_mstatus(csr_status_mstatus),
        .csr_status_satp(csr_status_satp),
        .csr_status_privilege(csr_status_privilege),
        .FIFO_read_enable(front_FIFO_read_enable),
        .back2front_valid(back2front_valid),
        .predict_base_pc(back_predict_base_pc),
        .predict_dir(back_predict_dir),
        .actual_dir(back_actual_dir),
        .actual_br_type(back_actual_br_type),
        .actual_target(back_actual_target),
        .alt_pred(back_alt_pred),
        .altpcpn(back_altpcpn),
        .pcpn(back_pcpn),
        .tage_idx(back_tage_idx),
        .tage_tag(back_tage_tag),
        .sc_used(back_sc_used),
        .sc_pred(back_sc_pred),
        .sc_sum(back_sc_sum),
        .sc_idx(back_sc_idx),
        .loop_used(back_loop_used),
        .loop_hit(back_loop_hit),
        .loop_pred(back_loop_pred),
        .loop_idx(back_loop_idx),
        .loop_tag(back_loop_tag),
        .FIFO_valid(front_FIFO_valid),
        .commit_stall(front_commit_stall),
        .pc(front_pc),
        .instructions(front_instructions),
        .inst_valid(front_inst_valid),
        .out_predict_dir(front_predict_dir),
        .predict_next_fetch_address(front_predict_next_fetch_address),
        .out_alt_pred(front_alt_pred),
        .out_altpcpn(front_altpcpn),
        .out_pcpn(front_pcpn),
        .page_fault_inst(front_page_fault_inst),
        .out_tage_idx(front_tage_idx),
        .out_tage_tag(front_tage_tag),
        .out_sc_used(front_sc_used),
        .out_sc_pred(front_sc_pred),
        .out_sc_sum(front_sc_sum),
        .out_sc_idx(front_sc_idx),
        .out_loop_used(front_loop_used),
        .out_loop_hit(front_loop_hit),
        .out_loop_pred(front_loop_pred),
        .out_loop_idx(front_loop_idx),
        .out_loop_tag(front_loop_tag),
        .icache_llc_read_req_valid(icache_llc_read_req_valid),
        .icache_llc_read_req_ready(icache_llc_read_req_ready),
        .icache_llc_read_req_accepted(icache_llc_read_req_accepted),
        .icache_llc_read_req_accepted_id(icache_llc_read_req_accepted_id),
        .icache_llc_read_req_addr(icache_llc_read_req_addr),
        .icache_llc_read_req_total_size(icache_llc_read_req_total_size),
        .icache_llc_read_req_id(icache_llc_read_req_id),
        .icache_llc_read_req_bypass(icache_llc_read_req_bypass),
        .icache_llc_read_resp_valid(icache_llc_read_resp_valid),
        .icache_llc_read_resp_ready(icache_llc_read_resp_ready),
        .icache_llc_read_resp_data(icache_llc_read_resp_data),
        .icache_llc_read_resp_id(icache_llc_read_resp_id),
        .icache_dcache_req_valid(icache_dcache_req_valid),
        .icache_dcache_req_addr(icache_dcache_req_addr),
        .dcache_icache_resp_valid(dcache_icache_resp_valid),
        .dcache_icache_resp_miss(dcache_icache_resp_miss),
        .dcache_icache_resp_data(dcache_icache_resp_data),
        .itlb_ptw_mem_req_valid(itlb_ptw_mem_req_valid),
        .itlb_ptw_mem_req_addr(itlb_ptw_mem_req_addr),
        .itlb_ptw_mem_resp_consumed(itlb_ptw_mem_resp_consumed),
        .itlb_ptw_mem_req_ready(itlb_ptw_mem_req_ready),
        .itlb_ptw_mem_resp_valid(itlb_ptw_mem_resp_valid),
        .itlb_ptw_mem_resp_data(itlb_ptw_mem_resp_data),
        .itlb_walk_req_valid(itlb_walk_req_valid),
        .itlb_walk_req_vaddr(itlb_walk_req_vaddr),
        .itlb_walk_req_satp(itlb_walk_req_satp),
        .itlb_walk_req_access_type(itlb_walk_req_access_type),
        .itlb_walk_resp_consumed(itlb_walk_resp_consumed),
        .itlb_walk_flush(itlb_walk_flush),
        .itlb_walk_req_ready(itlb_walk_req_ready),
        .itlb_walk_resp_valid(itlb_walk_resp_valid),
        .itlb_walk_resp_fault(itlb_walk_resp_fault),
        .itlb_walk_resp_vaddr(itlb_walk_resp_vaddr),
        .itlb_walk_resp_leaf_pte(itlb_walk_resp_leaf_pte),
        .itlb_walk_resp_leaf_level(itlb_walk_resp_leaf_level)
    );

    backend_top #(
        .FETCH_WIDTH(FETCH_WIDTH),
        .DECODE_WIDTH(DECODE_WIDTH),
        .COMMIT_WIDTH(COMMIT_WIDTH),
        .ISSUE_WIDTH(ISSUE_WIDTH),
        .ALU_NUM(ALU_NUM),
        .BRU_NUM(BRU_NUM),
        .ROB_NUM(ROB_NUM),
        .LDQ_SIZE(LDQ_SIZE),
        .STQ_SIZE(STQ_SIZE),
        .LOAD_WINDOWS_WIDTH(LOAD_WINDOWS_WIDTH),
        .STORE_WINDOWS_WIDTH(STORE_WINDOWS_WIDTH),
        .TN_MAX(TN_MAX),
        .PC_BITS(PC_BITS),
        .INST_BITS(INST_BITS),
        .ADDR_BITS(ADDR_BITS),
        .DATA_BITS(DATA_BITS),
        .STRB_BITS(STRB_BITS),
        .CSR_BITS(CSR_BITS),
        .PRIVILEGE_BITS(PRIVILEGE_BITS),
        .PCPN_BITS(PCPN_BITS),
        .BR_TYPE_BITS(BR_TYPE_BITS),
        .TAGE_IDX_BITS(TAGE_IDX_BITS),
        .TAGE_TAG_BITS(TAGE_TAG_BITS),
        .BPU_SCL_META_NTABLE(BPU_SCL_META_NTABLE),
        .BPU_SCL_META_IDX_BITS(BPU_SCL_META_IDX_BITS),
        .BPU_SCL_META_SUM_BITS(BPU_SCL_META_SUM_BITS),
        .BPU_LOOP_META_IDX_BITS(BPU_LOOP_META_IDX_BITS),
        .BPU_LOOP_META_TAG_BITS(BPU_LOOP_META_TAG_BITS),
        .LSU_LDU_COUNT(LSU_LDU_COUNT),
        .LSU_STA_COUNT(LSU_STA_COUNT),
        .LSU_SDU_COUNT(LSU_SDU_COUNT),
        .LSU_LDU_WIDTH(LSU_LDU_WIDTH),
        .LSU_REQ_ID_BITS(LSU_REQ_ID_BITS),
        .REPLAY_BITS(REPLAY_BITS),
        .MMU_RESULT_BITS(MMU_RESULT_BITS),
        .DTLB_ENTRIES(DTLB_ENTRIES),
        .PTW_ACCESS_TYPE_BITS(PTW_ACCESS_TYPE_BITS),
        .PTW_LEVEL_BITS(PTW_LEVEL_BITS),
        .PTE_BITS(PTE_BITS)
    ) u_backend_top (
        .aclk(cpu_clk),
        .aresetn(aresetn),
        .front2pre_inst(front_instructions),
        .front2pre_pc(front_pc),
        .front2pre_valid(front2pre_valid),
        .front2pre_front_stall(front_commit_stall),
        .front2pre_predict_dir(front_predict_dir),
        .front2pre_alt_pred(front_alt_pred),
        .front2pre_altpcpn(front_altpcpn),
        .front2pre_pcpn(front_pcpn),
        .front2pre_predict_next_fetch_address(front_predict_next_fetch_address_vec),
        .front2pre_tage_idx(front_tage_idx),
        .front2pre_tage_tag(front_tage_tag),
        .front2pre_sc_used(front_sc_used),
        .front2pre_sc_pred(front_sc_pred),
        .front2pre_sc_sum(front_sc_sum),
        .front2pre_sc_idx(front_sc_idx),
        .front2pre_loop_used(front_loop_used),
        .front2pre_loop_hit(front_loop_hit),
        .front2pre_loop_pred(front_loop_pred),
        .front2pre_loop_idx(front_loop_idx),
        .front2pre_loop_tag(front_loop_tag),
        .front2pre_page_fault_inst(front_page_fault_inst),
        .pre2front_fire(pre2front_fire),
        .pre2front_ready(pre2front_ready),
        .mispred(backend_mispred),
        .stall(backend_stall),
        .flush(backend_flush),
        .fence_i(backend_fence_i),
        .itlb_flush(backend_itlb_flush),
        .redirect_pc(backend_redirect_pc),
        .back2front_valid(back2front_valid),
        .predict_base_pc(back_predict_base_pc),
        .predict_dir(back_predict_dir),
        .actual_dir(back_actual_dir),
        .actual_br_type(back_actual_br_type),
        .actual_target(back_actual_target),
        .alt_pred(back_alt_pred),
        .altpcpn(back_altpcpn),
        .pcpn(back_pcpn),
        .tage_idx(back_tage_idx),
        .tage_tag(back_tage_tag),
        .sc_used(back_sc_used),
        .sc_pred(back_sc_pred),
        .sc_sum(back_sc_sum),
        .sc_idx(back_sc_idx),
        .loop_used(back_loop_used),
        .loop_hit(back_loop_hit),
        .loop_pred(back_loop_pred),
        .loop_idx(back_loop_idx),
        .loop_tag(back_loop_tag),
        .csr_status_sstatus(csr_status_sstatus),
        .csr_status_mstatus(csr_status_mstatus),
        .csr_status_satp(csr_status_satp),
        .csr_status_privilege(csr_status_privilege),
        .peripheral_req_is_mmio(peripheral_req_is_mmio),
        .peripheral_req_wen(peripheral_req_wen),
        .peripheral_req_mmio_addr(peripheral_req_mmio_addr),
        .peripheral_req_mmio_wdata(peripheral_req_mmio_wdata),
        .peripheral_req_mmio_fun3(peripheral_req_mmio_fun3),
        .peripheral_resp_is_mmio(peripheral_resp_is_mmio),
        .peripheral_resp_ready(peripheral_resp_ready),
        .peripheral_resp_mmio_rdata(peripheral_resp_mmio_rdata),
        .dtlb_ptw_mem_req_valid(dtlb_ptw_mem_req_valid),
        .dtlb_ptw_mem_req_addr(dtlb_ptw_mem_req_addr),
        .dtlb_ptw_mem_resp_consumed(dtlb_ptw_mem_resp_consumed),
        .dtlb_ptw_mem_req_ready(dtlb_ptw_mem_req_ready),
        .dtlb_ptw_mem_resp_valid(dtlb_ptw_mem_resp_valid),
        .dtlb_ptw_mem_resp_data(dtlb_ptw_mem_resp_data),
        .dtlb_walk_req_valid(dtlb_walk_req_valid),
        .dtlb_walk_req_vaddr(dtlb_walk_req_vaddr),
        .dtlb_walk_req_satp(dtlb_walk_req_satp),
        .dtlb_walk_req_access_type(dtlb_walk_req_access_type),
        .dtlb_walk_resp_consumed(dtlb_walk_resp_consumed),
        .dtlb_walk_flush(dtlb_walk_flush),
        .dtlb_walk_req_ready(dtlb_walk_req_ready),
        .dtlb_walk_resp_valid(dtlb_walk_resp_valid),
        .dtlb_walk_resp_fault(dtlb_walk_resp_fault),
        .dtlb_walk_resp_vaddr(dtlb_walk_resp_vaddr),
        .dtlb_walk_resp_leaf_pte(dtlb_walk_resp_leaf_pte),
        .dtlb_walk_resp_leaf_level(dtlb_walk_resp_leaf_level),
        .lsu2dcache_load_ports_valid(lsu2dcache_load_ports_valid),
        .lsu2dcache_load_ports_addr(lsu2dcache_load_ports_addr),
        .lsu2dcache_load_ports_req_id(lsu2dcache_load_ports_req_id),
        .lsu2dcache_store_ports_valid(lsu2dcache_store_ports_valid),
        .lsu2dcache_store_ports_addr(lsu2dcache_store_ports_addr),
        .lsu2dcache_store_ports_data(lsu2dcache_store_ports_data),
        .lsu2dcache_store_ports_strb(lsu2dcache_store_ports_strb),
        .lsu2dcache_store_ports_req_id(lsu2dcache_store_ports_req_id),
        .lsu2dcache_icache_req(lsu2dcache_icache_req),
        .dcache2lsu_load_resps_valid(dcache2lsu_load_resps_valid),
        .dcache2lsu_load_resps_data(dcache2lsu_load_resps_data),
        .dcache2lsu_load_resps_req_id(dcache2lsu_load_resps_req_id),
        .dcache2lsu_load_resps_replay(dcache2lsu_load_resps_replay),
        .dcache2lsu_store_resps_valid(dcache2lsu_store_resps_valid),
        .dcache2lsu_store_resps_replay(dcache2lsu_store_resps_replay),
        .dcache2lsu_store_resps_req_id(dcache2lsu_store_resps_req_id),
        .dcache2lsu_mshr_fill(dcache2lsu_mshr_fill)
    );

    mem_subsystem_top #(
        .ADDR_BITS(ADDR_BITS),
        .DATA_BITS(DATA_BITS),
        .STRB_BITS(STRB_BITS),
        .CSR_BITS(CSR_BITS),
        .PRIVILEGE_BITS(PRIVILEGE_BITS),
        .LSU_LDU_COUNT(LSU_LDU_COUNT),
        .LSU_STA_COUNT(LSU_STA_COUNT),
        .LSU_LDU_WIDTH(LSU_LDU_WIDTH),
        .LSU_REQ_ID_BITS(LSU_REQ_ID_BITS),
        .REPLAY_BITS(REPLAY_BITS),
        .DCACHE_LINE_BYTES(DCACHE_LINE_BYTES),
        .DCACHE_SET_COUNT(DCACHE_SET_COUNT),
        .DCACHE_WAY_COUNT(DCACHE_WAY_COUNT),
        .DCACHE_MSHR_ENTRIES(DCACHE_MSHR_ENTRIES),
        .DCACHE_WB_ENTRIES(DCACHE_WB_ENTRIES),
        .PTW_ACCESS_TYPE_BITS(PTW_ACCESS_TYPE_BITS),
        .PTW_LEVEL_BITS(PTW_LEVEL_BITS),
        .PTE_BITS(PTE_BITS),
        .NUM_READ_MASTERS(NUM_READ_MASTERS),
        .NUM_WRITE_MASTERS(NUM_WRITE_MASTERS),
        .ID_BITS(ID_BITS),
        .MODE_BITS(MODE_BITS),
        .LINE_BITS(LINE_BITS),
        .LINE_BYTES(LINE_BYTES),
        .READ_RESP_BITS(READ_RESP_BITS)
    ) u_mem_subsystem_top (
        .clk(cpu_clk),
        .rst_n(aresetn),
        .mode(mode),
        .icache_llc_read_req_valid(icache_llc_read_req_valid),
        .icache_llc_read_req_ready(icache_llc_read_req_ready),
        .icache_llc_read_req_accepted(icache_llc_read_req_accepted),
        .icache_llc_read_req_accepted_id(icache_llc_read_req_accepted_id),
        .icache_llc_read_req_addr(icache_llc_read_req_addr),
        .icache_llc_read_req_total_size(icache_llc_read_req_total_size),
        .icache_llc_read_req_id(icache_llc_read_req_id),
        .icache_llc_read_req_bypass(icache_llc_read_req_bypass),
        .icache_llc_read_resp_valid(icache_llc_read_resp_valid),
        .icache_llc_read_resp_ready(icache_llc_read_resp_ready),
        .icache_llc_read_resp_data(icache_llc_read_resp_data),
        .icache_llc_read_resp_id(icache_llc_read_resp_id),
        .icache_dcache_req_valid(icache_dcache_req_valid),
        .icache_dcache_req_addr(icache_dcache_req_addr),
        .dcache_icache_resp_valid(dcache_icache_resp_valid),
        .dcache_icache_resp_miss(dcache_icache_resp_miss),
        .dcache_icache_resp_data(dcache_icache_resp_data),
        .csr_status_sstatus(csr_status_sstatus),
        .csr_status_mstatus(csr_status_mstatus),
        .csr_status_satp(csr_status_satp),
        .csr_status_privilege(csr_status_privilege),
        .dtlb_ptw_mem_req_valid(dtlb_ptw_mem_req_valid),
        .dtlb_ptw_mem_req_addr(dtlb_ptw_mem_req_addr),
        .dtlb_ptw_mem_resp_consumed(dtlb_ptw_mem_resp_consumed),
        .dtlb_ptw_mem_req_ready(dtlb_ptw_mem_req_ready),
        .dtlb_ptw_mem_resp_valid(dtlb_ptw_mem_resp_valid),
        .dtlb_ptw_mem_resp_data(dtlb_ptw_mem_resp_data),
        .dtlb_walk_req_valid(dtlb_walk_req_valid),
        .dtlb_walk_req_vaddr(dtlb_walk_req_vaddr),
        .dtlb_walk_req_satp(dtlb_walk_req_satp),
        .dtlb_walk_req_access_type(dtlb_walk_req_access_type),
        .dtlb_walk_resp_consumed(dtlb_walk_resp_consumed),
        .dtlb_walk_flush(dtlb_walk_flush),
        .dtlb_walk_req_ready(dtlb_walk_req_ready),
        .dtlb_walk_resp_valid(dtlb_walk_resp_valid),
        .dtlb_walk_resp_fault(dtlb_walk_resp_fault),
        .dtlb_walk_resp_vaddr(dtlb_walk_resp_vaddr),
        .dtlb_walk_resp_leaf_pte(dtlb_walk_resp_leaf_pte),
        .dtlb_walk_resp_leaf_level(dtlb_walk_resp_leaf_level),
        .lsu2dcache_load_ports_valid(lsu2dcache_load_ports_valid),
        .lsu2dcache_load_ports_addr(lsu2dcache_load_ports_addr),
        .lsu2dcache_load_ports_req_id(lsu2dcache_load_ports_req_id),
        .lsu2dcache_store_ports_valid(lsu2dcache_store_ports_valid),
        .lsu2dcache_store_ports_addr(lsu2dcache_store_ports_addr),
        .lsu2dcache_store_ports_data(lsu2dcache_store_ports_data),
        .lsu2dcache_store_ports_strb(lsu2dcache_store_ports_strb),
        .lsu2dcache_store_ports_req_id(lsu2dcache_store_ports_req_id),
        .lsu2dcache_icache_req(lsu2dcache_icache_req),
        .dcache2lsu_load_resps_valid(dcache2lsu_load_resps_valid),
        .dcache2lsu_load_resps_data(dcache2lsu_load_resps_data),
        .dcache2lsu_load_resps_req_id(dcache2lsu_load_resps_req_id),
        .dcache2lsu_load_resps_replay(dcache2lsu_load_resps_replay),
        .dcache2lsu_store_resps_valid(dcache2lsu_store_resps_valid),
        .dcache2lsu_store_resps_replay(dcache2lsu_store_resps_replay),
        .dcache2lsu_store_resps_req_id(dcache2lsu_store_resps_req_id),
        .dcache2lsu_mshr_fill(dcache2lsu_mshr_fill),
        .peripheral_req_is_mmio(peripheral_req_is_mmio),
        .peripheral_req_wen(peripheral_req_wen),
        .peripheral_req_mmio_addr(peripheral_req_mmio_addr),
        .peripheral_req_mmio_wdata(peripheral_req_mmio_wdata),
        .peripheral_req_mmio_fun3(peripheral_req_mmio_fun3),
        .peripheral_resp_is_mmio(peripheral_resp_is_mmio),
        .peripheral_resp_ready(peripheral_resp_ready),
        .peripheral_resp_mmio_rdata(peripheral_resp_mmio_rdata),
        .itlb_ptw_mem_req_valid(itlb_ptw_mem_req_valid),
        .itlb_ptw_mem_req_addr(itlb_ptw_mem_req_addr),
        .itlb_ptw_mem_resp_consumed(itlb_ptw_mem_resp_consumed),
        .itlb_ptw_mem_req_ready(itlb_ptw_mem_req_ready),
        .itlb_ptw_mem_resp_valid(itlb_ptw_mem_resp_valid),
        .itlb_ptw_mem_resp_data(itlb_ptw_mem_resp_data),
        .itlb_walk_req_valid(itlb_walk_req_valid),
        .itlb_walk_req_vaddr(itlb_walk_req_vaddr),
        .itlb_walk_req_satp(itlb_walk_req_satp),
        .itlb_walk_req_access_type(itlb_walk_req_access_type),
        .itlb_walk_resp_consumed(itlb_walk_resp_consumed),
        .itlb_walk_flush(itlb_walk_flush),
        .itlb_walk_req_ready(itlb_walk_req_ready),
        .itlb_walk_resp_valid(itlb_walk_resp_valid),
        .itlb_walk_resp_fault(itlb_walk_resp_fault),
        .itlb_walk_resp_vaddr(itlb_walk_resp_vaddr),
        .itlb_walk_resp_leaf_pte(itlb_walk_resp_leaf_pte),
        .itlb_walk_resp_leaf_level(itlb_walk_resp_leaf_level),
        .read_req_valid(read_req_valid),
        .read_req_ready(read_req_ready),
        .read_req_accepted(read_req_accepted),
        .read_req_accepted_id(read_req_accepted_id),
        .read_req_addr(read_req_addr),
        .read_req_total_size(read_req_total_size),
        .read_req_id(read_req_id),
        .read_req_bypass(read_req_bypass),
        .read_resp_valid(read_resp_valid),
        .read_resp_ready(read_resp_ready),
        .read_resp_data(read_resp_data),
        .read_resp_id(read_resp_id),
        .write_req_valid(write_req_valid),
        .write_req_ready(write_req_ready),
        .write_req_accepted(write_req_accepted),
        .write_req_addr(write_req_addr),
        .write_req_wdata(write_req_wdata),
        .write_req_wstrb(write_req_wstrb),
        .write_req_total_size(write_req_total_size),
        .write_req_id(write_req_id),
        .write_req_bypass(write_req_bypass),
        .write_resp_valid(write_resp_valid),
        .write_resp_ready(write_resp_ready),
        .write_resp_id(write_resp_id),
        .write_resp_code(write_resp_code)
    );

    axi_subsystem_top #(
        .ADDR_BITS(ADDR_BITS),
        .ID_BITS(ID_BITS),
        .SLOT_ID_BITS(SLOT_ID_BITS),
        .MODE_BITS(MODE_BITS),
        .LINE_BYTES(LINE_BYTES),
        .LINE_BITS(LINE_BITS),
        .LINE_OFFSET_BITS(LINE_OFFSET_BITS),
        .FPGA_KB_LLC(FPGA_KB_LLC),
        .SET_COUNT(SET_COUNT),
        .SET_BITS(SET_BITS),
        .WAY_COUNT(WAY_COUNT),
        .WAY_BITS(WAY_BITS),
        .META_BITS(META_BITS),
        .LLC_SIZE_BYTES(LLC_SIZE_BYTES),
        .WINDOW_BYTES(WINDOW_BYTES),
        .WINDOW_WAYS(WINDOW_WAYS),
        .MMIO_BASE(MMIO_BASE),
        .MMIO_SIZE(MMIO_SIZE),
        .DDR_BASE(DDR_BASE),
        .RESET_MODE(RESET_MODE),
        .RESET_OFFSET(RESET_OFFSET),
        .AXI_SUBSYSTEM_FREQ_DIV(AXI_SUBSYSTEM_FREQ_DIV),
        .USE_SMIC12_STORES(USE_SMIC12_STORES),
        .TABLE_READ_LATENCY(TABLE_READ_LATENCY),
        .NUM_READ_MASTERS(NUM_READ_MASTERS),
        .NUM_WRITE_MASTERS(NUM_WRITE_MASTERS),
        .DDR_AXI_ID_BITS(DDR_AXI_ID_BITS),
        .DDR_AXI_DATA_BYTES(DDR_AXI_DATA_BYTES),
        .DDR_AXI_DATA_BITS(DDR_AXI_DATA_BITS),
        .DDR_AXI_STRB_BITS(DDR_AXI_STRB_BITS),
        .MMIO_AXI_ID_BITS(MMIO_AXI_ID_BITS),
        .MMIO_AXI_DATA_BYTES(MMIO_AXI_DATA_BYTES),
        .MMIO_AXI_DATA_BITS(MMIO_AXI_DATA_BITS),
        .MMIO_AXI_STRB_BITS(MMIO_AXI_STRB_BITS),
        .READ_RESP_BYTES(READ_RESP_BYTES),
        .READ_RESP_BITS(READ_RESP_BITS)
    ) u_axi_subsystem_top (
        .clk(aclk),
        .cpu_clk(cpu_clk),
        .rst_n(aresetn),
        .mode(mode),
        .read_req_valid(read_req_valid),
        .read_req_ready(read_req_ready),
        .read_req_accepted(read_req_accepted),
        .read_req_accepted_id(read_req_accepted_id),
        .read_req_addr(read_req_addr),
        .read_req_total_size(read_req_total_size),
        .read_req_id(read_req_id),
        .read_req_bypass(read_req_bypass),
        .read_resp_valid(read_resp_valid),
        .read_resp_ready(read_resp_ready),
        .read_resp_data(read_resp_data),
        .read_resp_id(read_resp_id),
        .write_req_valid(write_req_valid),
        .write_req_ready(write_req_ready),
        .write_req_accepted(write_req_accepted),
        .write_req_addr(write_req_addr),
        .write_req_wdata(write_req_wdata),
        .write_req_wstrb(write_req_wstrb),
        .write_req_total_size(write_req_total_size),
        .write_req_id(write_req_id),
        .write_req_bypass(write_req_bypass),
        .write_resp_valid(write_resp_valid),
        .write_resp_ready(write_resp_ready),
        .write_resp_id(write_resp_id),
        .write_resp_code(write_resp_code),

        // DDR/SDRAM AXI4 channel wiring to cpu_top external pins.
        .ddr_axi_awvalid(ddr_axi_awvalid),
        .ddr_axi_awready(ddr_axi_awready),
        .ddr_axi_awid(ddr_axi_awid),
        .ddr_axi_awaddr(ddr_axi_awaddr),
        .ddr_axi_awlen(ddr_axi_awlen),
        .ddr_axi_awsize(ddr_axi_awsize),
        .ddr_axi_awburst(ddr_axi_awburst),
        .ddr_axi_wvalid(ddr_axi_wvalid),
        .ddr_axi_wready(ddr_axi_wready),
        .ddr_axi_wdata(ddr_axi_wdata),
        .ddr_axi_wstrb(ddr_axi_wstrb),
        .ddr_axi_wlast(ddr_axi_wlast),
        .ddr_axi_bvalid(ddr_axi_bvalid),
        .ddr_axi_bready(ddr_axi_bready),
        .ddr_axi_bid(ddr_axi_bid),
        .ddr_axi_bresp(ddr_axi_bresp),
        .ddr_axi_arvalid(ddr_axi_arvalid),
        .ddr_axi_arready(ddr_axi_arready),
        .ddr_axi_arid(ddr_axi_arid),
        .ddr_axi_araddr(ddr_axi_araddr),
        .ddr_axi_arlen(ddr_axi_arlen),
        .ddr_axi_arsize(ddr_axi_arsize),
        .ddr_axi_arburst(ddr_axi_arburst),
        .ddr_axi_rvalid(ddr_axi_rvalid),
        .ddr_axi_rready(ddr_axi_rready),
        .ddr_axi_rid(ddr_axi_rid),
        .ddr_axi_rdata(ddr_axi_rdata),
        .ddr_axi_rresp(ddr_axi_rresp),
        .ddr_axi_rlast(ddr_axi_rlast),

        // MMIO AXI4 channel wiring to cpu_top external pins.
        .mmio_axi_awvalid(mmio_axi_awvalid),
        .mmio_axi_awready(mmio_axi_awready),
        .mmio_axi_awid(mmio_axi_awid),
        .mmio_axi_awaddr(mmio_axi_awaddr),
        .mmio_axi_awlen(mmio_axi_awlen),
        .mmio_axi_awsize(mmio_axi_awsize),
        .mmio_axi_awburst(mmio_axi_awburst),
        .mmio_axi_wvalid(mmio_axi_wvalid),
        .mmio_axi_wready(mmio_axi_wready),
        .mmio_axi_wdata(mmio_axi_wdata),
        .mmio_axi_wstrb(mmio_axi_wstrb),
        .mmio_axi_wlast(mmio_axi_wlast),
        .mmio_axi_bvalid(mmio_axi_bvalid),
        .mmio_axi_bready(mmio_axi_bready),
        .mmio_axi_bid(mmio_axi_bid),
        .mmio_axi_bresp(mmio_axi_bresp),
        .mmio_axi_arvalid(mmio_axi_arvalid),
        .mmio_axi_arready(mmio_axi_arready),
        .mmio_axi_arid(mmio_axi_arid),
        .mmio_axi_araddr(mmio_axi_araddr),
        .mmio_axi_arlen(mmio_axi_arlen),
        .mmio_axi_arsize(mmio_axi_arsize),
        .mmio_axi_arburst(mmio_axi_arburst),
        .mmio_axi_rvalid(mmio_axi_rvalid),
        .mmio_axi_rready(mmio_axi_rready),
        .mmio_axi_rid(mmio_axi_rid),
        .mmio_axi_rdata(mmio_axi_rdata),
        .mmio_axi_rresp(mmio_axi_rresp),
        .mmio_axi_rlast(mmio_axi_rlast)
    );

    // Fixed AXI4 attribute tie-offs added at this top boundary. These match
    // the reference RISCV_cpu_top.v defaults for SoC-side attributes. Burst
    // defaults live in axi_subsystem_top because they belong to the channel
    // adapter shell.
    assign ddr_axi_awlock   = AXI_LOCK_NORMAL;
    assign ddr_axi_awcache  = AXI_CACHE_LEGACY_FIXED;
    assign ddr_axi_awprot   = AXI_PROT_LEGACY_FIXED;
    assign ddr_axi_arlock   = AXI_LOCK_NORMAL;
    assign ddr_axi_arcache  = AXI_CACHE_LEGACY_FIXED;
    assign ddr_axi_arprot   = AXI_PROT_LEGACY_FIXED;

    assign mmio_axi_awlock  = AXI_LOCK_NORMAL;
    assign mmio_axi_awcache = AXI_CACHE_LEGACY_FIXED;
    assign mmio_axi_awprot  = AXI_PROT_LEGACY_FIXED;
    assign mmio_axi_arlock  = AXI_LOCK_NORMAL;
    assign mmio_axi_arcache = AXI_CACHE_LEGACY_FIXED;
    assign mmio_axi_arprot  = AXI_PROT_LEGACY_FIXED;

endmodule
