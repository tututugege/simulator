`timescale 1ns / 1ps
`include "axi_llc_params.vh"
`include "qm3_cpu_params.vh"

// RealDcache shell.
//
// TODO:
// 1. Implement RealDcache hit/miss/replay control logic.
// 2. Add data/tag/meta/replacement RAM template boundaries.
// 3. Implement MSHR and write-buffer behavior.
// 4. Implement LLC read refill and writeback request/response paths.
// 5. Implement DCache response generation for LSU, ICache probe, and PTW-routed
//    traffic.
//
// Request/response ports mirror simulator DCacheReqPorts/DCacheRespPorts after
// MemRouteBlock arbitration. LLC read/write ports keep the same naming style as
// the ICache LLC refill path.
module dcache_top #(
    parameter ADDR_BITS              = `AXI_LLC_ADDR_BITS,
    parameter DATA_BITS              = `QM3_DATA_BITS,
    parameter STRB_BITS              = `QM3_STRB_BITS,
    parameter LSU_LDU_COUNT          = `QM3_LSU_LDU_COUNT,
    parameter LSU_STA_COUNT          = `QM3_LSU_STA_COUNT,
    parameter LSU_LDU_WIDTH          = `QM3_LSU_LDU_WIDTH,
    parameter LSU_REQ_ID_BITS        = `QM3_LSU_REQ_ID_BITS,
    parameter REPLAY_BITS            = `QM3_REPLAY_BITS,
    parameter DCACHE_LINE_BYTES      = `QM3_DCACHE_LINE_BYTES,
    parameter DCACHE_SET_COUNT       = `QM3_DCACHE_SET_COUNT,
    parameter DCACHE_WAY_COUNT       = `QM3_DCACHE_WAY_COUNT,
    parameter DCACHE_MSHR_ENTRIES    = `QM3_DCACHE_MSHR_ENTRIES,
    parameter DCACHE_WB_ENTRIES      = `QM3_DCACHE_WB_ENTRIES,
    parameter ID_BITS                = `AXI_LLC_ID_BITS,
    parameter MODE_BITS              = `AXI_LLC_MODE_BITS,
    parameter LINE_BITS              = `AXI_LLC_LINE_BITS,
    parameter LINE_BYTES             = `AXI_LLC_LINE_BYTES,
    parameter READ_RESP_BITS         = `AXI_LLC_READ_RESP_BITS
) (
    input                                   clk,
    input                                   rst_n,
    input      [MODE_BITS-1:0]              mode,

    // DCacheReqPorts from mem_router_top.
    input      [LSU_LDU_COUNT-1:0]          router_dcache_load_ports_valid,
    input      [LSU_LDU_COUNT*ADDR_BITS-1:0] router_dcache_load_ports_addr,
    input      [LSU_LDU_COUNT*LSU_REQ_ID_BITS-1:0] router_dcache_load_ports_req_id,
    input      [LSU_STA_COUNT-1:0]          router_dcache_store_ports_valid,
    input      [LSU_STA_COUNT*ADDR_BITS-1:0] router_dcache_store_ports_addr,
    input      [LSU_STA_COUNT*DATA_BITS-1:0] router_dcache_store_ports_data,
    input      [LSU_STA_COUNT*STRB_BITS-1:0] router_dcache_store_ports_strb,
    input      [LSU_STA_COUNT*LSU_REQ_ID_BITS-1:0] router_dcache_store_ports_req_id,
    input      [LSU_LDU_WIDTH:0]            router_dcache_icache_req,

    // DCacheRespPorts to mem_router_top.
    output     [LSU_LDU_COUNT-1:0]          dcache_router_load_resps_valid,
    output     [LSU_LDU_COUNT*DATA_BITS-1:0] dcache_router_load_resps_data,
    output     [LSU_LDU_COUNT*LSU_REQ_ID_BITS-1:0] dcache_router_load_resps_req_id,
    output     [LSU_LDU_COUNT*REPLAY_BITS-1:0] dcache_router_load_resps_replay,
    output     [LSU_STA_COUNT-1:0]          dcache_router_store_resps_valid,
    output     [LSU_STA_COUNT*REPLAY_BITS-1:0] dcache_router_store_resps_replay,
    output     [LSU_STA_COUNT*LSU_REQ_ID_BITS-1:0] dcache_router_store_resps_req_id,
    output                                  dcache_router_mshr_fill,

    // Future RealDcache/MSHR LLC read path.
    output                                  dcache_llc_read_req_valid,
    input                                   dcache_llc_read_req_ready,
    input                                   dcache_llc_read_req_accepted,
    input      [ID_BITS-1:0]                dcache_llc_read_req_accepted_id,
    output     [ADDR_BITS-1:0]              dcache_llc_read_req_addr,
    output     [7:0]                        dcache_llc_read_req_total_size,
    output     [ID_BITS-1:0]                dcache_llc_read_req_id,
    output                                  dcache_llc_read_req_bypass,
    input                                   dcache_llc_read_resp_valid,
    output                                  dcache_llc_read_resp_ready,
    input      [READ_RESP_BITS-1:0]         dcache_llc_read_resp_data,
    input      [ID_BITS-1:0]                dcache_llc_read_resp_id,

    // Future RealDcache/WB LLC write path.
    output                                  dcache_llc_write_req_valid,
    input                                   dcache_llc_write_req_ready,
    input                                   dcache_llc_write_req_accepted,
    output     [ADDR_BITS-1:0]              dcache_llc_write_req_addr,
    output     [LINE_BITS-1:0]              dcache_llc_write_req_wdata,
    output     [LINE_BYTES-1:0]             dcache_llc_write_req_wstrb,
    output     [7:0]                        dcache_llc_write_req_total_size,
    output     [ID_BITS-1:0]                dcache_llc_write_req_id,
    output                                  dcache_llc_write_req_bypass,
    input                                   dcache_llc_write_resp_valid,
    output                                  dcache_llc_write_resp_ready,
    input      [ID_BITS-1:0]                dcache_llc_write_resp_id,
    input      [1:0]                        dcache_llc_write_resp_code
);

    localparam integer DCACHE_TOTAL_PORTS     = LSU_LDU_COUNT + LSU_STA_COUNT;
    localparam integer DCACHE_OFFSET_BITS     = $clog2(DCACHE_LINE_BYTES);
    localparam integer DCACHE_SET_BITS        = $clog2(DCACHE_SET_COUNT);
    localparam integer DCACHE_TAG_BITS        = ADDR_BITS - DCACHE_SET_BITS - DCACHE_OFFSET_BITS;
    localparam integer DCACHE_WAY_BITS        = $clog2(DCACHE_WAY_COUNT);
    localparam integer DCACHE_MSHR_BITS       = $clog2(DCACHE_MSHR_ENTRIES);
    localparam integer DCACHE_MSHR_COUNT_BITS = DCACHE_MSHR_BITS + 1;
    localparam integer DCACHE_WB_BITS         = $clog2(DCACHE_WB_ENTRIES);
    localparam integer DCACHE_WB_COUNT_BITS   = DCACHE_WB_BITS + 1;
    localparam integer DCACHE_PLRU_TREE_BITS  =
        (DCACHE_WAY_COUNT > 1) ? (DCACHE_WAY_COUNT - 1) : 1;

    wire [DCACHE_TOTAL_PORTS*DCACHE_SET_BITS-1:0] dcachereadreq_set_idx;
    wire [DCACHE_TOTAL_PORTS*DCACHE_WAY_COUNT-1:0] dcachelinereadresp_valid;
    wire [DCACHE_TOTAL_PORTS*DCACHE_WAY_COUNT*DCACHE_TAG_BITS-1:0] dcachelinereadresp_tag;
    wire [DCACHE_TOTAL_PORTS*DCACHE_WAY_COUNT-1:0] dcachelinereadresp_dirty;
    wire [DCACHE_TOTAL_PORTS*DCACHE_WAY_COUNT*LINE_BITS-1:0] dcachelinereadresp_data;
    wire [DCACHE_TOTAL_PORTS-1:0] pendingwrite_valid;
    wire [DCACHE_TOTAL_PORTS*DCACHE_SET_BITS-1:0] pendingwrite_set_idx;
    wire [DCACHE_TOTAL_PORTS*DCACHE_WAY_BITS-1:0] pendingwrite_way_idx;
    wire [DCACHE_TOTAL_PORTS*DCACHE_OFFSET_BITS-1:0] pendingwrite_word_off;
    wire [DCACHE_TOTAL_PORTS*DATA_BITS-1:0] pendingwrite_data;
    wire [DCACHE_TOTAL_PORTS*STRB_BITS-1:0] pendingwrite_strb;
    wire [DCACHE_TOTAL_PORTS-1:0] lru_updates_valid;
    wire [DCACHE_TOTAL_PORTS*DCACHE_SET_BITS-1:0] lru_updates_set_idx;
    wire [DCACHE_TOTAL_PORTS*DCACHE_WAY_BITS-1:0] lru_updates_way;
    wire fill_write_valid;
    wire [DCACHE_MSHR_BITS-1:0] fill_write_id;
    wire fill_write_dirty;
    wire [DCACHE_SET_BITS-1:0] fill_write_set_idx;
    wire [DCACHE_TAG_BITS-1:0] fill_write_tag;
    wire [DCACHE_WAY_BITS-1:0] fill_write_way_idx;
    wire [LINE_BITS-1:0] fill_write_data;
    wire fillout_valid;
    wire [DCACHE_SET_BITS-1:0] fillout_set_idx;
    wire [DCACHE_WAY_COUNT-1:0] fillin_valid_snap;
    wire [DCACHE_WAY_COUNT-1:0] fillin_dirty_snap;
    wire [DCACHE_WAY_COUNT*DCACHE_TAG_BITS-1:0] fillin_tag_snap;
    wire [DCACHE_WAY_COUNT*LINE_BITS-1:0] fillin_data_snap;
    wire [DCACHE_PLRU_TREE_BITS-1:0] fillin_plru_tree_state;

    wire [DCACHE_TOTAL_PORTS-1:0] dcache_mshr_find_req_valid;
    wire [DCACHE_TOTAL_PORTS*DCACHE_SET_BITS-1:0] dcache_mshr_find_req_set_idx;
    wire [DCACHE_TOTAL_PORTS*DCACHE_TAG_BITS-1:0] dcache_mshr_find_req_tag;
    wire [DCACHE_TOTAL_PORTS-1:0] dcache_mshr_find_resp_valid;
    wire [DCACHE_TOTAL_PORTS-1:0] dcache_mshr_find_resp_hit;
    wire [DCACHE_TOTAL_PORTS-1:0] dcache_mshr_req_valid;
    wire [DCACHE_TOTAL_PORTS*ADDR_BITS-1:0] dcache_mshr_req_addr;
    wire [DCACHE_TOTAL_PORTS-1:0] dcache_mshr_req_is_store;
    wire [DCACHE_TOTAL_PORTS*DATA_BITS-1:0] dcache_mshr_req_data;
    wire [DCACHE_TOTAL_PORTS*STRB_BITS-1:0] dcache_mshr_req_strb;
    wire mshr_fill_req_valid;
    wire [DCACHE_MSHR_BITS-1:0] mshr_fill_req_id;
    wire mshr_fill_req_dirty;
    wire [DCACHE_WAY_BITS-1:0] mshr_fill_req_way_idx;
    wire [ADDR_BITS-1:0] mshr_fill_req_addr;
    wire [LINE_BITS-1:0] mshr_fill_req_data;
    wire dcache_mshr_fill_resp_done;
    wire [DCACHE_MSHR_BITS-1:0] dcache_mshr_fill_resp_id;
    wire [DCACHE_MSHR_COUNT_BITS-1:0] mshr_free;

    wire wb_dirty_info_valid;
    wire [ADDR_BITS-1:0] wb_dirty_info_addr;
    wire [LINE_BITS-1:0] wb_dirty_info_data;
    wire [LSU_LDU_COUNT-1:0] wb_bypass_req_valid;
    wire [LSU_LDU_COUNT*ADDR_BITS-1:0] wb_bypass_req_addr;
    wire [LSU_LDU_COUNT-1:0] wb_bypass_resp_valid;
    wire [LSU_LDU_COUNT*DATA_BITS-1:0] wb_bypass_resp_data;
    wire [LSU_STA_COUNT-1:0] wb_merge_req_valid;
    wire [LSU_STA_COUNT*ADDR_BITS-1:0] wb_merge_req_addr;
    wire [LSU_STA_COUNT*DATA_BITS-1:0] wb_merge_req_data;
    wire [LSU_STA_COUNT*STRB_BITS-1:0] wb_merge_req_strb;
    wire [LSU_STA_COUNT-1:0] wb_merge_resp_valid;
    wire [LSU_STA_COUNT-1:0] wb_merge_resp_busy;
    wire [DCACHE_WB_COUNT_BITS-1:0] wb_free;

    assign dcache_router_load_resps_valid = {LSU_LDU_COUNT{1'b0}};
    assign dcache_router_load_resps_data  = {LSU_LDU_COUNT*DATA_BITS{1'b0}};
    assign dcache_router_load_resps_req_id = {LSU_LDU_COUNT*LSU_REQ_ID_BITS{1'b0}};
    assign dcache_router_load_resps_replay = {LSU_LDU_COUNT*REPLAY_BITS{1'b0}};
    assign dcache_router_store_resps_valid = {LSU_STA_COUNT{1'b0}};
    assign dcache_router_store_resps_replay = {LSU_STA_COUNT*REPLAY_BITS{1'b0}};
    assign dcache_router_store_resps_req_id = {LSU_STA_COUNT*LSU_REQ_ID_BITS{1'b0}};
    assign dcache_router_mshr_fill        = 1'b0;

    assign dcachereadreq_set_idx          = {DCACHE_TOTAL_PORTS*DCACHE_SET_BITS{1'b0}};
    assign pendingwrite_valid             = {DCACHE_TOTAL_PORTS{1'b0}};
    assign pendingwrite_set_idx           = {DCACHE_TOTAL_PORTS*DCACHE_SET_BITS{1'b0}};
    assign pendingwrite_way_idx           = {DCACHE_TOTAL_PORTS*DCACHE_WAY_BITS{1'b0}};
    assign pendingwrite_word_off          = {DCACHE_TOTAL_PORTS*DCACHE_OFFSET_BITS{1'b0}};
    assign pendingwrite_data              = {DCACHE_TOTAL_PORTS*DATA_BITS{1'b0}};
    assign pendingwrite_strb              = {DCACHE_TOTAL_PORTS*STRB_BITS{1'b0}};
    assign lru_updates_valid              = {DCACHE_TOTAL_PORTS{1'b0}};
    assign lru_updates_set_idx            = {DCACHE_TOTAL_PORTS*DCACHE_SET_BITS{1'b0}};
    assign lru_updates_way                = {DCACHE_TOTAL_PORTS*DCACHE_WAY_BITS{1'b0}};
    assign fill_write_valid               = 1'b0;
    assign fill_write_id                  = {DCACHE_MSHR_BITS{1'b0}};
    assign fill_write_dirty               = 1'b0;
    assign fill_write_set_idx             = {DCACHE_SET_BITS{1'b0}};
    assign fill_write_tag                 = {DCACHE_TAG_BITS{1'b0}};
    assign fill_write_way_idx             = {DCACHE_WAY_BITS{1'b0}};
    assign fill_write_data                = {LINE_BITS{1'b0}};
    assign fillout_valid                  = 1'b0;
    assign fillout_set_idx                = {DCACHE_SET_BITS{1'b0}};

    assign dcache_mshr_find_req_valid     = {DCACHE_TOTAL_PORTS{1'b0}};
    assign dcache_mshr_find_req_set_idx   = {DCACHE_TOTAL_PORTS*DCACHE_SET_BITS{1'b0}};
    assign dcache_mshr_find_req_tag       = {DCACHE_TOTAL_PORTS*DCACHE_TAG_BITS{1'b0}};
    assign dcache_mshr_req_valid          = {DCACHE_TOTAL_PORTS{1'b0}};
    assign dcache_mshr_req_addr           = {DCACHE_TOTAL_PORTS*ADDR_BITS{1'b0}};
    assign dcache_mshr_req_is_store       = {DCACHE_TOTAL_PORTS{1'b0}};
    assign dcache_mshr_req_data           = {DCACHE_TOTAL_PORTS*DATA_BITS{1'b0}};
    assign dcache_mshr_req_strb           = {DCACHE_TOTAL_PORTS*STRB_BITS{1'b0}};
    assign dcache_mshr_fill_resp_done     = 1'b0;
    assign dcache_mshr_fill_resp_id       = {DCACHE_MSHR_BITS{1'b0}};

    assign wb_dirty_info_valid            = 1'b0;
    assign wb_dirty_info_addr             = {ADDR_BITS{1'b0}};
    assign wb_dirty_info_data             = {LINE_BITS{1'b0}};
    assign wb_bypass_req_valid            = {LSU_LDU_COUNT{1'b0}};
    assign wb_bypass_req_addr             = {LSU_LDU_COUNT*ADDR_BITS{1'b0}};
    assign wb_merge_req_valid             = {LSU_STA_COUNT{1'b0}};
    assign wb_merge_req_addr              = {LSU_STA_COUNT*ADDR_BITS{1'b0}};
    assign wb_merge_req_data              = {LSU_STA_COUNT*DATA_BITS{1'b0}};
    assign wb_merge_req_strb              = {LSU_STA_COUNT*STRB_BITS{1'b0}};

    dcache_array_top #(
        .ADDR_BITS(ADDR_BITS),
        .DATA_BITS(DATA_BITS),
        .STRB_BITS(STRB_BITS),
        .LSU_LDU_COUNT(LSU_LDU_COUNT),
        .LSU_STA_COUNT(LSU_STA_COUNT),
        .DCACHE_LINE_BYTES(DCACHE_LINE_BYTES),
        .DCACHE_SET_COUNT(DCACHE_SET_COUNT),
        .DCACHE_WAY_COUNT(DCACHE_WAY_COUNT),
        .DCACHE_MSHR_ENTRIES(DCACHE_MSHR_ENTRIES),
        .LINE_BITS(LINE_BITS),
        .LINE_BYTES(LINE_BYTES)
    ) u_dcache_array_top (
        .clk(clk),
        .rst_n(rst_n),
        .dcachereadreq_set_idx(dcachereadreq_set_idx),
        .dcachelinereadresp_valid(dcachelinereadresp_valid),
        .dcachelinereadresp_tag(dcachelinereadresp_tag),
        .dcachelinereadresp_dirty(dcachelinereadresp_dirty),
        .dcachelinereadresp_data(dcachelinereadresp_data),
        .pendingwrite_valid(pendingwrite_valid),
        .pendingwrite_set_idx(pendingwrite_set_idx),
        .pendingwrite_way_idx(pendingwrite_way_idx),
        .pendingwrite_word_off(pendingwrite_word_off),
        .pendingwrite_data(pendingwrite_data),
        .pendingwrite_strb(pendingwrite_strb),
        .lru_updates_valid(lru_updates_valid),
        .lru_updates_set_idx(lru_updates_set_idx),
        .lru_updates_way(lru_updates_way),
        .fill_write_valid(fill_write_valid),
        .fill_write_id(fill_write_id),
        .fill_write_dirty(fill_write_dirty),
        .fill_write_set_idx(fill_write_set_idx),
        .fill_write_tag(fill_write_tag),
        .fill_write_way_idx(fill_write_way_idx),
        .fill_write_data(fill_write_data),
        .fillout_valid(fillout_valid),
        .fillout_set_idx(fillout_set_idx),
        .fillin_valid_snap(fillin_valid_snap),
        .fillin_dirty_snap(fillin_dirty_snap),
        .fillin_tag_snap(fillin_tag_snap),
        .fillin_data_snap(fillin_data_snap),
        .fillin_plru_tree_state(fillin_plru_tree_state)
    );

    dcache_mshr_top #(
        .ADDR_BITS(ADDR_BITS),
        .DATA_BITS(DATA_BITS),
        .STRB_BITS(STRB_BITS),
        .LSU_LDU_COUNT(LSU_LDU_COUNT),
        .LSU_STA_COUNT(LSU_STA_COUNT),
        .DCACHE_LINE_BYTES(DCACHE_LINE_BYTES),
        .DCACHE_SET_COUNT(DCACHE_SET_COUNT),
        .DCACHE_WAY_COUNT(DCACHE_WAY_COUNT),
        .DCACHE_MSHR_ENTRIES(DCACHE_MSHR_ENTRIES),
        .ID_BITS(ID_BITS),
        .LINE_BITS(LINE_BITS),
        .READ_RESP_BITS(READ_RESP_BITS)
    ) u_dcache_mshr_top (
        .clk(clk),
        .rst_n(rst_n),
        .find_req_valid(dcache_mshr_find_req_valid),
        .find_req_set_idx(dcache_mshr_find_req_set_idx),
        .find_req_tag(dcache_mshr_find_req_tag),
        .find_resp_valid(dcache_mshr_find_resp_valid),
        .find_resp_hit(dcache_mshr_find_resp_hit),
        .mshr_req_valid(dcache_mshr_req_valid),
        .mshr_req_addr(dcache_mshr_req_addr),
        .mshr_req_is_store(dcache_mshr_req_is_store),
        .mshr_req_data(dcache_mshr_req_data),
        .mshr_req_strb(dcache_mshr_req_strb),
        .fill_req_valid(mshr_fill_req_valid),
        .fill_req_id(mshr_fill_req_id),
        .fill_req_dirty(mshr_fill_req_dirty),
        .fill_req_way_idx(mshr_fill_req_way_idx),
        .fill_req_addr(mshr_fill_req_addr),
        .fill_req_data(mshr_fill_req_data),
        .fill_resp_done(dcache_mshr_fill_resp_done),
        .fill_resp_id(dcache_mshr_fill_resp_id),
        .free(mshr_free),
        .dcache_llc_read_req_valid(dcache_llc_read_req_valid),
        .dcache_llc_read_req_ready(dcache_llc_read_req_ready),
        .dcache_llc_read_req_accepted(dcache_llc_read_req_accepted),
        .dcache_llc_read_req_accepted_id(dcache_llc_read_req_accepted_id),
        .dcache_llc_read_req_addr(dcache_llc_read_req_addr),
        .dcache_llc_read_req_total_size(dcache_llc_read_req_total_size),
        .dcache_llc_read_req_id(dcache_llc_read_req_id),
        .dcache_llc_read_req_bypass(dcache_llc_read_req_bypass),
        .dcache_llc_read_resp_valid(dcache_llc_read_resp_valid),
        .dcache_llc_read_resp_ready(dcache_llc_read_resp_ready),
        .dcache_llc_read_resp_data(dcache_llc_read_resp_data),
        .dcache_llc_read_resp_id(dcache_llc_read_resp_id)
    );

    dcache_write_buffer_top #(
        .ADDR_BITS(ADDR_BITS),
        .DATA_BITS(DATA_BITS),
        .STRB_BITS(STRB_BITS),
        .LSU_LDU_COUNT(LSU_LDU_COUNT),
        .LSU_STA_COUNT(LSU_STA_COUNT),
        .DCACHE_WB_ENTRIES(DCACHE_WB_ENTRIES),
        .ID_BITS(ID_BITS),
        .LINE_BITS(LINE_BITS),
        .LINE_BYTES(LINE_BYTES)
    ) u_dcache_write_buffer_top (
        .clk(clk),
        .rst_n(rst_n),
        .dirty_info_valid(wb_dirty_info_valid),
        .dirty_info_addr(wb_dirty_info_addr),
        .dirty_info_data(wb_dirty_info_data),
        .bypass_req_valid(wb_bypass_req_valid),
        .bypass_req_addr(wb_bypass_req_addr),
        .bypass_resp_valid(wb_bypass_resp_valid),
        .bypass_resp_data(wb_bypass_resp_data),
        .merge_req_valid(wb_merge_req_valid),
        .merge_req_addr(wb_merge_req_addr),
        .merge_req_data(wb_merge_req_data),
        .merge_req_strb(wb_merge_req_strb),
        .merge_resp_valid(wb_merge_resp_valid),
        .merge_resp_busy(wb_merge_resp_busy),
        .free(wb_free),
        .dcache_llc_write_req_valid(dcache_llc_write_req_valid),
        .dcache_llc_write_req_ready(dcache_llc_write_req_ready),
        .dcache_llc_write_req_accepted(dcache_llc_write_req_accepted),
        .dcache_llc_write_req_addr(dcache_llc_write_req_addr),
        .dcache_llc_write_req_wdata(dcache_llc_write_req_wdata),
        .dcache_llc_write_req_wstrb(dcache_llc_write_req_wstrb),
        .dcache_llc_write_req_total_size(dcache_llc_write_req_total_size),
        .dcache_llc_write_req_id(dcache_llc_write_req_id),
        .dcache_llc_write_req_bypass(dcache_llc_write_req_bypass),
        .dcache_llc_write_resp_valid(dcache_llc_write_resp_valid),
        .dcache_llc_write_resp_ready(dcache_llc_write_resp_ready),
        .dcache_llc_write_resp_id(dcache_llc_write_resp_id),
        .dcache_llc_write_resp_code(dcache_llc_write_resp_code)
    );

endmodule
