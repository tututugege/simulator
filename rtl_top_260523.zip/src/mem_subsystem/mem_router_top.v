`timescale 1ns / 1ps
`include "axi_llc_params.vh"
`include "qm3_cpu_params.vh"

// MemRouteBlock shell.
//
// TODO:
// 1. Implement MemRouteBlock request arbitration among LSU, ICache, and PTW
//    clients.
// 2. Implement DCache response demultiplexing back to LSU, ICache, and PTW.
// 3. Implement route-id allocation and owner tracking.
// 4. Implement replay, grant, and wakeup state.
// 5. Implement the MMIO/peripheral route currently represented only by idle
//    response tie-offs.
module mem_router_top #(
    parameter ADDR_BITS              = `AXI_LLC_ADDR_BITS,
    parameter DATA_BITS              = `QM3_DATA_BITS,
    parameter STRB_BITS              = `QM3_STRB_BITS,
    parameter LSU_LDU_COUNT          = `QM3_LSU_LDU_COUNT,
    parameter LSU_STA_COUNT          = `QM3_LSU_STA_COUNT,
    parameter LSU_LDU_WIDTH          = `QM3_LSU_LDU_WIDTH,
    parameter LSU_REQ_ID_BITS        = `QM3_LSU_REQ_ID_BITS,
    parameter REPLAY_BITS            = `QM3_REPLAY_BITS,
    parameter PTW_OWNER_BITS         = 3
) (
    input                                   clk,
    input                                   rst_n,

    // MemRouteIn.dcache_resp from dcache_top.
    input      [LSU_LDU_COUNT-1:0]          dcache_router_load_resps_valid,
    input      [LSU_LDU_COUNT*DATA_BITS-1:0] dcache_router_load_resps_data,
    input      [LSU_LDU_COUNT*LSU_REQ_ID_BITS-1:0] dcache_router_load_resps_req_id,
    input      [LSU_LDU_COUNT*REPLAY_BITS-1:0] dcache_router_load_resps_replay,
    input      [LSU_STA_COUNT-1:0]          dcache_router_store_resps_valid,
    input      [LSU_STA_COUNT*REPLAY_BITS-1:0] dcache_router_store_resps_replay,
    input      [LSU_STA_COUNT*LSU_REQ_ID_BITS-1:0] dcache_router_store_resps_req_id,
    input                                   dcache_router_mshr_fill,

    // MemRouteIn.lsu_req from backend_top/LSU.
    input      [LSU_LDU_COUNT-1:0]          lsu2dcache_load_ports_valid,
    input      [LSU_LDU_COUNT*ADDR_BITS-1:0] lsu2dcache_load_ports_addr,
    input      [LSU_LDU_COUNT*LSU_REQ_ID_BITS-1:0] lsu2dcache_load_ports_req_id,
    input      [LSU_STA_COUNT-1:0]          lsu2dcache_store_ports_valid,
    input      [LSU_STA_COUNT*ADDR_BITS-1:0] lsu2dcache_store_ports_addr,
    input      [LSU_STA_COUNT*DATA_BITS-1:0] lsu2dcache_store_ports_data,
    input      [LSU_STA_COUNT*STRB_BITS-1:0] lsu2dcache_store_ports_strb,
    input      [LSU_STA_COUNT*LSU_REQ_ID_BITS-1:0] lsu2dcache_store_ports_req_id,
    input      [LSU_LDU_WIDTH:0]            lsu2dcache_icache_req,

    // MemRouteIn.icache_req from frontend_top/ICache.
    input                                   icache_dcache_req_valid,
    input      [ADDR_BITS-1:0]              icache_dcache_req_addr,

    // MemRouteIn.ptw_walk_req / ptw_dtlb_req / ptw_itlb_req from ptw_top.
    input                                   ptw_walk_req_valid,
    input      [ADDR_BITS-1:0]              ptw_walk_req_addr,
    input                                   ptw_dtlb_req_valid,
    input      [ADDR_BITS-1:0]              ptw_dtlb_req_addr,
    input                                   ptw_itlb_req_valid,
    input      [ADDR_BITS-1:0]              ptw_itlb_req_addr,

    // MemRouteOut.dcache_req to dcache_top.
    output     [LSU_LDU_COUNT-1:0]          router_dcache_load_ports_valid,
    output     [LSU_LDU_COUNT*ADDR_BITS-1:0] router_dcache_load_ports_addr,
    output     [LSU_LDU_COUNT*LSU_REQ_ID_BITS-1:0] router_dcache_load_ports_req_id,
    output     [LSU_STA_COUNT-1:0]          router_dcache_store_ports_valid,
    output     [LSU_STA_COUNT*ADDR_BITS-1:0] router_dcache_store_ports_addr,
    output     [LSU_STA_COUNT*DATA_BITS-1:0] router_dcache_store_ports_data,
    output     [LSU_STA_COUNT*STRB_BITS-1:0] router_dcache_store_ports_strb,
    output     [LSU_STA_COUNT*LSU_REQ_ID_BITS-1:0] router_dcache_store_ports_req_id,
    output     [LSU_LDU_WIDTH:0]            router_dcache_icache_req,

    // MemRouteOut.lsu_resp to backend_top/LSU.
    output     [LSU_LDU_COUNT-1:0]          dcache2lsu_load_resps_valid,
    output     [LSU_LDU_COUNT*DATA_BITS-1:0] dcache2lsu_load_resps_data,
    output     [LSU_LDU_COUNT*LSU_REQ_ID_BITS-1:0] dcache2lsu_load_resps_req_id,
    output     [LSU_LDU_COUNT*REPLAY_BITS-1:0] dcache2lsu_load_resps_replay,
    output     [LSU_STA_COUNT-1:0]          dcache2lsu_store_resps_valid,
    output     [LSU_STA_COUNT*REPLAY_BITS-1:0] dcache2lsu_store_resps_replay,
    output     [LSU_STA_COUNT*LSU_REQ_ID_BITS-1:0] dcache2lsu_store_resps_req_id,
    output                                  dcache2lsu_mshr_fill,

    // MemRouteOut.icache_resp to frontend_top/ICache.
    output                                  dcache_icache_resp_valid,
    output                                  dcache_icache_resp_miss,
    output     [DATA_BITS-1:0]              dcache_icache_resp_data,

    // MemRouteOut.ptw_grant / ptw_events / wakeup to ptw_top.
    output                                  ptw_grant_valid,
    output     [PTW_OWNER_BITS-1:0]         ptw_grant_owner,
    output     [LSU_REQ_ID_BITS-1:0]        ptw_grant_req_id,
    output                                  ptw_event_valid,
    output     [PTW_OWNER_BITS-1:0]         ptw_event_owner,
    output     [DATA_BITS-1:0]              ptw_event_data,
    output     [REPLAY_BITS-1:0]            ptw_event_replay,
    output     [ADDR_BITS-1:0]              ptw_event_req_addr,
    output     [LSU_REQ_ID_BITS-1:0]        ptw_event_req_id,
    output                                  ptw_wakeup_dtlb,
    output                                  ptw_wakeup_itlb,
    output                                  ptw_wakeup_walk,

    // PeripheralReqIO placeholder for the future MMIO route owned here.
    input                                   peripheral_req_is_mmio,
    input                                   peripheral_req_wen,
    input      [ADDR_BITS-1:0]              peripheral_req_mmio_addr,
    input      [DATA_BITS-1:0]              peripheral_req_mmio_wdata,
    input      [2:0]                        peripheral_req_mmio_fun3,

    // PeripheralRespIO placeholder for the future MMIO route owned here.
    output                                  peripheral_resp_is_mmio,
    output                                  peripheral_resp_ready,
    output     [DATA_BITS-1:0]              peripheral_resp_mmio_rdata
);

    assign router_dcache_load_ports_valid  = {LSU_LDU_COUNT{1'b0}};
    assign router_dcache_load_ports_addr   = {LSU_LDU_COUNT*ADDR_BITS{1'b0}};
    assign router_dcache_load_ports_req_id = {LSU_LDU_COUNT*LSU_REQ_ID_BITS{1'b0}};
    assign router_dcache_store_ports_valid = {LSU_STA_COUNT{1'b0}};
    assign router_dcache_store_ports_addr  = {LSU_STA_COUNT*ADDR_BITS{1'b0}};
    assign router_dcache_store_ports_data  = {LSU_STA_COUNT*DATA_BITS{1'b0}};
    assign router_dcache_store_ports_strb  = {LSU_STA_COUNT*STRB_BITS{1'b0}};
    assign router_dcache_store_ports_req_id = {LSU_STA_COUNT*LSU_REQ_ID_BITS{1'b0}};
    assign router_dcache_icache_req        = LSU_LDU_COUNT;

    assign dcache2lsu_load_resps_valid     = {LSU_LDU_COUNT{1'b0}};
    assign dcache2lsu_load_resps_data      = {LSU_LDU_COUNT*DATA_BITS{1'b0}};
    assign dcache2lsu_load_resps_req_id    = {LSU_LDU_COUNT*LSU_REQ_ID_BITS{1'b0}};
    assign dcache2lsu_load_resps_replay    = {LSU_LDU_COUNT*REPLAY_BITS{1'b0}};
    assign dcache2lsu_store_resps_valid    = {LSU_STA_COUNT{1'b0}};
    assign dcache2lsu_store_resps_replay   = {LSU_STA_COUNT*REPLAY_BITS{1'b0}};
    assign dcache2lsu_store_resps_req_id   = {LSU_STA_COUNT*LSU_REQ_ID_BITS{1'b0}};
    assign dcache2lsu_mshr_fill            = 1'b0;

    assign dcache_icache_resp_valid        = 1'b0;
    assign dcache_icache_resp_miss         = 1'b0;
    assign dcache_icache_resp_data         = {DATA_BITS{1'b0}};

    assign ptw_grant_valid                 = 1'b0;
    assign ptw_grant_owner                 = {PTW_OWNER_BITS{1'b0}};
    assign ptw_grant_req_id                = {LSU_REQ_ID_BITS{1'b0}};
    assign ptw_event_valid                 = 1'b0;
    assign ptw_event_owner                 = {PTW_OWNER_BITS{1'b0}};
    assign ptw_event_data                  = {DATA_BITS{1'b0}};
    assign ptw_event_replay                = {REPLAY_BITS{1'b0}};
    assign ptw_event_req_addr              = {ADDR_BITS{1'b0}};
    assign ptw_event_req_id                = {LSU_REQ_ID_BITS{1'b0}};
    assign ptw_wakeup_dtlb                 = 1'b0;
    assign ptw_wakeup_itlb                 = 1'b0;
    assign ptw_wakeup_walk                 = 1'b0;

    assign peripheral_resp_is_mmio         = 1'b0;
    assign peripheral_resp_ready           = 1'b0;
    assign peripheral_resp_mmio_rdata      = {DATA_BITS{1'b0}};

endmodule
