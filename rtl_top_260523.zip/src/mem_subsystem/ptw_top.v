`timescale 1ns / 1ps
`include "axi_llc_params.vh"
`include "qm3_cpu_params.vh"

// PTW shell.
//
// TODO:
// 1. Implement trained/generated PTW walk control logic.
// 2. Implement DTLB/ITLB client request arbitration and response routing.
// 3. Implement router feedback handling for grants, events, and wakeups.
// 4. Implement PTE decode, level transition, permission, and fault logic.
// 5. Keep page-table memory access through router-facing ports only; do not add
//    direct memory backdoors.
//
// Client ports follow simulator PtwMemPortCombIn/Out and
// PtwWalkPortCombIn/Out. Router feedback names mirror MemRouteBlock PtwGrant,
// PtwEvent, and ReplayWakeup.
module ptw_top #(
    parameter ADDR_BITS              = `AXI_LLC_ADDR_BITS,
    parameter DATA_BITS              = `QM3_DATA_BITS,
    parameter CSR_BITS               = `QM3_CSR_BITS,
    parameter PRIVILEGE_BITS         = `QM3_PRIVILEGE_BITS,
    parameter LSU_REQ_ID_BITS        = `QM3_LSU_REQ_ID_BITS,
    parameter REPLAY_BITS            = `QM3_REPLAY_BITS,
    parameter PTW_ACCESS_TYPE_BITS   = `QM3_PTW_ACCESS_TYPE_BITS,
    parameter PTW_LEVEL_BITS         = `QM3_PTW_LEVEL_BITS,
    parameter PTE_BITS               = `QM3_PTE_BITS,
    parameter PTW_OWNER_BITS         = 3
) (
    input                                   clk,
    input                                   rst_n,

    // CsrStatusIO context from backend_top for future walk permission checks.
    input      [CSR_BITS-1:0]               csr_status_sstatus,
    input      [CSR_BITS-1:0]               csr_status_mstatus,
    input      [CSR_BITS-1:0]               csr_status_satp,
    input      [PRIVILEGE_BITS-1:0]         csr_status_privilege,

    // DTLB PtwMemPortCombIn/Out.
    input                                   dtlb_ptw_mem_req_valid,
    input      [ADDR_BITS-1:0]              dtlb_ptw_mem_req_addr,
    input                                   dtlb_ptw_mem_resp_consumed,
    output                                  dtlb_ptw_mem_req_ready,
    output                                  dtlb_ptw_mem_resp_valid,
    output     [DATA_BITS-1:0]              dtlb_ptw_mem_resp_data,

    // ITLB PtwMemPortCombIn/Out.
    input                                   itlb_ptw_mem_req_valid,
    input      [ADDR_BITS-1:0]              itlb_ptw_mem_req_addr,
    input                                   itlb_ptw_mem_resp_consumed,
    output                                  itlb_ptw_mem_req_ready,
    output                                  itlb_ptw_mem_resp_valid,
    output     [DATA_BITS-1:0]              itlb_ptw_mem_resp_data,

    // DTLB PtwWalkPortCombIn/Out.
    input                                   dtlb_walk_req_valid,
    input      [ADDR_BITS-1:0]              dtlb_walk_req_vaddr,
    input      [CSR_BITS-1:0]               dtlb_walk_req_satp,
    input      [PTW_ACCESS_TYPE_BITS-1:0]   dtlb_walk_req_access_type,
    input                                   dtlb_walk_resp_consumed,
    input                                   dtlb_walk_flush,
    output                                  dtlb_walk_req_ready,
    output                                  dtlb_walk_resp_valid,
    output                                  dtlb_walk_resp_fault,
    output     [ADDR_BITS-1:0]              dtlb_walk_resp_vaddr,
    output     [PTE_BITS-1:0]               dtlb_walk_resp_leaf_pte,
    output     [PTW_LEVEL_BITS-1:0]         dtlb_walk_resp_leaf_level,

    // ITLB PtwWalkPortCombIn/Out.
    input                                   itlb_walk_req_valid,
    input      [ADDR_BITS-1:0]              itlb_walk_req_vaddr,
    input      [CSR_BITS-1:0]               itlb_walk_req_satp,
    input      [PTW_ACCESS_TYPE_BITS-1:0]   itlb_walk_req_access_type,
    input                                   itlb_walk_resp_consumed,
    input                                   itlb_walk_flush,
    output                                  itlb_walk_req_ready,
    output                                  itlb_walk_resp_valid,
    output                                  itlb_walk_resp_fault,
    output     [ADDR_BITS-1:0]              itlb_walk_resp_vaddr,
    output     [PTE_BITS-1:0]               itlb_walk_resp_leaf_pte,
    output     [PTW_LEVEL_BITS-1:0]         itlb_walk_resp_leaf_level,

    // PTW memory requests to mem_router_top.
    output                                  ptw_dtlb_req_valid,
    output     [ADDR_BITS-1:0]              ptw_dtlb_req_addr,
    output                                  ptw_itlb_req_valid,
    output     [ADDR_BITS-1:0]              ptw_itlb_req_addr,
    output                                  ptw_walk_req_valid,
    output     [ADDR_BITS-1:0]              ptw_walk_req_addr,

    // Router feedback from mem_router_top.
    input                                   ptw_grant_valid,
    input      [PTW_OWNER_BITS-1:0]         ptw_grant_owner,
    input      [LSU_REQ_ID_BITS-1:0]        ptw_grant_req_id,
    input                                   ptw_event_valid,
    input      [PTW_OWNER_BITS-1:0]         ptw_event_owner,
    input      [DATA_BITS-1:0]              ptw_event_data,
    input      [REPLAY_BITS-1:0]            ptw_event_replay,
    input      [ADDR_BITS-1:0]              ptw_event_req_addr,
    input      [LSU_REQ_ID_BITS-1:0]        ptw_event_req_id,
    input                                   ptw_wakeup_dtlb,
    input                                   ptw_wakeup_itlb,
    input                                   ptw_wakeup_walk
);

    assign dtlb_ptw_mem_req_ready      = 1'b0;
    assign dtlb_ptw_mem_resp_valid     = 1'b0;
    assign dtlb_ptw_mem_resp_data      = {DATA_BITS{1'b0}};
    assign dtlb_walk_req_ready         = 1'b0;
    assign dtlb_walk_resp_valid        = 1'b0;
    assign dtlb_walk_resp_fault        = 1'b0;
    assign dtlb_walk_resp_vaddr        = {ADDR_BITS{1'b0}};
    assign dtlb_walk_resp_leaf_pte     = {PTE_BITS{1'b0}};
    assign dtlb_walk_resp_leaf_level   = {PTW_LEVEL_BITS{1'b0}};

    assign itlb_ptw_mem_req_ready      = 1'b0;
    assign itlb_ptw_mem_resp_valid     = 1'b0;
    assign itlb_ptw_mem_resp_data      = {DATA_BITS{1'b0}};
    assign itlb_walk_req_ready         = 1'b0;
    assign itlb_walk_resp_valid        = 1'b0;
    assign itlb_walk_resp_fault        = 1'b0;
    assign itlb_walk_resp_vaddr        = {ADDR_BITS{1'b0}};
    assign itlb_walk_resp_leaf_pte     = {PTE_BITS{1'b0}};
    assign itlb_walk_resp_leaf_level   = {PTW_LEVEL_BITS{1'b0}};

    assign ptw_dtlb_req_valid          = 1'b0;
    assign ptw_dtlb_req_addr           = {ADDR_BITS{1'b0}};
    assign ptw_itlb_req_valid          = 1'b0;
    assign ptw_itlb_req_addr           = {ADDR_BITS{1'b0}};
    assign ptw_walk_req_valid          = 1'b0;
    assign ptw_walk_req_addr           = {ADDR_BITS{1'b0}};

endmodule
