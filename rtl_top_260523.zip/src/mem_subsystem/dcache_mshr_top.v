`timescale 1ns / 1ps
`include "axi_llc_params.vh"
`include "qm3_cpu_params.vh"

// DCache MSHR boundary shell.
//
// The DCache-facing ports mirror the simulator DcacheMSHRIO/MSHRDcacheIO shape.
// The LLC-facing ports are the existing DCache read-master channel. Internal MSHR
// allocation, merge, and refill tracking are intentionally left empty for now.
module dcache_mshr_top #(
    parameter ADDR_BITS              = `AXI_LLC_ADDR_BITS,
    parameter DATA_BITS              = `QM3_DATA_BITS,
    parameter STRB_BITS              = `QM3_STRB_BITS,
    parameter LSU_LDU_COUNT          = `QM3_LSU_LDU_COUNT,
    parameter LSU_STA_COUNT          = `QM3_LSU_STA_COUNT,
    parameter DCACHE_LINE_BYTES      = `QM3_DCACHE_LINE_BYTES,
    parameter DCACHE_SET_COUNT       = `QM3_DCACHE_SET_COUNT,
    parameter DCACHE_WAY_COUNT       = `QM3_DCACHE_WAY_COUNT,
    parameter DCACHE_MSHR_ENTRIES    = `QM3_DCACHE_MSHR_ENTRIES,
    parameter ID_BITS                = `AXI_LLC_ID_BITS,
    parameter LINE_BITS              = `AXI_LLC_LINE_BITS,
    parameter READ_RESP_BITS         = `AXI_LLC_READ_RESP_BITS,
    parameter DCACHE_TOTAL_PORTS     = LSU_LDU_COUNT + LSU_STA_COUNT,
    parameter DCACHE_OFFSET_BITS     = $clog2(DCACHE_LINE_BYTES),
    parameter DCACHE_SET_BITS        = $clog2(DCACHE_SET_COUNT),
    parameter DCACHE_TAG_BITS        = ADDR_BITS - DCACHE_SET_BITS - DCACHE_OFFSET_BITS,
    parameter DCACHE_WAY_BITS        = $clog2(DCACHE_WAY_COUNT),
    parameter DCACHE_MSHR_BITS       = $clog2(DCACHE_MSHR_ENTRIES),
    parameter DCACHE_MSHR_COUNT_BITS = DCACHE_MSHR_BITS + 1
) (
    input                                           clk,
    input                                           rst_n,

    // DcacheMSHRIO.find_req.
    input      [DCACHE_TOTAL_PORTS-1:0]             find_req_valid,
    input      [DCACHE_TOTAL_PORTS*DCACHE_SET_BITS-1:0] find_req_set_idx,
    input      [DCACHE_TOTAL_PORTS*DCACHE_TAG_BITS-1:0] find_req_tag,

    // MSHRDcacheIO.find_resp.
    output     [DCACHE_TOTAL_PORTS-1:0]             find_resp_valid,
    output     [DCACHE_TOTAL_PORTS-1:0]             find_resp_hit,

    // DcacheMSHRIO.mshr_req.
    input      [DCACHE_TOTAL_PORTS-1:0]             mshr_req_valid,
    input      [DCACHE_TOTAL_PORTS*ADDR_BITS-1:0]   mshr_req_addr,
    input      [DCACHE_TOTAL_PORTS-1:0]             mshr_req_is_store,
    input      [DCACHE_TOTAL_PORTS*DATA_BITS-1:0]   mshr_req_data,
    input      [DCACHE_TOTAL_PORTS*STRB_BITS-1:0]   mshr_req_strb,

    // MSHRDcacheIO.fill_req.
    output                                          fill_req_valid,
    output     [DCACHE_MSHR_BITS-1:0]              fill_req_id,
    output                                          fill_req_dirty,
    output     [DCACHE_WAY_BITS-1:0]               fill_req_way_idx,
    output     [ADDR_BITS-1:0]                     fill_req_addr,
    output     [LINE_BITS-1:0]                     fill_req_data,

    // DcacheMSHRIO.fill_resp and MSHRDcacheIO.free.
    input                                           fill_resp_done,
    input      [DCACHE_MSHR_BITS-1:0]              fill_resp_id,
    output     [DCACHE_MSHR_COUNT_BITS-1:0]        free,

    // LLC read path.
    output                                          dcache_llc_read_req_valid,
    input                                           dcache_llc_read_req_ready,
    input                                           dcache_llc_read_req_accepted,
    input      [ID_BITS-1:0]                        dcache_llc_read_req_accepted_id,
    output     [ADDR_BITS-1:0]                     dcache_llc_read_req_addr,
    output     [7:0]                                dcache_llc_read_req_total_size,
    output     [ID_BITS-1:0]                        dcache_llc_read_req_id,
    output                                          dcache_llc_read_req_bypass,
    input                                           dcache_llc_read_resp_valid,
    output                                          dcache_llc_read_resp_ready,
    input      [READ_RESP_BITS-1:0]                 dcache_llc_read_resp_data,
    input      [ID_BITS-1:0]                        dcache_llc_read_resp_id
);

    assign find_resp_valid               = {DCACHE_TOTAL_PORTS{1'b0}};
    assign find_resp_hit                 = {DCACHE_TOTAL_PORTS{1'b0}};

    assign fill_req_valid                = 1'b0;
    assign fill_req_id                   = {DCACHE_MSHR_BITS{1'b0}};
    assign fill_req_dirty                = 1'b0;
    assign fill_req_way_idx              = {DCACHE_WAY_BITS{1'b0}};
    assign fill_req_addr                 = {ADDR_BITS{1'b0}};
    assign fill_req_data                 = {LINE_BITS{1'b0}};
    assign free                          = {DCACHE_MSHR_COUNT_BITS{1'b0}};

    assign dcache_llc_read_req_valid      = 1'b0;
    assign dcache_llc_read_req_addr       = {ADDR_BITS{1'b0}};
    assign dcache_llc_read_req_total_size = 8'b0;
    assign dcache_llc_read_req_id         = {ID_BITS{1'b0}};
    assign dcache_llc_read_req_bypass     = 1'b0;
    assign dcache_llc_read_resp_ready     = 1'b0;

endmodule
