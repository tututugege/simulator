`timescale 1ns / 1ps
`include "axi_llc_params.vh"
`include "qm3_cpu_params.vh"

// DCache array boundary shell.
//
// This module preserves the simulator Dcache_Read/Dcache_Write style boundary:
// RealDcache will later drive read requests, pending writes, fill writes, LRU
// updates, and fillout probes; this shell will eventually own tag/data/dirty/PLRU
// RAMs and return line snapshots. For now it is an externally-correct empty
// boundary with all outputs tied off.
module dcache_array_top #(
    parameter ADDR_BITS              = `AXI_LLC_ADDR_BITS,
    parameter DATA_BITS              = `QM3_DATA_BITS,
    parameter STRB_BITS              = `QM3_STRB_BITS,
    parameter LSU_LDU_COUNT          = `QM3_LSU_LDU_COUNT,
    parameter LSU_STA_COUNT          = `QM3_LSU_STA_COUNT,
    parameter DCACHE_LINE_BYTES      = `QM3_DCACHE_LINE_BYTES,
    parameter DCACHE_SET_COUNT       = `QM3_DCACHE_SET_COUNT,
    parameter DCACHE_WAY_COUNT       = `QM3_DCACHE_WAY_COUNT,
    parameter DCACHE_MSHR_ENTRIES    = `QM3_DCACHE_MSHR_ENTRIES,
    parameter LINE_BITS              = `AXI_LLC_LINE_BITS,
    parameter LINE_BYTES             = `AXI_LLC_LINE_BYTES,
    parameter DCACHE_TOTAL_PORTS     = LSU_LDU_COUNT + LSU_STA_COUNT,
    parameter DCACHE_OFFSET_BITS     = $clog2(DCACHE_LINE_BYTES),
    parameter DCACHE_SET_BITS        = $clog2(DCACHE_SET_COUNT),
    parameter DCACHE_TAG_BITS        = ADDR_BITS - DCACHE_SET_BITS - DCACHE_OFFSET_BITS,
    parameter DCACHE_WAY_BITS        = $clog2(DCACHE_WAY_COUNT),
    parameter DCACHE_MSHR_BITS       = $clog2(DCACHE_MSHR_ENTRIES),
    parameter DCACHE_PLRU_TREE_BITS  = (DCACHE_WAY_COUNT > 1) ? (DCACHE_WAY_COUNT - 1) : 1
) (
    input                                           clk,
    input                                           rst_n,

    // DcacheLineReadReq[load+store].
    input      [DCACHE_TOTAL_PORTS*DCACHE_SET_BITS-1:0] dcachereadreq_set_idx,

    // DcacheLineReadResp[load+store].
    output     [DCACHE_TOTAL_PORTS*DCACHE_WAY_COUNT-1:0] dcachelinereadresp_valid,
    output     [DCACHE_TOTAL_PORTS*DCACHE_WAY_COUNT*DCACHE_TAG_BITS-1:0] dcachelinereadresp_tag,
    output     [DCACHE_TOTAL_PORTS*DCACHE_WAY_COUNT-1:0] dcachelinereadresp_dirty,
    output     [DCACHE_TOTAL_PORTS*DCACHE_WAY_COUNT*LINE_BITS-1:0] dcachelinereadresp_data,

    // PendingWrite[load+store].
    input      [DCACHE_TOTAL_PORTS-1:0]                  pendingwrite_valid,
    input      [DCACHE_TOTAL_PORTS*DCACHE_SET_BITS-1:0]  pendingwrite_set_idx,
    input      [DCACHE_TOTAL_PORTS*DCACHE_WAY_BITS-1:0]  pendingwrite_way_idx,
    input      [DCACHE_TOTAL_PORTS*DCACHE_OFFSET_BITS-1:0] pendingwrite_word_off,
    input      [DCACHE_TOTAL_PORTS*DATA_BITS-1:0]        pendingwrite_data,
    input      [DCACHE_TOTAL_PORTS*STRB_BITS-1:0]        pendingwrite_strb,

    // LruUpdate[load+store].
    input      [DCACHE_TOTAL_PORTS-1:0]                  lru_updates_valid,
    input      [DCACHE_TOTAL_PORTS*DCACHE_SET_BITS-1:0]  lru_updates_set_idx,
    input      [DCACHE_TOTAL_PORTS*DCACHE_WAY_BITS-1:0]  lru_updates_way,

    // FILLWrite.
    input                                           fill_write_valid,
    input      [DCACHE_MSHR_BITS-1:0]               fill_write_id,
    input                                           fill_write_dirty,
    input      [DCACHE_SET_BITS-1:0]                fill_write_set_idx,
    input      [DCACHE_TAG_BITS-1:0]                fill_write_tag,
    input      [DCACHE_WAY_BITS-1:0]                fill_write_way_idx,
    input      [LINE_BITS-1:0]                      fill_write_data,

    // FillOut.
    input                                           fillout_valid,
    input      [DCACHE_SET_BITS-1:0]                fillout_set_idx,

    // FillIn snapshot.
    output     [DCACHE_WAY_COUNT-1:0]               fillin_valid_snap,
    output     [DCACHE_WAY_COUNT-1:0]               fillin_dirty_snap,
    output     [DCACHE_WAY_COUNT*DCACHE_TAG_BITS-1:0] fillin_tag_snap,
    output     [DCACHE_WAY_COUNT*LINE_BITS-1:0]     fillin_data_snap,
    output     [DCACHE_PLRU_TREE_BITS-1:0]          fillin_plru_tree_state
);

    assign dcachelinereadresp_valid = {DCACHE_TOTAL_PORTS*DCACHE_WAY_COUNT{1'b0}};
    assign dcachelinereadresp_tag   = {DCACHE_TOTAL_PORTS*DCACHE_WAY_COUNT*DCACHE_TAG_BITS{1'b0}};
    assign dcachelinereadresp_dirty = {DCACHE_TOTAL_PORTS*DCACHE_WAY_COUNT{1'b0}};
    assign dcachelinereadresp_data  = {DCACHE_TOTAL_PORTS*DCACHE_WAY_COUNT*LINE_BITS{1'b0}};

    assign fillin_valid_snap        = {DCACHE_WAY_COUNT{1'b0}};
    assign fillin_dirty_snap        = {DCACHE_WAY_COUNT{1'b0}};
    assign fillin_tag_snap          = {DCACHE_WAY_COUNT*DCACHE_TAG_BITS{1'b0}};
    assign fillin_data_snap         = {DCACHE_WAY_COUNT*LINE_BITS{1'b0}};
    assign fillin_plru_tree_state   = {DCACHE_PLRU_TREE_BITS{1'b0}};

endmodule
