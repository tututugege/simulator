`timescale 1ns / 1ps
`include "axi_llc_params.vh"
`include "qm3_cpu_params.vh"

// DCache write-buffer boundary shell.
//
// The DCache-facing ports mirror the simulator DcacheWBIO/WBDcacheIO shape.
// The LLC-facing ports are the existing DCache write-master channel. Internal
// FIFOing, merge, bypass, and writeback issue logic are intentionally empty.
module dcache_write_buffer_top #(
    parameter ADDR_BITS              = `AXI_LLC_ADDR_BITS,
    parameter DATA_BITS              = `QM3_DATA_BITS,
    parameter STRB_BITS              = `QM3_STRB_BITS,
    parameter LSU_LDU_COUNT          = `QM3_LSU_LDU_COUNT,
    parameter LSU_STA_COUNT          = `QM3_LSU_STA_COUNT,
    parameter DCACHE_WB_ENTRIES      = `QM3_DCACHE_WB_ENTRIES,
    parameter ID_BITS                = `AXI_LLC_ID_BITS,
    parameter LINE_BITS              = `AXI_LLC_LINE_BITS,
    parameter LINE_BYTES             = `AXI_LLC_LINE_BYTES,
    parameter DCACHE_WB_BITS         = $clog2(DCACHE_WB_ENTRIES),
    parameter DCACHE_WB_COUNT_BITS   = DCACHE_WB_BITS + 1
) (
    input                                           clk,
    input                                           rst_n,

    // DcacheWBIO.dirty_info.
    input                                           dirty_info_valid,
    input      [ADDR_BITS-1:0]                     dirty_info_addr,
    input      [LINE_BITS-1:0]                     dirty_info_data,

    // DcacheWBIO.bypass_req / WBDcacheIO.bypass_resp.
    input      [LSU_LDU_COUNT-1:0]                 bypass_req_valid,
    input      [LSU_LDU_COUNT*ADDR_BITS-1:0]       bypass_req_addr,
    output     [LSU_LDU_COUNT-1:0]                 bypass_resp_valid,
    output     [LSU_LDU_COUNT*DATA_BITS-1:0]       bypass_resp_data,

    // DcacheWBIO.merge_req / WBDcacheIO.merge_resp.
    input      [LSU_STA_COUNT-1:0]                 merge_req_valid,
    input      [LSU_STA_COUNT*ADDR_BITS-1:0]       merge_req_addr,
    input      [LSU_STA_COUNT*DATA_BITS-1:0]       merge_req_data,
    input      [LSU_STA_COUNT*STRB_BITS-1:0]       merge_req_strb,
    output     [LSU_STA_COUNT-1:0]                 merge_resp_valid,
    output     [LSU_STA_COUNT-1:0]                 merge_resp_busy,

    // WBDcacheIO.free.
    output     [DCACHE_WB_COUNT_BITS-1:0]          free,

    // LLC write path.
    output                                          dcache_llc_write_req_valid,
    input                                           dcache_llc_write_req_ready,
    input                                           dcache_llc_write_req_accepted,
    output     [ADDR_BITS-1:0]                     dcache_llc_write_req_addr,
    output     [LINE_BITS-1:0]                     dcache_llc_write_req_wdata,
    output     [LINE_BYTES-1:0]                    dcache_llc_write_req_wstrb,
    output     [7:0]                                dcache_llc_write_req_total_size,
    output     [ID_BITS-1:0]                        dcache_llc_write_req_id,
    output                                          dcache_llc_write_req_bypass,
    input                                           dcache_llc_write_resp_valid,
    output                                          dcache_llc_write_resp_ready,
    input      [ID_BITS-1:0]                        dcache_llc_write_resp_id,
    input      [1:0]                                dcache_llc_write_resp_code
);

    assign bypass_resp_valid             = {LSU_LDU_COUNT{1'b0}};
    assign bypass_resp_data              = {LSU_LDU_COUNT*DATA_BITS{1'b0}};
    assign merge_resp_valid              = {LSU_STA_COUNT{1'b0}};
    assign merge_resp_busy               = {LSU_STA_COUNT{1'b0}};
    assign free                          = {DCACHE_WB_COUNT_BITS{1'b0}};

    assign dcache_llc_write_req_valid      = 1'b0;
    assign dcache_llc_write_req_addr       = {ADDR_BITS{1'b0}};
    assign dcache_llc_write_req_wdata      = {LINE_BITS{1'b0}};
    assign dcache_llc_write_req_wstrb      = {LINE_BYTES{1'b0}};
    assign dcache_llc_write_req_total_size = 8'b0;
    assign dcache_llc_write_req_id         = {ID_BITS{1'b0}};
    assign dcache_llc_write_req_bypass     = 1'b0;
    assign dcache_llc_write_resp_ready     = 1'b0;

endmodule
