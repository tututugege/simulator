`timescale 1ns / 1ps
`include "axi_llc_params.vh"

// Thin shell for the AXI/LLC dual-port subsystem.
//
// TODO:
// 1. Replace the idle AXI/LLC tie-offs with an instantiated dual-port
//    axi_llc_subsystem shell/RTL.
// 2. Add a real maintenance controller for mapped-offset and invalidate
//    requests when those controls are no longer fixed internally.
//
// The CPU-facing boundary exposes only memory requests and the two AXI4
// master ports. The mode request comes from cpu_top, while mapped-offset and
// invalidate controls stay local to this wrapper; when axi_llc_subsystem_dual
// is instantiated, those local tie-offs can be replaced by an internal
// maintenance controller. clk is the high-frequency AXI/LLC clock; cpu_clk is
// the low-frequency core clock used to qualify the CPU-facing handshake
// boundary.
module axi_subsystem_top #(
    parameter ADDR_BITS          = `AXI_LLC_ADDR_BITS,
    parameter ID_BITS            = `AXI_LLC_ID_BITS,
    parameter SLOT_ID_BITS       = `AXI_LLC_SLOT_ID_BITS,
    parameter MODE_BITS          = `AXI_LLC_MODE_BITS,
    parameter LINE_BYTES         = `AXI_LLC_LINE_BYTES,
    parameter LINE_BITS          = `AXI_LLC_LINE_BITS,
    parameter LINE_OFFSET_BITS   = `AXI_LLC_LINE_OFFSET_BITS,
    // 0: 3e13836 simulator default LLC (4 MiB, 16-way).
    // 1: shell-only FPGA profile (64 KiB, 4-way).
    parameter FPGA_KB_LLC        = 0,
    parameter SET_COUNT          = FPGA_KB_LLC ? `AXI_LLC_FPGA_SET_COUNT : `AXI_LLC_SET_COUNT,
    parameter SET_BITS           = FPGA_KB_LLC ? `AXI_LLC_FPGA_SET_BITS : `AXI_LLC_SET_BITS,
    parameter WAY_COUNT          = FPGA_KB_LLC ? `AXI_LLC_FPGA_WAY_COUNT : `AXI_LLC_WAY_COUNT,
    parameter WAY_BITS           = FPGA_KB_LLC ? `AXI_LLC_FPGA_WAY_BITS : `AXI_LLC_WAY_BITS,
    parameter META_BITS          = `AXI_LLC_META_BITS,
    parameter LLC_SIZE_BYTES     = FPGA_KB_LLC ? `AXI_LLC_FPGA_LLC_SIZE_BYTES : `AXI_LLC_LLC_SIZE_BYTES,
    parameter WINDOW_BYTES       = FPGA_KB_LLC ? `AXI_LLC_FPGA_WINDOW_BYTES : `AXI_LLC_WINDOW_BYTES,
    parameter WINDOW_WAYS        = FPGA_KB_LLC ? `AXI_LLC_FPGA_WINDOW_WAYS : `AXI_LLC_WINDOW_WAYS,
    parameter MMIO_BASE          = `AXI_LLC_MMIO_BASE,
    parameter MMIO_SIZE          = `AXI_LLC_MMIO_SIZE,
    parameter DDR_BASE           = 32'h4000_0000,
    parameter RESET_MODE         = {{(`AXI_LLC_MODE_BITS-2){1'b0}}, 2'b01},
    parameter RESET_OFFSET       = {`AXI_LLC_ADDR_BITS{1'b0}},
    parameter AXI_SUBSYSTEM_FREQ_DIV = `AXI_SUBSYSTEM_FREQ_DIV_DEFAULT,
    parameter USE_SMIC12_STORES  = 1,
    parameter TABLE_READ_LATENCY = `AXI_LLC_TABLE_READ_LATENCY,
    parameter NUM_READ_MASTERS   = 4,
    parameter NUM_WRITE_MASTERS  = 2,
    parameter DDR_AXI_ID_BITS    = `AXI_LLC_AXI_ID_BITS,
    parameter DDR_AXI_DATA_BYTES = `AXI_LLC_AXI_DATA_BYTES,
    parameter DDR_AXI_DATA_BITS  = `AXI_LLC_AXI_DATA_BITS,
    parameter DDR_AXI_STRB_BITS  = `AXI_LLC_AXI_STRB_BITS,
    parameter MMIO_AXI_ID_BITS   = `AXI_LLC_AXI_ID_BITS,
    parameter MMIO_AXI_DATA_BYTES = 4,
    parameter MMIO_AXI_DATA_BITS = 32,
    parameter MMIO_AXI_STRB_BITS = 4,
    parameter READ_RESP_BYTES    = `AXI_LLC_READ_RESP_BYTES,
    parameter READ_RESP_BITS     = `AXI_LLC_READ_RESP_BITS
) (
    // High-frequency AXI/LLC/DDR clock.
    input                                   clk,
    // Low-frequency CPU/mem-subsystem handshake clock.
    input                                   cpu_clk,
    input                                   rst_n,
    // axi_llc_subsystem_dual mode request from cpu_top.
    // 2'b01: LLC_ON, 2'b10: mapped-window mode, 2'b00/2'b11: LLC_OFF
    // (direct-bypass inside the LLC subsystem).
    input      [MODE_BITS-1:0]              mode,

    // axi-interconnect-kit ReadMasterReq_t.req from mem_subsystem_top.
    input      [NUM_READ_MASTERS-1:0]       read_req_valid,
    output     [NUM_READ_MASTERS-1:0]       read_req_ready,
    output     [NUM_READ_MASTERS-1:0]       read_req_accepted,
    output     [NUM_READ_MASTERS*ID_BITS-1:0] read_req_accepted_id,
    input      [NUM_READ_MASTERS*ADDR_BITS-1:0] read_req_addr,
    input      [NUM_READ_MASTERS*8-1:0]     read_req_total_size,
    input      [NUM_READ_MASTERS*ID_BITS-1:0] read_req_id,
    input      [NUM_READ_MASTERS-1:0]       read_req_bypass,

    // axi-interconnect-kit ReadMasterResp_t.resp to mem_subsystem_top.
    output     [NUM_READ_MASTERS-1:0]       read_resp_valid,
    input      [NUM_READ_MASTERS-1:0]       read_resp_ready,
    output     [NUM_READ_MASTERS*READ_RESP_BITS-1:0] read_resp_data,
    output     [NUM_READ_MASTERS*ID_BITS-1:0] read_resp_id,

    // axi-interconnect-kit WriteMasterReq_t.req from mem_subsystem_top.
    input      [NUM_WRITE_MASTERS-1:0]      write_req_valid,
    output     [NUM_WRITE_MASTERS-1:0]      write_req_ready,
    output     [NUM_WRITE_MASTERS-1:0]      write_req_accepted,
    input      [NUM_WRITE_MASTERS*ADDR_BITS-1:0] write_req_addr,
    input      [NUM_WRITE_MASTERS*LINE_BITS-1:0] write_req_wdata,
    input      [NUM_WRITE_MASTERS*LINE_BYTES-1:0] write_req_wstrb,
    input      [NUM_WRITE_MASTERS*8-1:0]    write_req_total_size,
    input      [NUM_WRITE_MASTERS*ID_BITS-1:0] write_req_id,
    input      [NUM_WRITE_MASTERS-1:0]      write_req_bypass,

    // axi-interconnect-kit WriteMasterResp_t.resp to mem_subsystem_top.
    output     [NUM_WRITE_MASTERS-1:0]      write_resp_valid,
    input      [NUM_WRITE_MASTERS-1:0]      write_resp_ready,
    output     [NUM_WRITE_MASTERS*ID_BITS-1:0] write_resp_id,
    output     [NUM_WRITE_MASTERS*2-1:0]    write_resp_code,

    // DDR/SDRAM AXI4 master interface to cpu_top DDR pins.
    output                                  ddr_axi_awvalid,
    input                                   ddr_axi_awready,
    output     [DDR_AXI_ID_BITS-1:0]        ddr_axi_awid,
    output     [ADDR_BITS-1:0]              ddr_axi_awaddr,
    output     [7:0]                        ddr_axi_awlen,
    output     [2:0]                        ddr_axi_awsize,
    output     [1:0]                        ddr_axi_awburst,
    output                                  ddr_axi_wvalid,
    input                                   ddr_axi_wready,
    output     [DDR_AXI_DATA_BITS-1:0]      ddr_axi_wdata,
    output     [DDR_AXI_STRB_BITS-1:0]      ddr_axi_wstrb,
    output                                  ddr_axi_wlast,
    input                                   ddr_axi_bvalid,
    output                                  ddr_axi_bready,
    input      [DDR_AXI_ID_BITS-1:0]        ddr_axi_bid,
    input      [1:0]                        ddr_axi_bresp,
    output                                  ddr_axi_arvalid,
    input                                   ddr_axi_arready,
    output     [DDR_AXI_ID_BITS-1:0]        ddr_axi_arid,
    output     [ADDR_BITS-1:0]              ddr_axi_araddr,
    output     [7:0]                        ddr_axi_arlen,
    output     [2:0]                        ddr_axi_arsize,
    output     [1:0]                        ddr_axi_arburst,
    input                                   ddr_axi_rvalid,
    output                                  ddr_axi_rready,
    input      [DDR_AXI_ID_BITS-1:0]        ddr_axi_rid,
    input      [DDR_AXI_DATA_BITS-1:0]      ddr_axi_rdata,
    input      [1:0]                        ddr_axi_rresp,
    input                                   ddr_axi_rlast,

    // MMIO AXI4 master interface to cpu_top MMIO pins.
    output                                  mmio_axi_awvalid,
    input                                   mmio_axi_awready,
    output     [MMIO_AXI_ID_BITS-1:0]       mmio_axi_awid,
    output     [ADDR_BITS-1:0]              mmio_axi_awaddr,
    output     [7:0]                        mmio_axi_awlen,
    output     [2:0]                        mmio_axi_awsize,
    output     [1:0]                        mmio_axi_awburst,
    output                                  mmio_axi_wvalid,
    input                                   mmio_axi_wready,
    output     [MMIO_AXI_DATA_BITS-1:0]     mmio_axi_wdata,
    output     [MMIO_AXI_STRB_BITS-1:0]     mmio_axi_wstrb,
    output                                  mmio_axi_wlast,
    input                                   mmio_axi_bvalid,
    output                                  mmio_axi_bready,
    input      [MMIO_AXI_ID_BITS-1:0]       mmio_axi_bid,
    input      [1:0]                        mmio_axi_bresp,
    output                                  mmio_axi_arvalid,
    input                                   mmio_axi_arready,
    output     [MMIO_AXI_ID_BITS-1:0]       mmio_axi_arid,
    output     [ADDR_BITS-1:0]              mmio_axi_araddr,
    output     [7:0]                        mmio_axi_arlen,
    output     [2:0]                        mmio_axi_arsize,
    output     [1:0]                        mmio_axi_arburst,
    input                                   mmio_axi_rvalid,
    output                                  mmio_axi_rready,
    input      [MMIO_AXI_ID_BITS-1:0]       mmio_axi_rid,
    input      [MMIO_AXI_DATA_BITS-1:0]     mmio_axi_rdata,
    input      [1:0]                        mmio_axi_rresp,
    input                                   mmio_axi_rlast
);

    localparam [1:0] AXI_BURST_FIXED = 2'b00;
    localparam [1:0] AXI_BURST_INCR  = 2'b01;

    // Local maintenance defaults for the future axi_llc_subsystem_dual
    // instance. Mapped offset and invalidation are intentionally fixed while
    // this module is only a shell; they are not part of the cpu_top boundary.
    wire [MODE_BITS-1:0] llc_mode_req;
    wire [ADDR_BITS-1:0] llc_mapped_offset_req;
    wire                 llc_invalidate_line_valid;
    wire [ADDR_BITS-1:0] llc_invalidate_line_addr;
    wire                 llc_invalidate_all_valid;

    assign llc_mode_req                = rst_n ? mode : RESET_MODE;
    assign llc_mapped_offset_req       = RESET_OFFSET;
    assign llc_invalidate_line_valid   = 1'b0;
    assign llc_invalidate_line_addr    = {ADDR_BITS{1'b0}};
    assign llc_invalidate_all_valid    = 1'b0;

    assign read_req_ready           = {NUM_READ_MASTERS{1'b0}};
    assign read_req_accepted        = {NUM_READ_MASTERS{1'b0}};
    assign read_req_accepted_id     = {NUM_READ_MASTERS*ID_BITS{1'b0}};
    assign read_resp_valid          = {NUM_READ_MASTERS{1'b0}};
    assign read_resp_data           = {NUM_READ_MASTERS*READ_RESP_BITS{1'b0}};
    assign read_resp_id             = {NUM_READ_MASTERS*ID_BITS{1'b0}};

    assign write_req_ready          = {NUM_WRITE_MASTERS{1'b0}};
    assign write_req_accepted       = {NUM_WRITE_MASTERS{1'b0}};
    assign write_resp_valid         = {NUM_WRITE_MASTERS{1'b0}};
    assign write_resp_id            = {NUM_WRITE_MASTERS*ID_BITS{1'b0}};
    assign write_resp_code          = {NUM_WRITE_MASTERS*2{1'b0}};

    assign ddr_axi_awvalid          = 1'b0;
    assign ddr_axi_awid             = {DDR_AXI_ID_BITS{1'b0}};
    assign ddr_axi_awaddr           = {ADDR_BITS{1'b0}};
    assign ddr_axi_awlen            = 8'b0;
    assign ddr_axi_awsize           = 3'b0;
    assign ddr_axi_wvalid           = 1'b0;
    assign ddr_axi_wdata            = {DDR_AXI_DATA_BITS{1'b0}};
    assign ddr_axi_wstrb            = {DDR_AXI_STRB_BITS{1'b0}};
    assign ddr_axi_wlast            = 1'b0;
    assign ddr_axi_bready           = 1'b0;
    assign ddr_axi_arvalid          = 1'b0;
    assign ddr_axi_arid             = {DDR_AXI_ID_BITS{1'b0}};
    assign ddr_axi_araddr           = {ADDR_BITS{1'b0}};
    assign ddr_axi_arlen            = 8'b0;
    assign ddr_axi_arsize           = 3'b0;
    assign ddr_axi_rready           = 1'b0;

    assign mmio_axi_awvalid         = 1'b0;
    assign mmio_axi_awid            = {MMIO_AXI_ID_BITS{1'b0}};
    assign mmio_axi_awaddr          = {ADDR_BITS{1'b0}};
    assign mmio_axi_awlen           = 8'b0;
    assign mmio_axi_awsize          = 3'b0;
    assign mmio_axi_wvalid          = 1'b0;
    assign mmio_axi_wdata           = {MMIO_AXI_DATA_BITS{1'b0}};
    assign mmio_axi_wstrb           = {MMIO_AXI_STRB_BITS{1'b0}};
    assign mmio_axi_wlast           = 1'b0;
    assign mmio_axi_bready          = 1'b0;
    assign mmio_axi_arvalid         = 1'b0;
    assign mmio_axi_arid            = {MMIO_AXI_ID_BITS{1'b0}};
    assign mmio_axi_araddr          = {ADDR_BITS{1'b0}};
    assign mmio_axi_arlen           = 8'b0;
    assign mmio_axi_arsize          = 3'b0;
    assign mmio_axi_rready          = 1'b0;

    // Intentional shell defaults. DDR follows the dual AXI memory path. MMIO
    // stays FIXED at this wrapper boundary to match RISCV_cpu_top.v defaults;
    // the real dual bridge currently emits INCR for both ports, so integration
    // will need an explicit decision here.
    assign ddr_axi_awburst          = AXI_BURST_INCR;
    assign ddr_axi_arburst          = AXI_BURST_INCR;
    assign mmio_axi_awburst         = AXI_BURST_FIXED;
    assign mmio_axi_arburst         = AXI_BURST_FIXED;

endmodule
