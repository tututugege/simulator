`timescale 1ns / 1ps
`include "axi_llc_params.vh"
`include "qm3_cpu_params.vh"

// Back-end shell.
//
// TODO:
// 1. Keep this wrapper as glue while replacing backend_core_top, lsu_top, and
//    dtlb_top with real or generated RTL.
// 2. Add queue/regfile/template interfaces below child tops before training or
//    generating backend internals.
//
// Interface names are flattened versions of simulator back-end IO structs:
// FrontPreIO/PreFrontIO, Back_out, PeripheralReqIO/RespIO, DTLB PtwMemPort/
// PtwWalkPort, and LsuDcacheIO/DcacheLsuIO. The RTL DTLB is owned by this
// backend shell; RealDcache is owned by mem_subsystem_top.
module backend_top #(
    parameter FETCH_WIDTH            = `QM3_FETCH_WIDTH,
    parameter DECODE_WIDTH           = `QM3_DECODE_WIDTH,
    parameter COMMIT_WIDTH           = `QM3_COMMIT_WIDTH,
    parameter ISSUE_WIDTH            = `QM3_ISSUE_WIDTH,
    parameter ALU_NUM                = `QM3_ALU_NUM,
    parameter BRU_NUM                = `QM3_BRU_NUM,
    parameter ROB_NUM                = `QM3_ROB_NUM,
    parameter LDQ_SIZE               = `QM3_LDQ_SIZE,
    parameter STQ_SIZE               = `QM3_STQ_SIZE,
    parameter LOAD_WINDOWS_WIDTH     = `QM3_LOAD_WINDOWS_WIDTH,
    parameter STORE_WINDOWS_WIDTH    = `QM3_STORE_WINDOWS_WIDTH,
    parameter TN_MAX                 = `QM3_TN_MAX,
    parameter PC_BITS                = `QM3_PC_BITS,
    parameter INST_BITS              = `QM3_INST_BITS,
    parameter ADDR_BITS              = `AXI_LLC_ADDR_BITS,
    parameter DATA_BITS              = `QM3_DATA_BITS,
    parameter STRB_BITS              = `QM3_STRB_BITS,
    parameter CSR_BITS               = `QM3_CSR_BITS,
    parameter PRIVILEGE_BITS         = `QM3_PRIVILEGE_BITS,
    parameter PCPN_BITS              = `QM3_PCPN_BITS,
    parameter BR_TYPE_BITS           = `QM3_BR_TYPE_BITS,
    parameter TAGE_IDX_BITS          = `QM3_TAGE_IDX_BITS,
    parameter TAGE_TAG_BITS          = `QM3_TAGE_TAG_BITS,
    parameter BPU_SCL_META_NTABLE    = `QM3_BPU_SCL_META_NTABLE,
    parameter BPU_SCL_META_IDX_BITS  = `QM3_BPU_SCL_META_IDX_BITS,
    parameter BPU_SCL_META_SUM_BITS  = `QM3_BPU_SCL_META_SUM_BITS,
    parameter BPU_LOOP_META_IDX_BITS = `QM3_BPU_LOOP_META_IDX_BITS,
    parameter BPU_LOOP_META_TAG_BITS = `QM3_BPU_LOOP_META_TAG_BITS,
    parameter LSU_LDU_COUNT          = `QM3_LSU_LDU_COUNT,
    parameter LSU_STA_COUNT          = `QM3_LSU_STA_COUNT,
    parameter LSU_SDU_COUNT          = `QM3_LSU_SDU_COUNT,
    parameter LSU_LDU_WIDTH          = `QM3_LSU_LDU_WIDTH,
    parameter LSU_REQ_ID_BITS        = `QM3_LSU_REQ_ID_BITS,
    parameter REPLAY_BITS            = `QM3_REPLAY_BITS,
    parameter MMU_RESULT_BITS        = `QM3_MMU_RESULT_BITS,
    parameter DTLB_ENTRIES           = `QM3_DTLB_ENTRIES,
    parameter PTW_ACCESS_TYPE_BITS   = `QM3_PTW_ACCESS_TYPE_BITS,
    parameter PTW_LEVEL_BITS         = `QM3_PTW_LEVEL_BITS,
    parameter PTE_BITS               = `QM3_PTE_BITS
) (
    input                                   aclk,
    input                                   aresetn,

    // FrontPreIO from frontend_top.front_top_out.
    input      [FETCH_WIDTH*INST_BITS-1:0]  front2pre_inst,
    input      [FETCH_WIDTH*PC_BITS-1:0]    front2pre_pc,
    input      [FETCH_WIDTH-1:0]            front2pre_valid,
    input                                   front2pre_front_stall,
    input      [FETCH_WIDTH-1:0]            front2pre_predict_dir,
    input      [FETCH_WIDTH-1:0]            front2pre_alt_pred,
    input      [FETCH_WIDTH*PCPN_BITS-1:0]  front2pre_altpcpn,
    input      [FETCH_WIDTH*PCPN_BITS-1:0]  front2pre_pcpn,
    input      [FETCH_WIDTH*PC_BITS-1:0]    front2pre_predict_next_fetch_address,
    input      [FETCH_WIDTH*TN_MAX*TAGE_IDX_BITS-1:0] front2pre_tage_idx,
    input      [FETCH_WIDTH*TN_MAX*TAGE_TAG_BITS-1:0] front2pre_tage_tag,
    input      [FETCH_WIDTH-1:0]            front2pre_sc_used,
    input      [FETCH_WIDTH-1:0]            front2pre_sc_pred,
    input      [FETCH_WIDTH*BPU_SCL_META_SUM_BITS-1:0] front2pre_sc_sum,
    input      [FETCH_WIDTH*BPU_SCL_META_NTABLE*BPU_SCL_META_IDX_BITS-1:0] front2pre_sc_idx,
    input      [FETCH_WIDTH-1:0]            front2pre_loop_used,
    input      [FETCH_WIDTH-1:0]            front2pre_loop_hit,
    input      [FETCH_WIDTH-1:0]            front2pre_loop_pred,
    input      [FETCH_WIDTH*BPU_LOOP_META_IDX_BITS-1:0] front2pre_loop_idx,
    input      [FETCH_WIDTH*BPU_LOOP_META_TAG_BITS-1:0] front2pre_loop_tag,
    input      [FETCH_WIDTH-1:0]            front2pre_page_fault_inst,

    // PreFrontIO to frontend_top.FIFO_read_enable generation.
    output     [FETCH_WIDTH-1:0]            pre2front_fire,
    output                                  pre2front_ready,

    // Back_out redirect/control to frontend_top.front_top_in.
    output                                  mispred,
    output                                  stall,
    output                                  flush,
    output                                  fence_i,
    output                                  itlb_flush,
    output     [PC_BITS-1:0]                redirect_pc,

    // Back_out commit/BPU update metadata to frontend_top.front_top_in.
    output     [COMMIT_WIDTH-1:0]           back2front_valid,
    output     [COMMIT_WIDTH*PC_BITS-1:0]   predict_base_pc,
    output     [COMMIT_WIDTH-1:0]           predict_dir,
    output     [COMMIT_WIDTH-1:0]           actual_dir,
    output     [COMMIT_WIDTH*BR_TYPE_BITS-1:0] actual_br_type,
    output     [COMMIT_WIDTH*PC_BITS-1:0]   actual_target,
    output     [COMMIT_WIDTH-1:0]           alt_pred,
    output     [COMMIT_WIDTH*PCPN_BITS-1:0] altpcpn,
    output     [COMMIT_WIDTH*PCPN_BITS-1:0] pcpn,
    output     [COMMIT_WIDTH*TN_MAX*TAGE_IDX_BITS-1:0] tage_idx,
    output     [COMMIT_WIDTH*TN_MAX*TAGE_TAG_BITS-1:0] tage_tag,
    output     [COMMIT_WIDTH-1:0]           sc_used,
    output     [COMMIT_WIDTH-1:0]           sc_pred,
    output     [COMMIT_WIDTH*BPU_SCL_META_SUM_BITS-1:0] sc_sum,
    output     [COMMIT_WIDTH*BPU_SCL_META_NTABLE*BPU_SCL_META_IDX_BITS-1:0] sc_idx,
    output     [COMMIT_WIDTH-1:0]           loop_used,
    output     [COMMIT_WIDTH-1:0]           loop_hit,
    output     [COMMIT_WIDTH-1:0]           loop_pred,
    output     [COMMIT_WIDTH*BPU_LOOP_META_IDX_BITS-1:0] loop_idx,
    output     [COMMIT_WIDTH*BPU_LOOP_META_TAG_BITS-1:0] loop_tag,

    // CsrStatusIO to frontend_top and mem_subsystem_top context logic.
    output     [CSR_BITS-1:0]               csr_status_sstatus,
    output     [CSR_BITS-1:0]               csr_status_mstatus,
    output     [CSR_BITS-1:0]               csr_status_satp,
    output     [PRIVILEGE_BITS-1:0]         csr_status_privilege,

    // PeripheralReqIO to mem_subsystem_top/MMIO path.
    output                                  peripheral_req_is_mmio,
    output                                  peripheral_req_wen,
    output     [ADDR_BITS-1:0]              peripheral_req_mmio_addr,
    output     [DATA_BITS-1:0]              peripheral_req_mmio_wdata,
    output     [2:0]                        peripheral_req_mmio_fun3,

    // PeripheralRespIO from mem_subsystem_top/MMIO path.
    input                                   peripheral_resp_is_mmio,
    input                                   peripheral_resp_ready,
    input      [DATA_BITS-1:0]              peripheral_resp_mmio_rdata,

    // DTLB PtwMemPortCombIn to mem_subsystem_top.
    output                                  dtlb_ptw_mem_req_valid,
    output     [ADDR_BITS-1:0]              dtlb_ptw_mem_req_addr,
    output                                  dtlb_ptw_mem_resp_consumed,

    // DTLB PtwMemPortCombOut from mem_subsystem_top.
    input                                   dtlb_ptw_mem_req_ready,
    input                                   dtlb_ptw_mem_resp_valid,
    input      [DATA_BITS-1:0]              dtlb_ptw_mem_resp_data,

    // DTLB PtwWalkPortCombIn to mem_subsystem_top.
    output                                  dtlb_walk_req_valid,
    output     [ADDR_BITS-1:0]              dtlb_walk_req_vaddr,
    output     [CSR_BITS-1:0]               dtlb_walk_req_satp,
    output     [PTW_ACCESS_TYPE_BITS-1:0]   dtlb_walk_req_access_type,
    output                                  dtlb_walk_resp_consumed,
    output                                  dtlb_walk_flush,

    // DTLB PtwWalkPortCombOut from mem_subsystem_top.
    input                                   dtlb_walk_req_ready,
    input                                   dtlb_walk_resp_valid,
    input                                   dtlb_walk_resp_fault,
    input      [ADDR_BITS-1:0]              dtlb_walk_resp_vaddr,
    input      [PTE_BITS-1:0]               dtlb_walk_resp_leaf_pte,
    input      [PTW_LEVEL_BITS-1:0]         dtlb_walk_resp_leaf_level,

    // LsuDcacheIO.req_ports to mem_subsystem_top/RealDcache.
    output     [LSU_LDU_COUNT-1:0]          lsu2dcache_load_ports_valid,
    output     [LSU_LDU_COUNT*ADDR_BITS-1:0] lsu2dcache_load_ports_addr,
    output     [LSU_LDU_COUNT*LSU_REQ_ID_BITS-1:0] lsu2dcache_load_ports_req_id,
    output     [LSU_STA_COUNT-1:0]          lsu2dcache_store_ports_valid,
    output     [LSU_STA_COUNT*ADDR_BITS-1:0] lsu2dcache_store_ports_addr,
    output     [LSU_STA_COUNT*DATA_BITS-1:0] lsu2dcache_store_ports_data,
    output     [LSU_STA_COUNT*STRB_BITS-1:0] lsu2dcache_store_ports_strb,
    output     [LSU_STA_COUNT*LSU_REQ_ID_BITS-1:0] lsu2dcache_store_ports_req_id,
    output     [LSU_LDU_WIDTH:0]            lsu2dcache_icache_req,

    // DcacheLsuIO.resp_ports from mem_subsystem_top/RealDcache.
    input      [LSU_LDU_COUNT-1:0]          dcache2lsu_load_resps_valid,
    input      [LSU_LDU_COUNT*DATA_BITS-1:0] dcache2lsu_load_resps_data,
    input      [LSU_LDU_COUNT*LSU_REQ_ID_BITS-1:0] dcache2lsu_load_resps_req_id,
    input      [LSU_LDU_COUNT*REPLAY_BITS-1:0] dcache2lsu_load_resps_replay,
    input      [LSU_STA_COUNT-1:0]          dcache2lsu_store_resps_valid,
    input      [LSU_STA_COUNT*REPLAY_BITS-1:0] dcache2lsu_store_resps_replay,
    input      [LSU_STA_COUNT*LSU_REQ_ID_BITS-1:0] dcache2lsu_store_resps_req_id,
    input                                   dcache2lsu_mshr_fill
);

    wire [LSU_LDU_COUNT-1:0]                  lsu_dtlb_ldq_req_valid;
    wire [LSU_LDU_COUNT*ADDR_BITS-1:0]        lsu_dtlb_ldq_req_vaddr;
    wire [LSU_STA_COUNT-1:0]                  lsu_dtlb_stq_req_valid;
    wire [LSU_STA_COUNT*ADDR_BITS-1:0]        lsu_dtlb_stq_req_vaddr;
    wire [LSU_LDU_COUNT-1:0]                  dtlb_lsu_ldq_resp_valid;
    wire [LSU_LDU_COUNT*ADDR_BITS-1:0]        dtlb_lsu_ldq_resp_paddr;
    wire [LSU_LDU_COUNT*MMU_RESULT_BITS-1:0]  dtlb_lsu_ldq_resp_result;
    wire [LSU_STA_COUNT-1:0]                  dtlb_lsu_stq_resp_valid;
    wire [LSU_STA_COUNT*ADDR_BITS-1:0]        dtlb_lsu_stq_resp_paddr;
    wire [LSU_STA_COUNT*MMU_RESULT_BITS-1:0]  dtlb_lsu_stq_resp_result;

    backend_core_top #(
        .FETCH_WIDTH(FETCH_WIDTH),
        .COMMIT_WIDTH(COMMIT_WIDTH),
        .TN_MAX(TN_MAX),
        .PC_BITS(PC_BITS),
        .INST_BITS(INST_BITS),
        .CSR_BITS(CSR_BITS),
        .PRIVILEGE_BITS(PRIVILEGE_BITS),
        .PCPN_BITS(PCPN_BITS),
        .BR_TYPE_BITS(BR_TYPE_BITS),
        .TAGE_IDX_BITS(TAGE_IDX_BITS),
        .TAGE_TAG_BITS(TAGE_TAG_BITS),
        .BPU_SCL_META_NTABLE(BPU_SCL_META_NTABLE),
        .BPU_SCL_META_IDX_BITS(BPU_SCL_META_IDX_BITS),
        .BPU_SCL_META_SUM_BITS(BPU_SCL_META_SUM_BITS),
        .BPU_LOOP_META_IDX_BITS(BPU_LOOP_META_IDX_BITS),
        .BPU_LOOP_META_TAG_BITS(BPU_LOOP_META_TAG_BITS)
    ) u_backend_core_top (
        .aclk(aclk),
        .aresetn(aresetn),
        .front2pre_inst(front2pre_inst),
        .front2pre_pc(front2pre_pc),
        .front2pre_valid(front2pre_valid),
        .front2pre_front_stall(front2pre_front_stall),
        .front2pre_predict_dir(front2pre_predict_dir),
        .front2pre_alt_pred(front2pre_alt_pred),
        .front2pre_altpcpn(front2pre_altpcpn),
        .front2pre_pcpn(front2pre_pcpn),
        .front2pre_predict_next_fetch_address(front2pre_predict_next_fetch_address),
        .front2pre_tage_idx(front2pre_tage_idx),
        .front2pre_tage_tag(front2pre_tage_tag),
        .front2pre_sc_used(front2pre_sc_used),
        .front2pre_sc_pred(front2pre_sc_pred),
        .front2pre_sc_sum(front2pre_sc_sum),
        .front2pre_sc_idx(front2pre_sc_idx),
        .front2pre_loop_used(front2pre_loop_used),
        .front2pre_loop_hit(front2pre_loop_hit),
        .front2pre_loop_pred(front2pre_loop_pred),
        .front2pre_loop_idx(front2pre_loop_idx),
        .front2pre_loop_tag(front2pre_loop_tag),
        .front2pre_page_fault_inst(front2pre_page_fault_inst),
        .pre2front_fire(pre2front_fire),
        .pre2front_ready(pre2front_ready),
        .mispred(mispred),
        .stall(stall),
        .flush(flush),
        .fence_i(fence_i),
        .itlb_flush(itlb_flush),
        .redirect_pc(redirect_pc),
        .back2front_valid(back2front_valid),
        .predict_base_pc(predict_base_pc),
        .predict_dir(predict_dir),
        .actual_dir(actual_dir),
        .actual_br_type(actual_br_type),
        .actual_target(actual_target),
        .alt_pred(alt_pred),
        .altpcpn(altpcpn),
        .pcpn(pcpn),
        .tage_idx(tage_idx),
        .tage_tag(tage_tag),
        .sc_used(sc_used),
        .sc_pred(sc_pred),
        .sc_sum(sc_sum),
        .sc_idx(sc_idx),
        .loop_used(loop_used),
        .loop_hit(loop_hit),
        .loop_pred(loop_pred),
        .loop_idx(loop_idx),
        .loop_tag(loop_tag),
        .csr_status_sstatus(csr_status_sstatus),
        .csr_status_mstatus(csr_status_mstatus),
        .csr_status_satp(csr_status_satp),
        .csr_status_privilege(csr_status_privilege)
    );

    lsu_top #(
        .ADDR_BITS(ADDR_BITS),
        .DATA_BITS(DATA_BITS),
        .STRB_BITS(STRB_BITS),
        .CSR_BITS(CSR_BITS),
        .PRIVILEGE_BITS(PRIVILEGE_BITS),
        .LSU_LDU_COUNT(LSU_LDU_COUNT),
        .LSU_STA_COUNT(LSU_STA_COUNT),
        .LSU_LDU_WIDTH(LSU_LDU_WIDTH),
        .LSU_REQ_ID_BITS(LSU_REQ_ID_BITS),
        .REPLAY_BITS(REPLAY_BITS),
        .MMU_RESULT_BITS(MMU_RESULT_BITS)
    ) u_lsu_top (
        .clk(aclk),
        .rst_n(aresetn),
        .csr_status_sstatus(csr_status_sstatus),
        .csr_status_mstatus(csr_status_mstatus),
        .csr_status_satp(csr_status_satp),
        .csr_status_privilege(csr_status_privilege),
        .lsu_dtlb_ldq_req_valid(lsu_dtlb_ldq_req_valid),
        .lsu_dtlb_ldq_req_vaddr(lsu_dtlb_ldq_req_vaddr),
        .lsu_dtlb_stq_req_valid(lsu_dtlb_stq_req_valid),
        .lsu_dtlb_stq_req_vaddr(lsu_dtlb_stq_req_vaddr),
        .dtlb_lsu_ldq_resp_valid(dtlb_lsu_ldq_resp_valid),
        .dtlb_lsu_ldq_resp_paddr(dtlb_lsu_ldq_resp_paddr),
        .dtlb_lsu_ldq_resp_result(dtlb_lsu_ldq_resp_result),
        .dtlb_lsu_stq_resp_valid(dtlb_lsu_stq_resp_valid),
        .dtlb_lsu_stq_resp_paddr(dtlb_lsu_stq_resp_paddr),
        .dtlb_lsu_stq_resp_result(dtlb_lsu_stq_resp_result),
        .peripheral_req_is_mmio(peripheral_req_is_mmio),
        .peripheral_req_wen(peripheral_req_wen),
        .peripheral_req_mmio_addr(peripheral_req_mmio_addr),
        .peripheral_req_mmio_wdata(peripheral_req_mmio_wdata),
        .peripheral_req_mmio_fun3(peripheral_req_mmio_fun3),
        .peripheral_resp_is_mmio(peripheral_resp_is_mmio),
        .peripheral_resp_ready(peripheral_resp_ready),
        .peripheral_resp_mmio_rdata(peripheral_resp_mmio_rdata),
        .lsu2dcache_load_ports_valid(lsu2dcache_load_ports_valid),
        .lsu2dcache_load_ports_addr(lsu2dcache_load_ports_addr),
        .lsu2dcache_load_ports_req_id(lsu2dcache_load_ports_req_id),
        .lsu2dcache_store_ports_valid(lsu2dcache_store_ports_valid),
        .lsu2dcache_store_ports_addr(lsu2dcache_store_ports_addr),
        .lsu2dcache_store_ports_data(lsu2dcache_store_ports_data),
        .lsu2dcache_store_ports_strb(lsu2dcache_store_ports_strb),
        .lsu2dcache_store_ports_req_id(lsu2dcache_store_ports_req_id),
        .lsu2dcache_icache_req(lsu2dcache_icache_req),
        .dcache2lsu_load_resps_valid(dcache2lsu_load_resps_valid),
        .dcache2lsu_load_resps_data(dcache2lsu_load_resps_data),
        .dcache2lsu_load_resps_req_id(dcache2lsu_load_resps_req_id),
        .dcache2lsu_load_resps_replay(dcache2lsu_load_resps_replay),
        .dcache2lsu_store_resps_valid(dcache2lsu_store_resps_valid),
        .dcache2lsu_store_resps_replay(dcache2lsu_store_resps_replay),
        .dcache2lsu_store_resps_req_id(dcache2lsu_store_resps_req_id),
        .dcache2lsu_mshr_fill(dcache2lsu_mshr_fill)
    );

    dtlb_top #(
        .ADDR_BITS(ADDR_BITS),
        .DATA_BITS(DATA_BITS),
        .CSR_BITS(CSR_BITS),
        .PRIVILEGE_BITS(PRIVILEGE_BITS),
        .LSU_LDU_COUNT(LSU_LDU_COUNT),
        .LSU_STA_COUNT(LSU_STA_COUNT),
        .MMU_RESULT_BITS(MMU_RESULT_BITS),
        .DTLB_ENTRIES(DTLB_ENTRIES),
        .PTW_ACCESS_TYPE_BITS(PTW_ACCESS_TYPE_BITS),
        .PTW_LEVEL_BITS(PTW_LEVEL_BITS),
        .PTE_BITS(PTE_BITS)
    ) u_dtlb_top (
        .clk(aclk),
        .rst_n(aresetn),
        .flush(flush),
        .csr_status_sstatus(csr_status_sstatus),
        .csr_status_mstatus(csr_status_mstatus),
        .csr_status_satp(csr_status_satp),
        .csr_status_privilege(csr_status_privilege),
        .lsu_dtlb_ldq_req_valid(lsu_dtlb_ldq_req_valid),
        .lsu_dtlb_ldq_req_vaddr(lsu_dtlb_ldq_req_vaddr),
        .lsu_dtlb_stq_req_valid(lsu_dtlb_stq_req_valid),
        .lsu_dtlb_stq_req_vaddr(lsu_dtlb_stq_req_vaddr),
        .dtlb_lsu_ldq_resp_valid(dtlb_lsu_ldq_resp_valid),
        .dtlb_lsu_ldq_resp_paddr(dtlb_lsu_ldq_resp_paddr),
        .dtlb_lsu_ldq_resp_result(dtlb_lsu_ldq_resp_result),
        .dtlb_lsu_stq_resp_valid(dtlb_lsu_stq_resp_valid),
        .dtlb_lsu_stq_resp_paddr(dtlb_lsu_stq_resp_paddr),
        .dtlb_lsu_stq_resp_result(dtlb_lsu_stq_resp_result),
        .dtlb_ptw_mem_req_valid(dtlb_ptw_mem_req_valid),
        .dtlb_ptw_mem_req_addr(dtlb_ptw_mem_req_addr),
        .dtlb_ptw_mem_resp_consumed(dtlb_ptw_mem_resp_consumed),
        .dtlb_ptw_mem_req_ready(dtlb_ptw_mem_req_ready),
        .dtlb_ptw_mem_resp_valid(dtlb_ptw_mem_resp_valid),
        .dtlb_ptw_mem_resp_data(dtlb_ptw_mem_resp_data),
        .dtlb_walk_req_valid(dtlb_walk_req_valid),
        .dtlb_walk_req_vaddr(dtlb_walk_req_vaddr),
        .dtlb_walk_req_satp(dtlb_walk_req_satp),
        .dtlb_walk_req_access_type(dtlb_walk_req_access_type),
        .dtlb_walk_resp_consumed(dtlb_walk_resp_consumed),
        .dtlb_walk_flush(dtlb_walk_flush),
        .dtlb_walk_req_ready(dtlb_walk_req_ready),
        .dtlb_walk_resp_valid(dtlb_walk_resp_valid),
        .dtlb_walk_resp_fault(dtlb_walk_resp_fault),
        .dtlb_walk_resp_vaddr(dtlb_walk_resp_vaddr),
        .dtlb_walk_resp_leaf_pte(dtlb_walk_resp_leaf_pte),
        .dtlb_walk_resp_leaf_level(dtlb_walk_resp_leaf_level)
    );

endmodule
