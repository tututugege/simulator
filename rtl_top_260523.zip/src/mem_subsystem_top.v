`timescale 1ns / 1ps
`include "axi_llc_params.vh"
`include "qm3_cpu_params.vh"

// Memory-subsystem shell.
//
// TODO:
// 1. Keep this wrapper as glue while replacing ptw_top, dcache_top, and
//    mem_router_top with real or generated RTL.
// 2. Add DCache/PTW table-template boundaries inside child modules rather than
//    widening this top-level mem-subsystem interface.
//
// This boundary is intended to own the shared PTW core, RealDcache,
// MemRouteBlock, and peripheral/MMIO routing. The frontend keeps ICache/ITLB
// internally and only sends ITLB miss/walk traffic here. The backend keeps LSU
// and DTLB internally, sends DTLB miss/walk traffic here, and sends DCache
// requests to the RealDcache owned by this subsystem.
module mem_subsystem_top #(
    parameter ADDR_BITS              = `AXI_LLC_ADDR_BITS,
    parameter DATA_BITS              = `QM3_DATA_BITS,
    parameter STRB_BITS              = `QM3_STRB_BITS,
    parameter CSR_BITS               = `QM3_CSR_BITS,
    parameter PRIVILEGE_BITS         = `QM3_PRIVILEGE_BITS,
    parameter LSU_LDU_COUNT          = `QM3_LSU_LDU_COUNT,
    parameter LSU_STA_COUNT          = `QM3_LSU_STA_COUNT,
    parameter LSU_LDU_WIDTH          = `QM3_LSU_LDU_WIDTH,
    parameter LSU_REQ_ID_BITS        = `QM3_LSU_REQ_ID_BITS,
    parameter REPLAY_BITS            = `QM3_REPLAY_BITS,
    parameter DCACHE_LINE_BYTES      = `QM3_DCACHE_LINE_BYTES,
    parameter DCACHE_SET_COUNT       = `QM3_DCACHE_SET_COUNT,
    parameter DCACHE_WAY_COUNT       = `QM3_DCACHE_WAY_COUNT,
    parameter DCACHE_MSHR_ENTRIES    = `QM3_DCACHE_MSHR_ENTRIES,
    parameter DCACHE_WB_ENTRIES      = `QM3_DCACHE_WB_ENTRIES,
    parameter PTW_ACCESS_TYPE_BITS   = `QM3_PTW_ACCESS_TYPE_BITS,
    parameter PTW_LEVEL_BITS         = `QM3_PTW_LEVEL_BITS,
    parameter PTE_BITS               = `QM3_PTE_BITS,
    parameter NUM_READ_MASTERS       = `QM3_NUM_READ_MASTERS,
    parameter NUM_WRITE_MASTERS      = `QM3_NUM_WRITE_MASTERS,
    parameter ID_BITS                = `AXI_LLC_ID_BITS,
    parameter MODE_BITS              = `AXI_LLC_MODE_BITS,
    parameter LINE_BITS              = `AXI_LLC_LINE_BITS,
    parameter LINE_BYTES             = `AXI_LLC_LINE_BYTES,
    parameter READ_RESP_BITS         = `AXI_LLC_READ_RESP_BITS
) (
    input                                   clk,
    input                                   rst_n,
    // LLC/cache mode from cpu_top. LLC_OFF is handled inside the AXI/LLC
    // subsystem; future DCache-local bypass should follow LLC mapped-window
    // address-mode policy, not LLC_OFF.
    input      [MODE_BITS-1:0]              mode,

    // ReadMasterReq/Resp from frontend_top ICache miss refill. This is routed
    // to axi_subsystem_top MASTER_ICACHE.
    input                                   icache_llc_read_req_valid,
    output                                  icache_llc_read_req_ready,
    output                                  icache_llc_read_req_accepted,
    output     [ID_BITS-1:0]                icache_llc_read_req_accepted_id,
    input      [ADDR_BITS-1:0]              icache_llc_read_req_addr,
    input      [7:0]                        icache_llc_read_req_total_size,
    input      [ID_BITS-1:0]                icache_llc_read_req_id,
    input                                   icache_llc_read_req_bypass,
    output                                  icache_llc_read_resp_valid,
    input                                   icache_llc_read_resp_ready,
    output     [READ_RESP_BITS-1:0]         icache_llc_read_resp_data,
    output     [ID_BITS-1:0]                icache_llc_read_resp_id,

    // ICacheMemPortReq from frontend_top. MemRouteBlock routes this
    // ICache -> DCache coherent word probe into the RealDcache load path.
    input                                   icache_dcache_req_valid,
    input      [ADDR_BITS-1:0]              icache_dcache_req_addr,

    // ICacheMemPortResp to frontend_top with the DCache probe result.
    output                                  dcache_icache_resp_valid,
    output                                  dcache_icache_resp_miss,
    output     [DATA_BITS-1:0]              dcache_icache_resp_data,

    // CsrStatusIO from backend_top for future peripheral/PTW context.
    input      [CSR_BITS-1:0]               csr_status_sstatus,
    input      [CSR_BITS-1:0]               csr_status_mstatus,
    input      [CSR_BITS-1:0]               csr_status_satp,
    input      [PRIVILEGE_BITS-1:0]         csr_status_privilege,

    // DTLB PtwMemPortCombIn from backend_top.
    input                                   dtlb_ptw_mem_req_valid,
    input      [ADDR_BITS-1:0]              dtlb_ptw_mem_req_addr,
    input                                   dtlb_ptw_mem_resp_consumed,

    // DTLB PtwMemPortCombOut to backend_top.
    output                                  dtlb_ptw_mem_req_ready,
    output                                  dtlb_ptw_mem_resp_valid,
    output     [DATA_BITS-1:0]              dtlb_ptw_mem_resp_data,

    // DTLB PtwWalkPortCombIn from backend_top.
    input                                   dtlb_walk_req_valid,
    input      [ADDR_BITS-1:0]              dtlb_walk_req_vaddr,
    input      [CSR_BITS-1:0]               dtlb_walk_req_satp,
    input      [PTW_ACCESS_TYPE_BITS-1:0]   dtlb_walk_req_access_type,
    input                                   dtlb_walk_resp_consumed,
    input                                   dtlb_walk_flush,

    // DTLB PtwWalkPortCombOut to backend_top.
    output                                  dtlb_walk_req_ready,
    output                                  dtlb_walk_resp_valid,
    output                                  dtlb_walk_resp_fault,
    output     [ADDR_BITS-1:0]              dtlb_walk_resp_vaddr,
    output     [PTE_BITS-1:0]               dtlb_walk_resp_leaf_pte,
    output     [PTW_LEVEL_BITS-1:0]         dtlb_walk_resp_leaf_level,

    // LsuDcacheIO.req_ports from backend_top to RealDcache in this subsystem.
    input      [LSU_LDU_COUNT-1:0]          lsu2dcache_load_ports_valid,
    input      [LSU_LDU_COUNT*ADDR_BITS-1:0] lsu2dcache_load_ports_addr,
    input      [LSU_LDU_COUNT*LSU_REQ_ID_BITS-1:0] lsu2dcache_load_ports_req_id,
    input      [LSU_STA_COUNT-1:0]          lsu2dcache_store_ports_valid,
    input      [LSU_STA_COUNT*ADDR_BITS-1:0] lsu2dcache_store_ports_addr,
    input      [LSU_STA_COUNT*DATA_BITS-1:0] lsu2dcache_store_ports_data,
    input      [LSU_STA_COUNT*STRB_BITS-1:0] lsu2dcache_store_ports_strb,
    input      [LSU_STA_COUNT*LSU_REQ_ID_BITS-1:0] lsu2dcache_store_ports_req_id,
    input      [LSU_LDU_WIDTH:0]            lsu2dcache_icache_req,

    // DcacheLsuIO.resp_ports from RealDcache in this subsystem to backend_top.
    output     [LSU_LDU_COUNT-1:0]          dcache2lsu_load_resps_valid,
    output     [LSU_LDU_COUNT*DATA_BITS-1:0] dcache2lsu_load_resps_data,
    output     [LSU_LDU_COUNT*LSU_REQ_ID_BITS-1:0] dcache2lsu_load_resps_req_id,
    output     [LSU_LDU_COUNT*REPLAY_BITS-1:0] dcache2lsu_load_resps_replay,
    output     [LSU_STA_COUNT-1:0]          dcache2lsu_store_resps_valid,
    output     [LSU_STA_COUNT*REPLAY_BITS-1:0] dcache2lsu_store_resps_replay,
    output     [LSU_STA_COUNT*LSU_REQ_ID_BITS-1:0] dcache2lsu_store_resps_req_id,
    output                                  dcache2lsu_mshr_fill,

    // PeripheralReqIO from backend_top to MMIO route in this subsystem.
    input                                   peripheral_req_is_mmio,
    input                                   peripheral_req_wen,
    input      [ADDR_BITS-1:0]              peripheral_req_mmio_addr,
    input      [DATA_BITS-1:0]              peripheral_req_mmio_wdata,
    input      [2:0]                        peripheral_req_mmio_fun3,

    // PeripheralRespIO from MMIO route in this subsystem to backend_top.
    output                                  peripheral_resp_is_mmio,
    output                                  peripheral_resp_ready,
    output     [DATA_BITS-1:0]              peripheral_resp_mmio_rdata,

    // ITLB PtwMemPortCombIn from frontend_top.
    input                                   itlb_ptw_mem_req_valid,
    input      [ADDR_BITS-1:0]              itlb_ptw_mem_req_addr,
    input                                   itlb_ptw_mem_resp_consumed,

    // ITLB PtwMemPortCombOut to frontend_top.
    output                                  itlb_ptw_mem_req_ready,
    output                                  itlb_ptw_mem_resp_valid,
    output     [DATA_BITS-1:0]              itlb_ptw_mem_resp_data,

    // ITLB PtwWalkPortCombIn from frontend_top.
    input                                   itlb_walk_req_valid,
    input      [ADDR_BITS-1:0]              itlb_walk_req_vaddr,
    input      [CSR_BITS-1:0]               itlb_walk_req_satp,
    input      [PTW_ACCESS_TYPE_BITS-1:0]   itlb_walk_req_access_type,
    input                                   itlb_walk_resp_consumed,
    input                                   itlb_walk_flush,

    // ITLB PtwWalkPortCombOut to frontend_top.
    output                                  itlb_walk_req_ready,
    output                                  itlb_walk_resp_valid,
    output                                  itlb_walk_resp_fault,
    output     [ADDR_BITS-1:0]              itlb_walk_resp_vaddr,
    output     [PTE_BITS-1:0]               itlb_walk_resp_leaf_pte,
    output     [PTW_LEVEL_BITS-1:0]         itlb_walk_resp_leaf_level,

    // axi-interconnect-kit ReadMasterReq_t.req to axi_subsystem_top.
    output     [NUM_READ_MASTERS-1:0]       read_req_valid,
    input      [NUM_READ_MASTERS-1:0]       read_req_ready,
    input      [NUM_READ_MASTERS-1:0]       read_req_accepted,
    input      [NUM_READ_MASTERS*ID_BITS-1:0] read_req_accepted_id,
    output     [NUM_READ_MASTERS*ADDR_BITS-1:0] read_req_addr,
    output     [NUM_READ_MASTERS*8-1:0]     read_req_total_size,
    output     [NUM_READ_MASTERS*ID_BITS-1:0] read_req_id,
    output     [NUM_READ_MASTERS-1:0]       read_req_bypass,

    // axi-interconnect-kit ReadMasterResp_t.resp from axi_subsystem_top.
    input      [NUM_READ_MASTERS-1:0]       read_resp_valid,
    output     [NUM_READ_MASTERS-1:0]       read_resp_ready,
    input      [NUM_READ_MASTERS*READ_RESP_BITS-1:0] read_resp_data,
    input      [NUM_READ_MASTERS*ID_BITS-1:0] read_resp_id,

    // axi-interconnect-kit WriteMasterReq_t.req to axi_subsystem_top.
    output     [NUM_WRITE_MASTERS-1:0]      write_req_valid,
    input      [NUM_WRITE_MASTERS-1:0]      write_req_ready,
    input      [NUM_WRITE_MASTERS-1:0]      write_req_accepted,
    output     [NUM_WRITE_MASTERS*ADDR_BITS-1:0] write_req_addr,
    output     [NUM_WRITE_MASTERS*LINE_BITS-1:0] write_req_wdata,
    output     [NUM_WRITE_MASTERS*LINE_BYTES-1:0] write_req_wstrb,
    output     [NUM_WRITE_MASTERS*8-1:0]    write_req_total_size,
    output     [NUM_WRITE_MASTERS*ID_BITS-1:0] write_req_id,
    output     [NUM_WRITE_MASTERS-1:0]      write_req_bypass,

    // axi-interconnect-kit WriteMasterResp_t.resp from axi_subsystem_top.
    input      [NUM_WRITE_MASTERS-1:0]      write_resp_valid,
    output     [NUM_WRITE_MASTERS-1:0]      write_resp_ready,
    input      [NUM_WRITE_MASTERS*ID_BITS-1:0] write_resp_id,
    input      [NUM_WRITE_MASTERS*2-1:0]    write_resp_code
);

    localparam integer AXI_MASTER_ICACHE       = `QM3_AXI_MASTER_ICACHE;
    localparam integer AXI_MASTER_DCACHE_R     = `QM3_AXI_MASTER_DCACHE_R;
    localparam integer AXI_MASTER_DCACHE_W     = `QM3_AXI_MASTER_DCACHE_W;
    localparam integer PTW_OWNER_BITS          = 3;

    genvar read_master_idx;
    genvar write_master_idx;

    // Future RealDcache/MSHR LLC read path. Kept as named wires so the ICache
    // and DCache LLC access paths use the same naming style before being packed
    // into the axi-interconnect-kit master bus.
    wire                                  dcache_llc_read_req_valid;
    wire                                  dcache_llc_read_req_ready;
    wire                                  dcache_llc_read_req_accepted;
    wire [ID_BITS-1:0]                    dcache_llc_read_req_accepted_id;
    wire [ADDR_BITS-1:0]                  dcache_llc_read_req_addr;
    wire [7:0]                            dcache_llc_read_req_total_size;
    wire [ID_BITS-1:0]                    dcache_llc_read_req_id;
    wire                                  dcache_llc_read_req_bypass;
    wire                                  dcache_llc_read_resp_valid;
    wire                                  dcache_llc_read_resp_ready;
    wire [READ_RESP_BITS-1:0]             dcache_llc_read_resp_data;
    wire [ID_BITS-1:0]                    dcache_llc_read_resp_id;

    // Future RealDcache/WB LLC write path.
    wire                                  dcache_llc_write_req_valid;
    wire                                  dcache_llc_write_req_ready;
    wire                                  dcache_llc_write_req_accepted;
    wire [ADDR_BITS-1:0]                  dcache_llc_write_req_addr;
    wire [LINE_BITS-1:0]                  dcache_llc_write_req_wdata;
    wire [LINE_BYTES-1:0]                 dcache_llc_write_req_wstrb;
    wire [7:0]                            dcache_llc_write_req_total_size;
    wire [ID_BITS-1:0]                    dcache_llc_write_req_id;
    wire                                  dcache_llc_write_req_bypass;
    wire                                  dcache_llc_write_resp_valid;
    wire                                  dcache_llc_write_resp_ready;
    wire [ID_BITS-1:0]                    dcache_llc_write_resp_id;
    wire [1:0]                            dcache_llc_write_resp_code;

    wire [LSU_LDU_COUNT-1:0]           router_dcache_load_ports_valid;
    wire [LSU_LDU_COUNT*ADDR_BITS-1:0] router_dcache_load_ports_addr;
    wire [LSU_LDU_COUNT*LSU_REQ_ID_BITS-1:0] router_dcache_load_ports_req_id;
    wire [LSU_STA_COUNT-1:0]           router_dcache_store_ports_valid;
    wire [LSU_STA_COUNT*ADDR_BITS-1:0] router_dcache_store_ports_addr;
    wire [LSU_STA_COUNT*DATA_BITS-1:0] router_dcache_store_ports_data;
    wire [LSU_STA_COUNT*STRB_BITS-1:0] router_dcache_store_ports_strb;
    wire [LSU_STA_COUNT*LSU_REQ_ID_BITS-1:0] router_dcache_store_ports_req_id;
    wire [LSU_LDU_WIDTH:0]             router_dcache_icache_req;
    wire [LSU_LDU_COUNT-1:0]           dcache_router_load_resps_valid;
    wire [LSU_LDU_COUNT*DATA_BITS-1:0] dcache_router_load_resps_data;
    wire [LSU_LDU_COUNT*LSU_REQ_ID_BITS-1:0] dcache_router_load_resps_req_id;
    wire [LSU_LDU_COUNT*REPLAY_BITS-1:0] dcache_router_load_resps_replay;
    wire [LSU_STA_COUNT-1:0]           dcache_router_store_resps_valid;
    wire [LSU_STA_COUNT*REPLAY_BITS-1:0] dcache_router_store_resps_replay;
    wire [LSU_STA_COUNT*LSU_REQ_ID_BITS-1:0] dcache_router_store_resps_req_id;
    wire                                dcache_router_mshr_fill;

    wire                                ptw_dtlb_req_valid;
    wire [ADDR_BITS-1:0]                ptw_dtlb_req_addr;
    wire                                ptw_itlb_req_valid;
    wire [ADDR_BITS-1:0]                ptw_itlb_req_addr;
    wire                                ptw_walk_req_valid;
    wire [ADDR_BITS-1:0]                ptw_walk_req_addr;
    wire                                ptw_grant_valid;
    wire [PTW_OWNER_BITS-1:0]           ptw_grant_owner;
    wire [LSU_REQ_ID_BITS-1:0]          ptw_grant_req_id;
    wire                                ptw_event_valid;
    wire [PTW_OWNER_BITS-1:0]           ptw_event_owner;
    wire [DATA_BITS-1:0]                ptw_event_data;
    wire [REPLAY_BITS-1:0]              ptw_event_replay;
    wire [ADDR_BITS-1:0]                ptw_event_req_addr;
    wire [LSU_REQ_ID_BITS-1:0]          ptw_event_req_id;
    wire                                ptw_wakeup_dtlb;
    wire                                ptw_wakeup_itlb;
    wire                                ptw_wakeup_walk;

    ptw_top #(
        .ADDR_BITS(ADDR_BITS),
        .DATA_BITS(DATA_BITS),
        .CSR_BITS(CSR_BITS),
        .PRIVILEGE_BITS(PRIVILEGE_BITS),
        .LSU_REQ_ID_BITS(LSU_REQ_ID_BITS),
        .REPLAY_BITS(REPLAY_BITS),
        .PTW_ACCESS_TYPE_BITS(PTW_ACCESS_TYPE_BITS),
        .PTW_LEVEL_BITS(PTW_LEVEL_BITS),
        .PTE_BITS(PTE_BITS),
        .PTW_OWNER_BITS(PTW_OWNER_BITS)
    ) u_ptw_top (
        .clk(clk),
        .rst_n(rst_n),
        .csr_status_sstatus(csr_status_sstatus),
        .csr_status_mstatus(csr_status_mstatus),
        .csr_status_satp(csr_status_satp),
        .csr_status_privilege(csr_status_privilege),
        .dtlb_ptw_mem_req_valid(dtlb_ptw_mem_req_valid),
        .dtlb_ptw_mem_req_addr(dtlb_ptw_mem_req_addr),
        .dtlb_ptw_mem_resp_consumed(dtlb_ptw_mem_resp_consumed),
        .dtlb_ptw_mem_req_ready(dtlb_ptw_mem_req_ready),
        .dtlb_ptw_mem_resp_valid(dtlb_ptw_mem_resp_valid),
        .dtlb_ptw_mem_resp_data(dtlb_ptw_mem_resp_data),
        .itlb_ptw_mem_req_valid(itlb_ptw_mem_req_valid),
        .itlb_ptw_mem_req_addr(itlb_ptw_mem_req_addr),
        .itlb_ptw_mem_resp_consumed(itlb_ptw_mem_resp_consumed),
        .itlb_ptw_mem_req_ready(itlb_ptw_mem_req_ready),
        .itlb_ptw_mem_resp_valid(itlb_ptw_mem_resp_valid),
        .itlb_ptw_mem_resp_data(itlb_ptw_mem_resp_data),
        .dtlb_walk_req_valid(dtlb_walk_req_valid),
        .dtlb_walk_req_vaddr(dtlb_walk_req_vaddr),
        .dtlb_walk_req_satp(dtlb_walk_req_satp),
        .dtlb_walk_req_access_type(dtlb_walk_req_access_type),
        .dtlb_walk_resp_consumed(dtlb_walk_resp_consumed),
        .dtlb_walk_flush(dtlb_walk_flush),
        .dtlb_walk_req_ready(dtlb_walk_req_ready),
        .dtlb_walk_resp_valid(dtlb_walk_resp_valid),
        .dtlb_walk_resp_fault(dtlb_walk_resp_fault),
        .dtlb_walk_resp_vaddr(dtlb_walk_resp_vaddr),
        .dtlb_walk_resp_leaf_pte(dtlb_walk_resp_leaf_pte),
        .dtlb_walk_resp_leaf_level(dtlb_walk_resp_leaf_level),
        .itlb_walk_req_valid(itlb_walk_req_valid),
        .itlb_walk_req_vaddr(itlb_walk_req_vaddr),
        .itlb_walk_req_satp(itlb_walk_req_satp),
        .itlb_walk_req_access_type(itlb_walk_req_access_type),
        .itlb_walk_resp_consumed(itlb_walk_resp_consumed),
        .itlb_walk_flush(itlb_walk_flush),
        .itlb_walk_req_ready(itlb_walk_req_ready),
        .itlb_walk_resp_valid(itlb_walk_resp_valid),
        .itlb_walk_resp_fault(itlb_walk_resp_fault),
        .itlb_walk_resp_vaddr(itlb_walk_resp_vaddr),
        .itlb_walk_resp_leaf_pte(itlb_walk_resp_leaf_pte),
        .itlb_walk_resp_leaf_level(itlb_walk_resp_leaf_level),
        .ptw_dtlb_req_valid(ptw_dtlb_req_valid),
        .ptw_dtlb_req_addr(ptw_dtlb_req_addr),
        .ptw_itlb_req_valid(ptw_itlb_req_valid),
        .ptw_itlb_req_addr(ptw_itlb_req_addr),
        .ptw_walk_req_valid(ptw_walk_req_valid),
        .ptw_walk_req_addr(ptw_walk_req_addr),
        .ptw_grant_valid(ptw_grant_valid),
        .ptw_grant_owner(ptw_grant_owner),
        .ptw_grant_req_id(ptw_grant_req_id),
        .ptw_event_valid(ptw_event_valid),
        .ptw_event_owner(ptw_event_owner),
        .ptw_event_data(ptw_event_data),
        .ptw_event_replay(ptw_event_replay),
        .ptw_event_req_addr(ptw_event_req_addr),
        .ptw_event_req_id(ptw_event_req_id),
        .ptw_wakeup_dtlb(ptw_wakeup_dtlb),
        .ptw_wakeup_itlb(ptw_wakeup_itlb),
        .ptw_wakeup_walk(ptw_wakeup_walk)
    );

    mem_router_top #(
        .ADDR_BITS(ADDR_BITS),
        .DATA_BITS(DATA_BITS),
        .STRB_BITS(STRB_BITS),
        .LSU_LDU_COUNT(LSU_LDU_COUNT),
        .LSU_STA_COUNT(LSU_STA_COUNT),
        .LSU_LDU_WIDTH(LSU_LDU_WIDTH),
        .LSU_REQ_ID_BITS(LSU_REQ_ID_BITS),
        .REPLAY_BITS(REPLAY_BITS),
        .PTW_OWNER_BITS(PTW_OWNER_BITS)
    ) u_mem_router_top (
        .clk(clk),
        .rst_n(rst_n),
        .dcache_router_load_resps_valid(dcache_router_load_resps_valid),
        .dcache_router_load_resps_data(dcache_router_load_resps_data),
        .dcache_router_load_resps_req_id(dcache_router_load_resps_req_id),
        .dcache_router_load_resps_replay(dcache_router_load_resps_replay),
        .dcache_router_store_resps_valid(dcache_router_store_resps_valid),
        .dcache_router_store_resps_replay(dcache_router_store_resps_replay),
        .dcache_router_store_resps_req_id(dcache_router_store_resps_req_id),
        .dcache_router_mshr_fill(dcache_router_mshr_fill),
        .lsu2dcache_load_ports_valid(lsu2dcache_load_ports_valid),
        .lsu2dcache_load_ports_addr(lsu2dcache_load_ports_addr),
        .lsu2dcache_load_ports_req_id(lsu2dcache_load_ports_req_id),
        .lsu2dcache_store_ports_valid(lsu2dcache_store_ports_valid),
        .lsu2dcache_store_ports_addr(lsu2dcache_store_ports_addr),
        .lsu2dcache_store_ports_data(lsu2dcache_store_ports_data),
        .lsu2dcache_store_ports_strb(lsu2dcache_store_ports_strb),
        .lsu2dcache_store_ports_req_id(lsu2dcache_store_ports_req_id),
        .lsu2dcache_icache_req(lsu2dcache_icache_req),
        .icache_dcache_req_valid(icache_dcache_req_valid),
        .icache_dcache_req_addr(icache_dcache_req_addr),
        .ptw_walk_req_valid(ptw_walk_req_valid),
        .ptw_walk_req_addr(ptw_walk_req_addr),
        .ptw_dtlb_req_valid(ptw_dtlb_req_valid),
        .ptw_dtlb_req_addr(ptw_dtlb_req_addr),
        .ptw_itlb_req_valid(ptw_itlb_req_valid),
        .ptw_itlb_req_addr(ptw_itlb_req_addr),
        .router_dcache_load_ports_valid(router_dcache_load_ports_valid),
        .router_dcache_load_ports_addr(router_dcache_load_ports_addr),
        .router_dcache_load_ports_req_id(router_dcache_load_ports_req_id),
        .router_dcache_store_ports_valid(router_dcache_store_ports_valid),
        .router_dcache_store_ports_addr(router_dcache_store_ports_addr),
        .router_dcache_store_ports_data(router_dcache_store_ports_data),
        .router_dcache_store_ports_strb(router_dcache_store_ports_strb),
        .router_dcache_store_ports_req_id(router_dcache_store_ports_req_id),
        .router_dcache_icache_req(router_dcache_icache_req),
        .dcache2lsu_load_resps_valid(dcache2lsu_load_resps_valid),
        .dcache2lsu_load_resps_data(dcache2lsu_load_resps_data),
        .dcache2lsu_load_resps_req_id(dcache2lsu_load_resps_req_id),
        .dcache2lsu_load_resps_replay(dcache2lsu_load_resps_replay),
        .dcache2lsu_store_resps_valid(dcache2lsu_store_resps_valid),
        .dcache2lsu_store_resps_replay(dcache2lsu_store_resps_replay),
        .dcache2lsu_store_resps_req_id(dcache2lsu_store_resps_req_id),
        .dcache2lsu_mshr_fill(dcache2lsu_mshr_fill),
        .dcache_icache_resp_valid(dcache_icache_resp_valid),
        .dcache_icache_resp_miss(dcache_icache_resp_miss),
        .dcache_icache_resp_data(dcache_icache_resp_data),
        .ptw_grant_valid(ptw_grant_valid),
        .ptw_grant_owner(ptw_grant_owner),
        .ptw_grant_req_id(ptw_grant_req_id),
        .ptw_event_valid(ptw_event_valid),
        .ptw_event_owner(ptw_event_owner),
        .ptw_event_data(ptw_event_data),
        .ptw_event_replay(ptw_event_replay),
        .ptw_event_req_addr(ptw_event_req_addr),
        .ptw_event_req_id(ptw_event_req_id),
        .ptw_wakeup_dtlb(ptw_wakeup_dtlb),
        .ptw_wakeup_itlb(ptw_wakeup_itlb),
        .ptw_wakeup_walk(ptw_wakeup_walk),
        .peripheral_req_is_mmio(peripheral_req_is_mmio),
        .peripheral_req_wen(peripheral_req_wen),
        .peripheral_req_mmio_addr(peripheral_req_mmio_addr),
        .peripheral_req_mmio_wdata(peripheral_req_mmio_wdata),
        .peripheral_req_mmio_fun3(peripheral_req_mmio_fun3),
        .peripheral_resp_is_mmio(peripheral_resp_is_mmio),
        .peripheral_resp_ready(peripheral_resp_ready),
        .peripheral_resp_mmio_rdata(peripheral_resp_mmio_rdata)
    );

    dcache_top #(
        .ADDR_BITS(ADDR_BITS),
        .DATA_BITS(DATA_BITS),
        .STRB_BITS(STRB_BITS),
        .LSU_LDU_COUNT(LSU_LDU_COUNT),
        .LSU_STA_COUNT(LSU_STA_COUNT),
        .LSU_LDU_WIDTH(LSU_LDU_WIDTH),
        .LSU_REQ_ID_BITS(LSU_REQ_ID_BITS),
        .REPLAY_BITS(REPLAY_BITS),
        .DCACHE_LINE_BYTES(DCACHE_LINE_BYTES),
        .DCACHE_SET_COUNT(DCACHE_SET_COUNT),
        .DCACHE_WAY_COUNT(DCACHE_WAY_COUNT),
        .DCACHE_MSHR_ENTRIES(DCACHE_MSHR_ENTRIES),
        .DCACHE_WB_ENTRIES(DCACHE_WB_ENTRIES),
        .ID_BITS(ID_BITS),
        .MODE_BITS(MODE_BITS),
        .LINE_BITS(LINE_BITS),
        .LINE_BYTES(LINE_BYTES),
        .READ_RESP_BITS(READ_RESP_BITS)
    ) u_dcache_top (
        .clk(clk),
        .rst_n(rst_n),
        .mode(mode),
        .router_dcache_load_ports_valid(router_dcache_load_ports_valid),
        .router_dcache_load_ports_addr(router_dcache_load_ports_addr),
        .router_dcache_load_ports_req_id(router_dcache_load_ports_req_id),
        .router_dcache_store_ports_valid(router_dcache_store_ports_valid),
        .router_dcache_store_ports_addr(router_dcache_store_ports_addr),
        .router_dcache_store_ports_data(router_dcache_store_ports_data),
        .router_dcache_store_ports_strb(router_dcache_store_ports_strb),
        .router_dcache_store_ports_req_id(router_dcache_store_ports_req_id),
        .router_dcache_icache_req(router_dcache_icache_req),
        .dcache_router_load_resps_valid(dcache_router_load_resps_valid),
        .dcache_router_load_resps_data(dcache_router_load_resps_data),
        .dcache_router_load_resps_req_id(dcache_router_load_resps_req_id),
        .dcache_router_load_resps_replay(dcache_router_load_resps_replay),
        .dcache_router_store_resps_valid(dcache_router_store_resps_valid),
        .dcache_router_store_resps_replay(dcache_router_store_resps_replay),
        .dcache_router_store_resps_req_id(dcache_router_store_resps_req_id),
        .dcache_router_mshr_fill(dcache_router_mshr_fill),
        .dcache_llc_read_req_valid(dcache_llc_read_req_valid),
        .dcache_llc_read_req_ready(dcache_llc_read_req_ready),
        .dcache_llc_read_req_accepted(dcache_llc_read_req_accepted),
        .dcache_llc_read_req_accepted_id(dcache_llc_read_req_accepted_id),
        .dcache_llc_read_req_addr(dcache_llc_read_req_addr),
        .dcache_llc_read_req_total_size(dcache_llc_read_req_total_size),
        .dcache_llc_read_req_id(dcache_llc_read_req_id),
        .dcache_llc_read_req_bypass(dcache_llc_read_req_bypass),
        .dcache_llc_read_resp_valid(dcache_llc_read_resp_valid),
        .dcache_llc_read_resp_ready(dcache_llc_read_resp_ready),
        .dcache_llc_read_resp_data(dcache_llc_read_resp_data),
        .dcache_llc_read_resp_id(dcache_llc_read_resp_id),
        .dcache_llc_write_req_valid(dcache_llc_write_req_valid),
        .dcache_llc_write_req_ready(dcache_llc_write_req_ready),
        .dcache_llc_write_req_accepted(dcache_llc_write_req_accepted),
        .dcache_llc_write_req_addr(dcache_llc_write_req_addr),
        .dcache_llc_write_req_wdata(dcache_llc_write_req_wdata),
        .dcache_llc_write_req_wstrb(dcache_llc_write_req_wstrb),
        .dcache_llc_write_req_total_size(dcache_llc_write_req_total_size),
        .dcache_llc_write_req_id(dcache_llc_write_req_id),
        .dcache_llc_write_req_bypass(dcache_llc_write_req_bypass),
        .dcache_llc_write_resp_valid(dcache_llc_write_resp_valid),
        .dcache_llc_write_resp_ready(dcache_llc_write_resp_ready),
        .dcache_llc_write_resp_id(dcache_llc_write_resp_id),
        .dcache_llc_write_resp_code(dcache_llc_write_resp_code)
    );

    assign icache_llc_read_req_ready       = read_req_ready[AXI_MASTER_ICACHE];
    assign icache_llc_read_req_accepted    = read_req_accepted[AXI_MASTER_ICACHE];
    assign icache_llc_read_req_accepted_id =
        read_req_accepted_id[AXI_MASTER_ICACHE*ID_BITS +: ID_BITS];
    assign icache_llc_read_resp_valid      = read_resp_valid[AXI_MASTER_ICACHE];
    assign icache_llc_read_resp_data       =
        read_resp_data[AXI_MASTER_ICACHE*READ_RESP_BITS +: READ_RESP_BITS];
    assign icache_llc_read_resp_id         =
        read_resp_id[AXI_MASTER_ICACHE*ID_BITS +: ID_BITS];

    assign dcache_llc_read_req_ready       = read_req_ready[AXI_MASTER_DCACHE_R];
    assign dcache_llc_read_req_accepted    = read_req_accepted[AXI_MASTER_DCACHE_R];
    assign dcache_llc_read_req_accepted_id =
        read_req_accepted_id[AXI_MASTER_DCACHE_R*ID_BITS +: ID_BITS];
    assign dcache_llc_read_resp_valid      = read_resp_valid[AXI_MASTER_DCACHE_R];
    assign dcache_llc_read_resp_data       =
        read_resp_data[AXI_MASTER_DCACHE_R*READ_RESP_BITS +: READ_RESP_BITS];
    assign dcache_llc_read_resp_id         =
        read_resp_id[AXI_MASTER_DCACHE_R*ID_BITS +: ID_BITS];

    assign dcache_llc_write_req_ready      = write_req_ready[AXI_MASTER_DCACHE_W];
    assign dcache_llc_write_req_accepted   = write_req_accepted[AXI_MASTER_DCACHE_W];
    assign dcache_llc_write_resp_valid     = write_resp_valid[AXI_MASTER_DCACHE_W];
    assign dcache_llc_write_resp_id        =
        write_resp_id[AXI_MASTER_DCACHE_W*ID_BITS +: ID_BITS];
    assign dcache_llc_write_resp_code      =
        write_resp_code[AXI_MASTER_DCACHE_W*2 +: 2];

    generate
        for (read_master_idx = 0; read_master_idx < NUM_READ_MASTERS; read_master_idx = read_master_idx + 1) begin : gen_llc_read_master
            if (read_master_idx == AXI_MASTER_ICACHE) begin : gen_icache_llc_read
                assign read_req_valid[read_master_idx] = icache_llc_read_req_valid;
                assign read_req_addr[read_master_idx*ADDR_BITS +: ADDR_BITS] = icache_llc_read_req_addr;
                assign read_req_total_size[read_master_idx*8 +: 8] = icache_llc_read_req_total_size;
                assign read_req_id[read_master_idx*ID_BITS +: ID_BITS] = icache_llc_read_req_id;
                assign read_req_bypass[read_master_idx] = icache_llc_read_req_bypass;
                assign read_resp_ready[read_master_idx] = icache_llc_read_resp_ready;
            end else if (read_master_idx == AXI_MASTER_DCACHE_R) begin : gen_dcache_llc_read
                assign read_req_valid[read_master_idx] = dcache_llc_read_req_valid;
                assign read_req_addr[read_master_idx*ADDR_BITS +: ADDR_BITS] = dcache_llc_read_req_addr;
                assign read_req_total_size[read_master_idx*8 +: 8] = dcache_llc_read_req_total_size;
                assign read_req_id[read_master_idx*ID_BITS +: ID_BITS] = dcache_llc_read_req_id;
                assign read_req_bypass[read_master_idx] = dcache_llc_read_req_bypass;
                assign read_resp_ready[read_master_idx] = dcache_llc_read_resp_ready;
            end else begin : gen_unused_llc_read
                assign read_req_valid[read_master_idx] = 1'b0;
                assign read_req_addr[read_master_idx*ADDR_BITS +: ADDR_BITS] = {ADDR_BITS{1'b0}};
                assign read_req_total_size[read_master_idx*8 +: 8] = 8'b0;
                assign read_req_id[read_master_idx*ID_BITS +: ID_BITS] = {ID_BITS{1'b0}};
                assign read_req_bypass[read_master_idx] = 1'b0;
                assign read_resp_ready[read_master_idx] = 1'b0;
            end
        end
    endgenerate

    generate
        for (write_master_idx = 0; write_master_idx < NUM_WRITE_MASTERS; write_master_idx = write_master_idx + 1) begin : gen_llc_write_master
            if (write_master_idx == AXI_MASTER_DCACHE_W) begin : gen_dcache_llc_write
                assign write_req_valid[write_master_idx] = dcache_llc_write_req_valid;
                assign write_req_addr[write_master_idx*ADDR_BITS +: ADDR_BITS] = dcache_llc_write_req_addr;
                assign write_req_wdata[write_master_idx*LINE_BITS +: LINE_BITS] = dcache_llc_write_req_wdata;
                assign write_req_wstrb[write_master_idx*LINE_BYTES +: LINE_BYTES] = dcache_llc_write_req_wstrb;
                assign write_req_total_size[write_master_idx*8 +: 8] = dcache_llc_write_req_total_size;
                assign write_req_id[write_master_idx*ID_BITS +: ID_BITS] = dcache_llc_write_req_id;
                assign write_req_bypass[write_master_idx] = dcache_llc_write_req_bypass;
                assign write_resp_ready[write_master_idx] = dcache_llc_write_resp_ready;
            end else begin : gen_unused_llc_write
                assign write_req_valid[write_master_idx] = 1'b0;
                assign write_req_addr[write_master_idx*ADDR_BITS +: ADDR_BITS] = {ADDR_BITS{1'b0}};
                assign write_req_wdata[write_master_idx*LINE_BITS +: LINE_BITS] = {LINE_BITS{1'b0}};
                assign write_req_wstrb[write_master_idx*LINE_BYTES +: LINE_BYTES] = {LINE_BYTES{1'b0}};
                assign write_req_total_size[write_master_idx*8 +: 8] = 8'b0;
                assign write_req_id[write_master_idx*ID_BITS +: ID_BITS] = {ID_BITS{1'b0}};
                assign write_req_bypass[write_master_idx] = 1'b0;
                assign write_resp_ready[write_master_idx] = 1'b0;
            end
        end
    endgenerate

endmodule
