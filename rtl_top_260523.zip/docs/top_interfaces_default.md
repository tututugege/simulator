# 3e13836 default 配置下的顶层接口说明

本文档描述 3e13836 default 下当前 RTL 空壳的 top 边界。所有模块目前
仍是 interface-only shell；尚未接入真实子模块的输出均在 RTL 中显式 tie-off
为空闲值。逐信号 bit 精确统计和每个信号的功能说明见
`docs/interface_bitwidth_default.md`。

## 3e13836 default 参数快照

基础宽度：`PC_BITS=32`、`INST_BITS=32`、`DATA_BITS=32`、`STRB_BITS=8`、
`ADDR_BITS=32`、`CSR_BITS=32`、`PRIVILEGE_BITS=2`。

前后端规模：`FETCH_WIDTH=16`、`DECODE_WIDTH=8`、`COMMIT_WIDTH=8`、
`TN_MAX=4`、`ISSUE_WIDTH=24`、`ROB_NUM=512`、`IDU_INST_BUFFER_SIZE=1024`、
`FTQ_SIZE=512`、`LDQ_SIZE=512`、`STQ_SIZE=512`。

分支预测元数据：`PCPN_BITS=3`、`BR_TYPE_BITS=3`、`TAGE_IDX_BITS=12`、
`TAGE_TAG_BITS=8`、`BPU_SCL_META_NTABLE=8`、`BPU_SCL_META_IDX_BITS=16`、
`BPU_SCL_META_SUM_BITS=16`、`BPU_LOOP_META_IDX_BITS=16`、
`BPU_LOOP_META_TAG_BITS=16`。

访存子系统规模：`LSU_LDU_COUNT=4`、`LSU_STA_COUNT=4`、
`LSU_SDU_COUNT=4`、`LSU_LDU_WIDTH=2`、`LSU_REQ_ID_BITS=32`、
`REPLAY_BITS=2`、`ITLB_ENTRIES=64`、`DTLB_ENTRIES=64`。ICache 为
`64B x 64 sets x 8 ways`，DCache 为
`64B x 256 sets x 4 ways`，DCache `MSHR=8`、`WB=8`。

AXI/LLC 规模：`NUM_READ_MASTERS=4`、`NUM_WRITE_MASTERS=2`、`ID_BITS=4`、
`LINE_BYTES=64`、`LINE_BITS=512`、`READ_RESP_BITS=2048`。default LLC 为
`4 MiB / 4096 sets / 16 ways`；`FPGA_KB_LLC=1` 时仅 LLC 变为
`64 KiB / 256 sets / 4 ways`。DDR AXI 为 `ID=6`、`DATA=256`、
`STRB=32`；MMIO AXI 为 `ID=6`、`DATA=32`、`STRB=4`。默认分频比例
`AXI_SUBSYSTEM_FREQ_DIV=16`，即 `aclk:cpu_clk = 16:1`。

## 时钟域约定

`cpu_top.aclk` 是 AXI/LLC/DDR 高频时钟，驱动 `axi_subsystem_top.clk` 和外部
AXI 相关逻辑。`cpu_top.cpu_clk` 是 CPU core 低频时钟，驱动
`frontend_top.aclk`、`backend_top.aclk` 和 `mem_subsystem_top.clk`。
`axi_subsystem_top` 同时接收 `cpu_clk`，用于后续真实 AXI/LLC wrapper 在
mem subsystem 交界处按低频边界保持和采样 valid/ready 握手。

建议 SoC/FPGA 顶层从同一个外部时钟源经 PLL/MMCM/clock wizard 生成
`aclk` 和 `cpu_clk` 后一起输入 `cpu_top`。不建议在 `cpu_top` 内部用普通 RTL
计数器分频生成 `cpu_clk`，否则会引入普通逻辑时钟、clock tree 和时序约束问题。

## 当前空壳层次

本轮拆分后，四个大 top 的功能性对接端口保持稳定；新增子模块只用于明确下一步
可替换为手写 RTL、模板生成 RTL 或机器学习生成 RTL 的边界。

| 大 top | 子模块空壳 | 说明 |
| --- | --- | --- |
| `frontend_top` | `frontend_core_top`、`icache_top`、`itlb_top` | ICache 和 ITLB 已分离，`icache_top` 通过单口 lookup 与 `itlb_top` 对接。 |
| `backend_top` | `backend_core_top`、`lsu_top`、`dtlb_top` | DTLB 通过参数化 LSU load/store 查询端口与 `lsu_top` 对接。 |
| `mem_subsystem_top` | `ptw_top`、`dcache_top`、`mem_router_top` | PTW、RealDcache、MemRouteBlock 边界已经拆开。 |
| `axi_subsystem_top` | 暂无更深层拆分 | 仍是后续 `axi_llc_subsystem_dual` 的薄 wrapper 空壳。 |

新子模块的功能性端口按对应 C++ struct 的 Input/Output 顺序排列；例如
`icache_top` 按 `icache_in`/`icache_out`，`dtlb_top`/`lsu_top` 按
`LsuMMUIO`/`MMULsuIO`，`mem_router_top` 按 `MemRouteIn`/`MemRouteOut`。
perf/debug 字段不纳入训练边界端口。3e13836 中 `LoadReq`/`StoreReq` 在
`!BSD_CONFIG` 下还有 `replay` 字段；当前 C++ 只把它用于 perf 归因
(`slot.perf_replay`)，不参与 RealDcache 功能结果，因此 RTL 空壳仍不把它作为
训练/对接边界端口。

### 64B cacheline 下的已知位宽浪费

当前接口保持 simulator/axi-interconnect-kit 的既有载体形状，可以继续作为 RTL
顶层接口推进；浪费主要来自“按最大事务宽度/多 master slot 展平”的保守设计，
不是当前 64B cacheline 路径会实际用满这些位。

simulator 侧这些数据不是单个巨大标量，而是数组载体：read response 是每个
read master 一组 `WideReadData_t.words[64]`，即 64 个 32-bit word，共
256B/2048 bits；RTL 顶层把 4 个 read master 展平成
`read_resp_data[8191:0]`。当前 ICache/DCache cacheline refill 请求最大为
64B，只读取其中低 16 个 32-bit word，高 48 个 word 不承载有效 cacheline
数据。因此：

| 信号 | 当前 default 宽度 | 64B cacheline 实际有效宽度 | 可后续优化的浪费 |
| --- | ---: | ---: | ---: |
| `icache_llc_read_resp_data` | 2048 bits | 512 bits | 1536 bits |
| `read_resp_data` 单个 read master slot | 2048 bits | 512 bits | 1536 bits |
| `read_resp_data` 全部 4 个 read master slot | 8192 bits | 2048 bits | 6144 bits |

`write_req_wdata` 看起来是 1024 bits，但它是 2 个 write master slot 展平后的
总线；单个 write master slot 为 512 bits，正好等于当前 64B cacheline。所
以这里没有“单次 cacheline 写请求超过 cacheline”的问题，主要浪费是总线上同
时保留了两个独立写 master 的 payload slot：

| 信号 | 当前 default 宽度 | 单个 64B cacheline 写 payload | 说明 |
| --- | ---: | ---: | --- |
| `write_req_wdata` 单个 write master slot | 512 bits | 512 bits | 已经和 cacheline 对齐。 |
| `write_req_wdata` 全部 2 个 write master slot | 1024 bits | 512 bits/slot | 展平多个 master slot 带来的总线宽度。 |

保持现状时，simulator/RTL 接口语义是“低位 word 按请求大小有效，高位 word
空闲/未使用”。这不是当前 64B cacheline 路径上的有效数据截断。后续如果要
裁剪位宽，优先目标是把 `READ_RESP_BYTES/READ_RESP_BITS` 从 256B/2048 bits
收敛到 `LINE_BYTES/LINE_BITS` 的 64B/512 bits，并同步修改
`axi_llc_subsystem_dual` 及其 wrapper 参数，同时约束所有 read 请求的
`total_size <= LINE_BYTES - 1`。

## `cpu_top`

外部控制信号：

| 信号 | 方向 | default 宽度 | 作用 |
| --- | --- | ---: | --- |
| `ext_int` | in | 6 | 外部中断输入，后续接入 backend/CSR。 |
| `aclk` | in | 1 | 高频 AXI/LLC/DDR 时钟。 |
| `cpu_clk` | in | 1 | 低频 CPU core 时钟，驱动 frontend/backend/mem subsystem。 |
| `aresetn` | in | 1 | 低有效复位。 |
| `mode` | in | 2 | AXI/LLC 模式控制：`2'b01` 为 LLC_ON，`2'b10` 为 mapped-window，`2'b00/2'b11` 为 LLC_OFF。LLC_OFF 只在 AXI/LLC 子系统内绕过 LLC，不表示绕过 ICache/DCache；I/D cache 本地 bypass 后续应由 mapped-window 地址模式决定。 |
| `global_reset` | out | 1 | 由 `~aresetn` 生成的高有效复位。 |

DDR AXI4 master 端口，连接 DDR/SDRAM memory-controller 路径：

| 通道 | 信号 | default 宽度 | 作用 |
| --- | --- | --- | --- |
| AW | `ddr_axi_awvalid/ready/id/addr/len/size/burst/lock/cache/prot` | `id=6`、`addr=32`、`len=8`、`size=3`、`burst=2`、`lock=1`、`cache=4`、`prot=3` | DDR 写地址通道。`lock/cache/prot` 在 `cpu_top` 中固定为默认值。 |
| W | `ddr_axi_wvalid/ready/data/strb/last` | `data=256`、`strb=32` | DDR 写数据通道。AXI4 无 WID。 |
| B | `ddr_axi_bvalid/ready/id/resp` | `id=6`、`resp=2` | DDR 写响应通道。 |
| AR | `ddr_axi_arvalid/ready/id/addr/len/size/burst/lock/cache/prot` | `id=6`、`addr=32`、`len=8`、`size=3`、`burst=2`、`lock=1`、`cache=4`、`prot=3` | DDR 读地址通道。 |
| R | `ddr_axi_rvalid/ready/id/data/resp/last` | `id=6`、`data=256`、`resp=2` | DDR 读数据通道。 |

MMIO AXI4 master 端口，连接外设/MMIO 路径：

| 通道 | 信号 | default 宽度 | 作用 |
| --- | --- | --- | --- |
| AW | `mmio_axi_awvalid/ready/id/addr/len/size/burst/lock/cache/prot` | `id=6`、`addr=32`、`len=8`、`size=3`、`burst=2`、`lock=1`、`cache=4`、`prot=3` | MMIO 写地址通道。MMIO burst 在 AXI wrapper 中固定为 fixed-address burst。 |
| W | `mmio_axi_wvalid/ready/data/strb/last` | `data=32`、`strb=4` | MMIO 写数据通道。 |
| B | `mmio_axi_bvalid/ready/id/resp` | `id=6`、`resp=2` | MMIO 写响应通道。 |
| AR | `mmio_axi_arvalid/ready/id/addr/len/size/burst/lock/cache/prot` | `id=6`、`addr=32`、`len=8`、`size=3`、`burst=2`、`lock=1`、`cache=4`、`prot=3` | MMIO 读地址通道。 |
| R | `mmio_axi_rvalid/ready/id/data/resp/last` | `id=6`、`data=32`、`resp=2` | MMIO 读数据通道。 |

## `frontend_top`

时钟与控制输入：

| 信号组 | 方向 | default 宽度 | 作用 |
| --- | --- | --- | --- |
| `aclk`、`aresetn`、`reset` | in | 各 1 | frontend 低频时钟与复位；`aclk` 当前由 `cpu_top.cpu_clk` 驱动。 |
| `refetch`、`itlb_flush`、`fence_i`、`refetch_address` | in | `addr=32` | backend 发来的重定向与 frontend flush 控制。 |
| `csr_status_sstatus/mstatus/satp/privilege` | in | `32/32/32/2` | ITLB/MMU 需要的 CSR 上下文。 |
| `FIFO_read_enable` | in | 1 | backend 消费或重定向时对 frontend FIFO 的读取控制。 |

backend 到 frontend 的训练输入：

| 信号组 | 方向 | default 宽度 | 作用 |
| --- | --- | --- | --- |
| `back2front_valid` 与分支方向/目标字段 | in | `valid=8`、`pc vectors=256`、`br_type=24` | commit 阶段的 BPU 训练元数据。 |
| `alt_pred`、`altpcpn`、`pcpn` | in | `8`、`24`、`24` | 分支预测 provider 元数据。 |
| `tage_idx`、`tage_tag` | in | `384`、`256` | `COMMIT_WIDTH * TN_MAX` 的 TAGE 元数据。 |
| `sc_used`、`sc_pred`、`sc_sum`、`sc_idx` | in | `8`、`8`、`128`、`1024` | statistical corrector 元数据。 |
| `loop_used/hit/pred`、`loop_idx`、`loop_tag` | in | `8`、`128`、`128` | loop predictor 元数据。 |

frontend 到 backend 的取指输出：

| 信号组 | 方向 | default 宽度 | 作用 |
| --- | --- | --- | --- |
| `FIFO_valid`、`commit_stall` | out | 各 1 | frontend 队列状态与 stall 状态。 |
| `pc`、`instructions`、`inst_valid` | out | `512`、`512`、`16` | 发往 backend 的 fetch packet。 |
| `out_predict_dir`、`predict_next_fetch_address` | out | `16`、`32` | fetch packet 对应的预测结果。 |
| `out_alt_pred`、`out_altpcpn`、`out_pcpn` | out | `16`、`48`、`48` | 随 fetch packet 传递的 provider 元数据。 |
| `page_fault_inst` | out | 16 | 每条取指对应的 page fault 标记。 |
| `out_tage_idx`、`out_tage_tag` | out | `768`、`512` | `FETCH_WIDTH * TN_MAX` 的 TAGE 元数据。 |
| `out_sc_used/pred/sum/idx` | out | `16`、`16`、`256`、`2048` | statistical corrector 元数据。 |
| `out_loop_used/hit/pred/idx/tag` | out | `16`、`16`、`16`、`256`、`256` | loop predictor 元数据。 |

frontend 侧全局控制与访存接口：

| 信号组 | 方向 | default 宽度 | 作用 |
| --- | --- | --- | --- |
| `mode` | in | 2 | 来自 `cpu_top` 的 AXI/LLC 模式上下文；当前空壳不据此改写 ICache refill bypass，后续 ICache 本地 bypass 由 mapped-window 地址模式决定。 |
| `icache_llc_read_req_*` | out/in | `addr=32`、`id=4`、`total_size=8` | ICache miss refill 请求，经 `mem_subsystem_top` 路由到 LLC read master `MASTER_ICACHE`。 |
| `icache_llc_read_resp_*` | in/out | `data=2048`、`id=4` | LLC refill 响应返回 ICache。 |
| `icache_dcache_req_valid/addr` | out | `1/32` | ICache miss 时发出的 DCache coherent word probe。 |
| `dcache_icache_resp_valid/miss/data` | in | `1/1/32` | DCache probe 结果返回 ICache。 |
| `itlb_ptw_mem_*` | out/in | `addr=32`、`data=32` | ITLB 的 PTW memory read 请求/响应通道。 |
| `itlb_walk_*` | out/in | `vaddr=32`、`satp=32`、`pte=32`、`level=8` | ITLB page walk 请求/响应通道。 |

## `backend_top`

frontend packet 输入与消费反馈：

| 信号组 | 方向 | default 宽度 | 作用 |
| --- | --- | --- | --- |
| `front2pre_inst`、`front2pre_pc`、`front2pre_valid` | in | `512`、`512`、`16` | frontend 发来的 fetch packet。 |
| `front2pre_*prediction metadata` | in | 与 frontend fetch 输出一致 | 随每条取指携带的预测元数据。 |
| `pre2front_fire`、`pre2front_ready` | out | `16`、`1` | backend 对 frontend FIFO 的消费反馈。 |

backend 控制与 commit 输出：

| 信号组 | 方向 | default 宽度 | 作用 |
| --- | --- | --- | --- |
| `mispred`、`stall`、`flush`、`fence_i`、`itlb_flush`、`redirect_pc` | out | `pc=32` | 重定向、flush 与 frontend 控制。 |
| `back2front_*` branch-training 输出 | out | 与 frontend 训练输入一致 | commit 阶段的 BPU 更新元数据。 |
| `csr_status_sstatus/mstatus/satp/privilege` | out | `32/32/32/2` | 当前 CSR 上下文，供 frontend 和 mem subsystem 使用。 |

backend 访存接口：

| 信号组 | 方向 | default 宽度 | 作用 |
| --- | --- | --- | --- |
| `peripheral_req_*` | out | `addr=32`、`wdata=32`、`fun3=3` | LSU 发起的 MMIO/peripheral 请求。 |
| `peripheral_resp_*` | in | `rdata=32` | MMIO/peripheral 响应返回 backend。 |
| `dtlb_ptw_mem_*` | out/in | `addr=32`、`data=32` | DTLB 的 PTW memory read 请求/响应通道。 |
| `dtlb_walk_*` | out/in | `vaddr=32`、`satp=32`、`pte=32`、`level=8` | DTLB page walk 请求/响应通道。 |
| `lsu2dcache_load_ports_*` | out | `valid=4`、`addr=128`、`req_id=128` | LSU load 请求，发往 `mem_subsystem_top` 内的 RealDcache。 |
| `lsu2dcache_store_ports_*` | out | `valid=4`、`addr=128`、`data=128`、`strb=32`、`req_id=128` | LSU store 请求，发往 RealDcache。 |
| `lsu2dcache_icache_req` | out | 3 | 标记当前被 ICache probe 借用的 DCache load port；空闲值为 `LSU_LDU_COUNT`。 |
| `dcache2lsu_load_resps_*` | in | `valid=4`、`data=128`、`req_id=128`、`replay=8` | DCache load 响应返回 LSU。 |
| `dcache2lsu_store_resps_*` | in | `valid=4`、`replay=8`、`req_id=128` | DCache store 响应返回 LSU。 |
| `dcache2lsu_mshr_fill` | in | 1 | DCache MSHR fill 事件。 |

## `mem_subsystem_top`

该边界后续负责容纳 MemRouteBlock、共享 PTW core、RealDcache、MSHR、write
buffer 和 peripheral route。

| 信号组 | 方向 | default 宽度 | 作用 |
| --- | --- | --- | --- |
| `mode` | in | 2 | 来自 `cpu_top` 的 AXI/LLC 模式上下文；LLC_OFF 不在这里强制改写 ICache/DCache 请求，后续 DCache 本地 bypass 由 mapped-window 地址模式决定。 |
| `icache_llc_read_req/resp_*` | in/out | `addr=32`、`id=4`、`resp_data=2048` | ICache miss refill 路径，打包到 AXI read master slot `MASTER_ICACHE`。 |
| `icache_dcache_req_*`、`dcache_icache_resp_*` | in/out | `addr=32`、`data=32` | ICache coherent word probe，经 MemRouteBlock 注入 DCache load port。 |
| `csr_status_*` | in | `32/32/32/2` | 后续 PTW/peripheral 逻辑需要的 CSR 上下文。 |
| `dtlb_ptw_mem_*`、`dtlb_walk_*` | in/out | `addr=32`、`pte=32`、`level=8` | backend DTLB 的 PTW 接口。 |
| `itlb_ptw_mem_*`、`itlb_walk_*` | in/out | `addr=32`、`pte=32`、`level=8` | frontend ITLB 的 PTW 接口。 |
| `lsu2dcache_*` | in | default 配置下的 LSU 宽度 | LSU 请求进入 RealDcache。 |
| `dcache2lsu_*` | out | DCache 到 backend 的响应宽度 | RealDcache 响应和 replay 结果。 |
| `peripheral_req/resp_*` | in/out | `addr=32`、`data=32` | backend MMIO 请求和响应路径。 |
| `read_req/read_resp_*` | out/in | `masters=4`、`addr=128`、`id=16`、`resp_data=8192` | 打包后的 axi-interconnect-kit read master 请求/响应总线。 |
| `write_req/write_resp_*` | out/in | `masters=2`、`addr=64`、`wdata=1024`、`wstrb=128`、`id=8` | 打包后的 axi-interconnect-kit write master 请求/响应总线。 |

当前空壳把 `icache_llc_read_*` 打包到 read master 0，并为后续 DCache LLC
read/write 路径预留了 read master 1 和 write master 0 的内部命名线束。

## `axi_subsystem_top`

该模块是后续 `axi_llc_subsystem_dual` 的一层薄 wrapper。LLC `mode` 由
`cpu_top` 输入并向后续 AXI/LLC 双口 top 传递；mapped offset 和 invalidate
控制目前保持在模块内部 tie-off，等待后续维护控制器接入。

全局控制和 CPU 侧 master 总线：

| 信号组 | 方向 | default 宽度 | 作用 |
| --- | --- | --- | --- |
| `clk/cpu_clk/rst_n` | in | 各 1 | `clk` 为 AXI/LLC 高频时钟，`cpu_clk` 为 CPU 侧低频握手时钟，`rst_n` 为低有效复位。 |
| `mode` | in | 2 | AXI/LLC 模式请求：`2'b01` LLC_ON，`2'b10` mapped-window，`2'b00/2'b11` LLC_OFF/direct-bypass inside LLC subsystem。 |
| `read_req_*` | in/out | `valid/ready/accepted=4`、`addr=128`、`total_size=32`、`id=16`、`bypass=4` | 来自 `mem_subsystem_top` 的打包 ReadMasterReq。 |
| `read_resp_*` | out/in | `valid/ready=4`、`data=8192`、`id=16` | 返回 `mem_subsystem_top` 的打包 ReadMasterResp。 |
| `write_req_*` | in/out | `valid/ready/accepted=2`、`addr=64`、`wdata=1024`、`wstrb=128`、`total_size=16`、`id=8`、`bypass=2` | 来自 `mem_subsystem_top` 的打包 WriteMasterReq。 |
| `write_resp_*` | out/in | `valid/ready=2`、`id=8`、`code=4` | 返回 `mem_subsystem_top` 的打包 WriteMasterResp。 |

外部 AXI master 端口：

| 端口 | default 宽度 | 作用 |
| --- | --- | --- |
| `ddr_axi_*` | DDR AXI `ID=6`、`ADDR=32`、`DATA=256`、`STRB=32` | DDR/SDRAM AXI4 master。 |
| `mmio_axi_*` | MMIO AXI `ID=6`、`ADDR=32`、`DATA=32`、`STRB=4` | peripheral/MMIO AXI4 master。 |

wrapper 当前把 CPU 侧响应和外部 AXI 请求都保持为空闲。真实子系统接入后，
DDR 通道使用 incrementing burst，MMIO 通道使用 fixed-address burst。
