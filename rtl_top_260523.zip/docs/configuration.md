# RTL 配置说明

当前 `rtl_top` 只保留两种配置口径：

- `default`：匹配 `3e13836/simulator/include/config.h.default` 的 CPU/cache/AXI/LLC 空壳参数。
- `fpga_kb_llc`：在 `default` 基础上只缩小 LLC 几何参数，CPU、frontend、backend、ICache、DCache、TLB 规模保持不变；该配置目前只用于后续 FPGA 资源受限验证的空壳参数预留。

配置入口仍是 `src/include/qm3_cpu_params.vh` 和
`src/include/axi_llc_params.vh`，但不再通过 `src/include/config/*.vh` 递归
include 选择 default/small/medium/large。`qm3_cpu_params.vh` 固定描述
3e13836 default CPU 规模；LLC 的 FPGA 小容量变体通过 `cpu_top` /
`axi_subsystem_top` 的 `FPGA_KB_LLC` parameter 选择，避免仿真或综合时因为
多层 include 顺序产生隐式配置漂移。

示例：

```sh
files=$(grep -v '^+' filelist/rtl.f | sed '/^$/d' | tr '\n' ' ')

# 3e13836 default
yosys -p "read_verilog -sv -I src/include $files; hierarchy -check -top cpu_top"

# default CPU + 64 KiB shell-only LLC
yosys -p "read_verilog -sv -I src/include $files; chparam -set FPGA_KB_LLC 1 cpu_top; hierarchy -check -top cpu_top"
```

## CPU/default 参数

| 参数 | 3e13836 default |
| --- | ---: |
| `QM3_FETCH_WIDTH` | 16 |
| `QM3_DECODE_WIDTH` | 8 |
| `QM3_COMMIT_WIDTH` | 8 |
| `QM3_ISSUE_WIDTH` | 24 |
| `QM3_ALU_NUM` | 8 |
| `QM3_BRU_NUM` | 4 |
| `QM3_ROB_NUM` | 512 |
| `QM3_IDU_INST_BUFFER_SIZE` | 1024 |
| `QM3_FTQ_SIZE` | 512 |
| `QM3_LDQ_SIZE` | 512 |
| `QM3_STQ_SIZE` | 512 |
| `QM3_LSU_LDU_COUNT` | 4 |
| `QM3_LSU_STA_COUNT` | 4 |
| `QM3_LSU_SDU_COUNT` | 4 |
| `QM3_LSU_LDU_WIDTH` | 2 |
| `QM3_LOAD_WINDOWS_WIDTH` | 20 |
| `QM3_STORE_WINDOWS_WIDTH` | 20 |
| `QM3_ITLB_ENTRIES` | 64 |
| `QM3_DTLB_ENTRIES` | 64 |
| `QM3_ICACHE_LINE_BYTES` | 64 |
| `QM3_ICACHE_SET_COUNT` | 64 |
| `QM3_ICACHE_WAY_COUNT` | 8 |
| `QM3_DCACHE_LINE_BYTES` | 64 |
| `QM3_DCACHE_SET_COUNT` | 256 |
| `QM3_DCACHE_WAY_COUNT` | 4 |
| `QM3_DCACHE_MSHR_ENTRIES` | 8 |
| `QM3_DCACHE_WB_ENTRIES` | 8 |

## AXI/LLC 参数

| 参数 | `default` | `fpga_kb_llc` |
| --- | ---: | ---: |
| `FPGA_KB_LLC` | 0 | 1 |
| `AXI_SUBSYSTEM_FREQ_DIV` | 16 | 16 |
| `AXI_LLC_LLC_SIZE_BYTES` | 4194304 | 65536 |
| `AXI_LLC_LINE_BYTES` | 64 | 64 |
| `AXI_LLC_SET_COUNT` | 4096 | 256 |
| `AXI_LLC_SET_BITS` | 12 | 8 |
| `AXI_LLC_WAY_COUNT` | 16 | 4 |
| `AXI_LLC_WAY_BITS` | 4 | 2 |
| `AXI_LLC_WINDOW_BYTES` | 4194304 | 65536 |
| `AXI_LLC_WINDOW_WAYS` | 16 | 4 |
| `AXI_LLC_READ_RESP_BYTES` | 256 | 256 |
| `AXI_LLC_AXI_DATA_BYTES` | 32 | 32 |
| `AXI_LLC_AXI_ID_BITS` | 6 | 6 |
| `QM3_NUM_READ_MASTERS` | 4 | 4 |
| `QM3_NUM_WRITE_MASTERS` | 2 | 2 |

注意：3e13836 C++ AXI interconnect 中 mode=2 的 mapped-window 大小当前是
固定 4 MiB。`fpga_kb_llc` 是 RTL 空壳预留配置，后续真正接入
`axi_llc_subsystem_dual` 时，需要同步确认小 LLC 配置下 mapped-window 是否也
参数化缩小。

## 时钟配置

`cpu_top` 现在显式暴露两个时钟：

| 信号 | 时钟域 | 说明 |
| --- | --- | --- |
| `aclk` | 高频 AXI/LLC/DDR 域 | 驱动 `axi_subsystem_top` 以及外部 DDR/MMIO AXI 相关逻辑。 |
| `cpu_clk` | 低频 CPU core 域 | 驱动 `frontend_top`、`backend_top` 和 `mem_subsystem_top`。 |

3e13836 simulator default 的分频比例对应
`CONFIG_AXI_SUBSYSTEM_FREQ_DIV=16u`，RTL 参数为 `AXI_SUBSYSTEM_FREQ_DIV=16`，即
`aclk:cpu_clk = 16:1`。因为两个时钟是整数倍相关时钟，后续真实
`axi_llc_subsystem_dual` 接入时，mem subsystem 与 AXI/LLC 之间的
valid/ready 握手应以 `cpu_clk` 边界为准进行保持和采样，不需要按异步 CDC
接口处理。

建议 SoC/FPGA 顶层从外部 PLL/MMCM/clock wizard 同源生成并输入这两个时钟，
不要在 `cpu_top` 内用普通 RTL 计数器再分频出 `cpu_clk`。这样更容易约束时钟
关系、使用专用 clock buffer，并避免综合后生成普通逻辑时钟带来的时钟树和时序
问题。若后续需要单时钟仿真入口，建议单独增加 simulation wrapper，而不是把
分频器放进 `cpu_top` 正式边界。
