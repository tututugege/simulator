# 3e13836 default 配置接口 bit 精确统计

本文档基于当前 RTL 源码在 3e13836 default 下的端口声明统计：

- `src/frontend_top.v`
- `src/backend_top.v`
- `src/mem_subsystem_top.v`
- `src/axi_subsystem_top.v`

这四个大 top 内部已经拆出 interface-only 子空壳。子空壳端口用于下一步训练/
替换具体模块 RTL，不改变本文档统计的四个大 top 对外端口位宽。功能性端口按
对应 C++ Input/Output struct 顺序排列；perf/debug 字段不纳入训练边界端口。
`LoadReq`/`StoreReq` 在 3e13836 的 `!BSD_CONFIG` 路径下带有 perf 归因用
`replay` 输入字段，当前 RTL 空壳未把该非功能字段纳入端口统计。

统计只考虑模块接口上的端口，不把 `cpu_top` 内部胶水逻辑带来的改宽、广播、
合并和扇出当作子模块端口的一部分。存在胶水改宽的位置会分别列出源模块侧和
目的模块侧的端口位宽。

## 文档完整性检查

`docs/top_interfaces_default.md` 已经覆盖四个子模块的所有功能性信号组，但它
是分组级说明，并不是逐信号 bit 精确清单。本文档逐个列出四个子模块的全部端
口，并补充每个信号的功能说明。

| 模块 | 端口数 | 输入 bits | 输出 bits | 本文档覆盖情况 |
| --- | ---: | ---: | ---: | --- |
| `frontend_top` | 90 | 5045 | 5607 | 全部端口已覆盖 |
| `backend_top` | 98 | 6427 | 3741 | 全部端口已覆盖；CSR 输出同时扇出到 frontend 和 mem subsystem |
| `mem_subsystem_top` | 110 | 9454 | 4188 | 全部端口已覆盖 |
| `axi_subsystem_top` | 87 | 1771 | 8794 | 全部端口已覆盖 |

四个子模块之间当前只有以下连接关系：

| 连接 | 源模块侧端口 | bits | 目的模块侧端口 | bits | 备注 |
| --- | ---: | ---: | ---: | ---: | --- |
| `frontend_top -> backend_top` | 22 | 5394 | 21 | 5873 | `cpu_top` 会生成 `front2pre_valid`，并把 32-bit next PC 广播成 512-bit |
| `backend_top -> frontend_top` | 32 | 2856 | 29 | 2838 | `cpu_top` 会合并 redirect/FIFO 控制 |
| `frontend_top -> mem_subsystem_top` | 17 | 213 | 17 | 213 | 端口名和位宽一致 |
| `mem_subsystem_top -> frontend_top` | 18 | 2202 | 18 | 2202 | 端口名和位宽一致 |
| `backend_top -> mem_subsystem_top` | 27 | 983 | 27 | 983 | 端口名和位宽一致 |
| `mem_subsystem_top -> backend_top` | 20 | 552 | 20 | 552 | 端口名和位宽一致 |
| `mem_subsystem_top -> axi_subsystem_top` | 14 | 1434 | 14 | 1434 | 端口名和位宽一致 |
| `axi_subsystem_top -> mem_subsystem_top` | 11 | 8254 | 11 | 8254 | 端口名和位宽一致 |

四个子模块和 `cpu_top` 外部/本地顶层边界的连接如下。这里按子模块端口统计，
所以 `cpu_clk/aclk/aresetn` 的扇出会在多个模块中重复计算。

| 连接 | 信号数 | bits | 说明 |
| --- | ---: | ---: | --- |
| `rtl_top -> frontend_top` | 4 | 5 | `frontend_top.aclk(cpu_clk)/aresetn/reset/mode`，其中 `reset` 来自 `cpu_top` 内部生成的 `global_reset` |
| `frontend_top -> rtl_top` | 0 | 0 | 当前无 frontend 直连 `cpu_top` 外部边界的输出 |
| `rtl_top -> backend_top` | 2 | 2 | `backend_top.aclk(cpu_clk)/aresetn` |
| `backend_top -> rtl_top` | 0 | 0 | 当前无 backend 直连 `cpu_top` 外部边界的输出 |
| `rtl_top -> mem_subsystem_top` | 3 | 4 | `mem_subsystem_top.clk(cpu_clk)/rst_n/mode` |
| `mem_subsystem_top -> rtl_top` | 0 | 0 | 当前无 mem subsystem 直连 `cpu_top` 外部边界的输出 |
| `rtl_top -> axi_subsystem_top` | 26 | 337 | `clk(aclk)`、`cpu_clk`、复位、`mode`，以及 DDR/MMIO AXI slave 侧返回/反压信号 |
| `axi_subsystem_top -> rtl_top` | 36 | 540 | DDR/MMIO AXI master 侧请求/数据/响应接收信号 |

`cpu_top` 还有若干不属于四个子模块端口的顶层信号：`ext_int` 输入 6 bits 当前
尚未接入子模块；`aclk` 输入 1 bit 作为 AXI/LLC/DDR 高频时钟，`cpu_clk` 输入
1 bit 作为 frontend/backend/mem subsystem 低频时钟；`mode` 输入 2 bits 扇出到
frontend/mem subsystem/AXI subsystem；`global_reset` 输出 1 bit 由
`~aresetn` 生成；DDR/MMIO 的
`awlock/awcache/awprot/arlock/arcache/arprot` 共 32 bits 目前在 `cpu_top`
固定 tie-off，不经过 `axi_subsystem_top`。

当前 default 分频比例对应 simulator 的
`CONFIG_AXI_SUBSYSTEM_FREQ_DIV=16u`，RTL 参数为 `AXI_SUBSYSTEM_FREQ_DIV=16`，
即 `aclk:cpu_clk = 16:1`。
mem subsystem 与 AXI/LLC 之间的 request/response 端口本身仍按各自端口位宽
统计；后续真实 AXI/LLC 实现需要在 `axi_subsystem_top` 内按 `cpu_clk` 边界
保持和采样这些 CPU 侧握手。

## 64B cacheline 下的位宽浪费记录

当前文档的 bit 统计严格反映 RTL 端口声明，因此保留了
simulator/axi-interconnect-kit 的既有接口形状。对于 3e13836 default
中的 64B cacheline 配置，这些接口是可用的，但存在以下可后续优化的位宽浪费：

| 位置 | 信号 | 当前 bits | 64B cacheline 有效 bits | 当前处理方式 | 后续优化方向 |
| --- | --- | ---: | ---: | --- | --- |
| `axi_subsystem_top -> mem_subsystem_top` | `read_resp_data` 单个 read master slot | 2048 | 512 | simulator 中为 `WideReadData_t.words[64]`；当前 cacheline refill 只使用低 16 个 32-bit word。 | 将 `READ_RESP_BYTES` 从 256B 收敛到 64B。 |
| `axi_subsystem_top -> mem_subsystem_top` | `read_resp_data` 全部 4 个 read master slot | 8192 | 2048 | RTL 把 4 个 read master 的 2048-bit response slot 展平；未被有效 response 使用的 slot/高位 word 空闲。 | 与 AXI submodule 一起参数化为 4 x 512 bits。 |
| `mem_subsystem_top -> frontend_top` | `icache_llc_read_resp_data` | 2048 | 512 | ICache refill 只消耗一个 64B line；高 1536 bits 不承载当前 cacheline 数据。 | 与 `read_resp_data` 裁剪保持一致。 |
| `mem_subsystem_top -> axi_subsystem_top` | `write_req_wdata` 单个 write master slot | 512 | 512 | 单个 write payload 已经等于 64B cacheline。 | 暂无单 slot 裁剪空间。 |
| `mem_subsystem_top -> axi_subsystem_top` | `write_req_wdata` 全部 2 个 write master slot | 1024 | 512/slot | 总线宽度来自 2 个 write master slot 展平，不是单次写请求超过 cacheline。 | 只有在减少 write master 数量或改成非展平结构时才会变窄。 |

保持现状时，实际语义不是在当前 64B cacheline 路径上截断有效数据，而是“按最大
载体宽度传递，低位 word 按请求大小有效，高位 word 空闲/未使用”。如果后续裁
剪 read response 宽度，需要同时修改 `axi_llc_subsystem_dual` 及 wrapper 参
数，并在 mem subsystem/AXI 边界保证所有 read 请求的 `total_size` 不超过
`LINE_BYTES - 1`。

## `frontend_top -> backend_top`

frontend 源端口：

| 信号 | bits | 功能 |
| --- | ---: | --- |
| `FIFO_valid` | 1 | frontend fetch FIFO 中存在可发送的取指包。 |
| `commit_stall` | 1 | frontend 侧提交/队列 stall 状态，送入 backend 的 `front2pre_front_stall`。 |
| `pc` | 512 | `FETCH_WIDTH` 条取指 slot 的 PC。 |
| `instructions` | 512 | `FETCH_WIDTH` 条取指 slot 的指令数据。 |
| `inst_valid` | 16 | 每个取指 slot 的有效位，参与 `cpu_top` 内部 `front2pre_valid` 生成。 |
| `out_predict_dir` | 16 | 每个取指 slot 的分支方向预测。 |
| `predict_next_fetch_address` | 32 | frontend 给出的下一次取指地址；在 `cpu_top` 内广播给 backend。 |
| `out_alt_pred` | 16 | 每个取指 slot 的 alternate provider 预测结果。 |
| `out_altpcpn` | 48 | 每个取指 slot 的 alternate provider 编号。 |
| `out_pcpn` | 48 | 每个取指 slot 的主 provider 编号。 |
| `page_fault_inst` | 16 | 每个取指 slot 的取指页异常标记。 |
| `out_tage_idx` | 768 | 每个取指 slot 携带的 TAGE 表索引元数据。 |
| `out_tage_tag` | 512 | 每个取指 slot 携带的 TAGE tag 元数据。 |
| `out_sc_used` | 16 | 每个取指 slot 是否使用 statistical corrector。 |
| `out_sc_pred` | 16 | 每个取指 slot 的 statistical corrector 预测结果。 |
| `out_sc_sum` | 256 | 每个取指 slot 的 statistical corrector sum 元数据。 |
| `out_sc_idx` | 2048 | 每个取指 slot 的 statistical corrector 表索引元数据。 |
| `out_loop_used` | 16 | 每个取指 slot 是否使用 loop predictor。 |
| `out_loop_hit` | 16 | 每个取指 slot 的 loop predictor 命中标记。 |
| `out_loop_pred` | 16 | 每个取指 slot 的 loop predictor 预测方向。 |
| `out_loop_idx` | 256 | 每个取指 slot 的 loop predictor 索引元数据。 |
| `out_loop_tag` | 256 | 每个取指 slot 的 loop predictor tag 元数据。 |
| **合计** | **5394** |  |

backend 目的端口：

| 信号 | bits | 功能 |
| --- | ---: | --- |
| `front2pre_inst` | 512 | backend 接收的取指指令向量。 |
| `front2pre_pc` | 512 | backend 接收的取指 PC 向量。 |
| `front2pre_valid` | 16 | backend 接收的每 slot 有效位，由 `cpu_top` 基于 frontend FIFO/valid/predict 生成。 |
| `front2pre_front_stall` | 1 | backend 接收的 frontend stall 状态。 |
| `front2pre_predict_dir` | 16 | backend 接收的分支方向预测。 |
| `front2pre_alt_pred` | 16 | backend 接收的 alternate provider 预测结果。 |
| `front2pre_altpcpn` | 48 | backend 接收的 alternate provider 编号。 |
| `front2pre_pcpn` | 48 | backend 接收的主 provider 编号。 |
| `front2pre_predict_next_fetch_address` | 512 | backend 每个取指 slot 对应的 next-fetch PC；由 32-bit frontend 输出广播得到。 |
| `front2pre_tage_idx` | 768 | backend 接收的 TAGE 表索引元数据。 |
| `front2pre_tage_tag` | 512 | backend 接收的 TAGE tag 元数据。 |
| `front2pre_sc_used` | 16 | backend 接收的 statistical corrector 使用标记。 |
| `front2pre_sc_pred` | 16 | backend 接收的 statistical corrector 预测结果。 |
| `front2pre_sc_sum` | 256 | backend 接收的 statistical corrector sum 元数据。 |
| `front2pre_sc_idx` | 2048 | backend 接收的 statistical corrector 表索引元数据。 |
| `front2pre_loop_used` | 16 | backend 接收的 loop predictor 使用标记。 |
| `front2pre_loop_hit` | 16 | backend 接收的 loop predictor 命中标记。 |
| `front2pre_loop_pred` | 16 | backend 接收的 loop predictor 预测方向。 |
| `front2pre_loop_idx` | 256 | backend 接收的 loop predictor 索引元数据。 |
| `front2pre_loop_tag` | 256 | backend 接收的 loop predictor tag 元数据。 |
| `front2pre_page_fault_inst` | 16 | backend 接收的取指页异常标记。 |
| **合计** | **5873** |  |

## `backend_top -> frontend_top`

backend 源端口：

| 信号 | bits | 功能 |
| --- | ---: | --- |
| `pre2front_fire` | 16 | backend 对 frontend fetch FIFO 各 slot 的消费标记。 |
| `pre2front_ready` | 1 | backend 是否准备好继续接收 frontend 数据。 |
| `mispred` | 1 | backend 检测到分支误预测。 |
| `stall` | 1 | backend stall，参与 `cpu_top` 内部 FIFO 读取控制。 |
| `flush` | 1 | backend flush 请求，参与 frontend refetch 控制。 |
| `fence_i` | 1 | backend 发出的 `fence.i` 控制。 |
| `itlb_flush` | 1 | backend 发出的 ITLB flush 控制。 |
| `redirect_pc` | 32 | backend 重定向 PC。 |
| `back2front_valid` | 8 | commit 阶段每条训练项是否有效。 |
| `predict_base_pc` | 256 | commit 阶段 BPU 训练的预测基准 PC。 |
| `predict_dir` | 8 | commit 阶段记录的预测方向。 |
| `actual_dir` | 8 | commit 阶段解析出的真实方向。 |
| `actual_br_type` | 24 | commit 阶段解析出的分支类型。 |
| `actual_target` | 256 | commit 阶段解析出的真实跳转目标。 |
| `alt_pred` | 8 | commit 阶段 alternate provider 预测结果。 |
| `altpcpn` | 24 | commit 阶段 alternate provider 编号。 |
| `pcpn` | 24 | commit 阶段主 provider 编号。 |
| `tage_idx` | 384 | commit 阶段 TAGE 表索引元数据。 |
| `tage_tag` | 256 | commit 阶段 TAGE tag 元数据。 |
| `sc_used` | 8 | commit 阶段 statistical corrector 使用标记。 |
| `sc_pred` | 8 | commit 阶段 statistical corrector 预测结果。 |
| `sc_sum` | 128 | commit 阶段 statistical corrector sum 元数据。 |
| `sc_idx` | 1024 | commit 阶段 statistical corrector 表索引元数据。 |
| `loop_used` | 8 | commit 阶段 loop predictor 使用标记。 |
| `loop_hit` | 8 | commit 阶段 loop predictor 命中标记。 |
| `loop_pred` | 8 | commit 阶段 loop predictor 预测方向。 |
| `loop_idx` | 128 | commit 阶段 loop predictor 索引元数据。 |
| `loop_tag` | 128 | commit 阶段 loop predictor tag 元数据。 |
| `csr_status_sstatus` | 32 | backend 当前 `sstatus` CSR 上下文。 |
| `csr_status_mstatus` | 32 | backend 当前 `mstatus` CSR 上下文。 |
| `csr_status_satp` | 32 | backend 当前 `satp` CSR 上下文。 |
| `csr_status_privilege` | 2 | backend 当前特权级。 |
| **合计** | **2856** |  |

frontend 目的端口：

| 信号 | bits | 功能 |
| --- | ---: | --- |
| `refetch` | 1 | frontend 重取指请求，由 `mispred/flush` 合并生成。 |
| `itlb_flush` | 1 | frontend 内部 ITLB flush 控制。 |
| `fence_i` | 1 | frontend 内部 ICache/取指侧 `fence.i` 控制。 |
| `refetch_address` | 32 | frontend 重取指目标 PC。 |
| `csr_status_sstatus` | 32 | frontend ITLB/MMU 使用的 `sstatus`。 |
| `csr_status_mstatus` | 32 | frontend ITLB/MMU 使用的 `mstatus`。 |
| `csr_status_satp` | 32 | frontend ITLB/MMU 使用的 `satp`。 |
| `csr_status_privilege` | 2 | frontend ITLB/MMU 使用的特权级。 |
| `FIFO_read_enable` | 1 | frontend FIFO 读取使能，由 backend stall/redirect 状态合并生成。 |
| `back2front_valid` | 8 | frontend BPU 训练项有效位。 |
| `predict_base_pc` | 256 | frontend BPU 训练的预测基准 PC。 |
| `predict_dir` | 8 | frontend BPU 训练的预测方向。 |
| `actual_dir` | 8 | frontend BPU 训练的真实方向。 |
| `actual_br_type` | 24 | frontend BPU 训练的真实分支类型。 |
| `actual_target` | 256 | frontend BPU 训练的真实跳转目标。 |
| `alt_pred` | 8 | frontend BPU 训练的 alternate provider 预测结果。 |
| `altpcpn` | 24 | frontend BPU 训练的 alternate provider 编号。 |
| `pcpn` | 24 | frontend BPU 训练的主 provider 编号。 |
| `tage_idx` | 384 | frontend BPU 训练的 TAGE 表索引元数据。 |
| `tage_tag` | 256 | frontend BPU 训练的 TAGE tag 元数据。 |
| `sc_used` | 8 | frontend BPU 训练的 statistical corrector 使用标记。 |
| `sc_pred` | 8 | frontend BPU 训练的 statistical corrector 预测结果。 |
| `sc_sum` | 128 | frontend BPU 训练的 statistical corrector sum 元数据。 |
| `sc_idx` | 1024 | frontend BPU 训练的 statistical corrector 表索引元数据。 |
| `loop_used` | 8 | frontend BPU 训练的 loop predictor 使用标记。 |
| `loop_hit` | 8 | frontend BPU 训练的 loop predictor 命中标记。 |
| `loop_pred` | 8 | frontend BPU 训练的 loop predictor 预测方向。 |
| `loop_idx` | 128 | frontend BPU 训练的 loop predictor 索引元数据。 |
| `loop_tag` | 128 | frontend BPU 训练的 loop predictor tag 元数据。 |
| **合计** | **2838** |  |

## `frontend_top <-> mem_subsystem_top`

`frontend_top -> mem_subsystem_top`：

| 信号 | bits | 功能 |
| --- | ---: | --- |
| `icache_llc_read_req_valid` | 1 | ICache miss refill 读请求有效。 |
| `icache_llc_read_req_addr` | 32 | ICache refill 读请求地址。 |
| `icache_llc_read_req_total_size` | 8 | ICache refill 读请求总字节数。 |
| `icache_llc_read_req_id` | 4 | ICache refill 读请求 ID。 |
| `icache_llc_read_req_bypass` | 1 | ICache refill 是否绕过 LLC。 |
| `icache_llc_read_resp_ready` | 1 | ICache 可以接收 refill 读响应。 |
| `icache_dcache_req_valid` | 1 | ICache 发起 DCache coherent word probe。 |
| `icache_dcache_req_addr` | 32 | ICache 查询 DCache 的 word 地址。 |
| `itlb_ptw_mem_req_valid` | 1 | ITLB PTW memory read 请求有效。 |
| `itlb_ptw_mem_req_addr` | 32 | ITLB PTW memory read 请求地址。 |
| `itlb_ptw_mem_resp_consumed` | 1 | ITLB 已消费 PTW memory read 响应。 |
| `itlb_walk_req_valid` | 1 | ITLB page walk 请求有效。 |
| `itlb_walk_req_vaddr` | 32 | ITLB page walk 的虚拟地址。 |
| `itlb_walk_req_satp` | 32 | ITLB page walk 使用的 `satp`。 |
| `itlb_walk_req_access_type` | 32 | ITLB page walk 访问类型。 |
| `itlb_walk_resp_consumed` | 1 | ITLB 已消费 page walk 响应。 |
| `itlb_walk_flush` | 1 | ITLB page walk flush 控制。 |
| **合计** | **213** |  |

`mem_subsystem_top -> frontend_top`：

| 信号 | bits | 功能 |
| --- | ---: | --- |
| `icache_llc_read_req_ready` | 1 | mem subsystem 可接收 ICache refill 读请求。 |
| `icache_llc_read_req_accepted` | 1 | ICache refill 读请求已被 LLC 侧接受。 |
| `icache_llc_read_req_accepted_id` | 4 | 被接受的 ICache refill 读请求 ID。 |
| `icache_llc_read_resp_valid` | 1 | ICache refill 读响应有效。 |
| `icache_llc_read_resp_data` | 2048 | ICache refill 返回数据。 |
| `icache_llc_read_resp_id` | 4 | ICache refill 响应 ID。 |
| `dcache_icache_resp_valid` | 1 | DCache coherent word probe 响应有效。 |
| `dcache_icache_resp_miss` | 1 | DCache probe 未命中标记。 |
| `dcache_icache_resp_data` | 32 | DCache probe 返回的 word 数据。 |
| `itlb_ptw_mem_req_ready` | 1 | PTW memory 端口可接收 ITLB 请求。 |
| `itlb_ptw_mem_resp_valid` | 1 | ITLB PTW memory read 响应有效。 |
| `itlb_ptw_mem_resp_data` | 32 | ITLB PTW memory read 响应数据。 |
| `itlb_walk_req_ready` | 1 | PTW walk 端口可接收 ITLB 请求。 |
| `itlb_walk_resp_valid` | 1 | ITLB page walk 响应有效。 |
| `itlb_walk_resp_fault` | 1 | ITLB page walk 异常标记。 |
| `itlb_walk_resp_vaddr` | 32 | ITLB page walk 响应对应虚拟地址。 |
| `itlb_walk_resp_leaf_pte` | 32 | ITLB page walk 找到的 leaf PTE。 |
| `itlb_walk_resp_leaf_level` | 8 | ITLB page walk leaf 层级。 |
| **合计** | **2202** |  |

## `backend_top <-> mem_subsystem_top`

`backend_top -> mem_subsystem_top`：

| 信号 | bits | 功能 |
| --- | ---: | --- |
| `csr_status_sstatus` | 32 | mem subsystem/PTW 使用的 `sstatus`。 |
| `csr_status_mstatus` | 32 | mem subsystem/PTW 使用的 `mstatus`。 |
| `csr_status_satp` | 32 | mem subsystem/PTW 使用的 `satp`。 |
| `csr_status_privilege` | 2 | mem subsystem/PTW 使用的当前特权级。 |
| `peripheral_req_is_mmio` | 1 | LSU peripheral 请求是否指向 MMIO。 |
| `peripheral_req_wen` | 1 | LSU peripheral 请求是否为写。 |
| `peripheral_req_mmio_addr` | 32 | LSU MMIO 请求地址。 |
| `peripheral_req_mmio_wdata` | 32 | LSU MMIO 写数据。 |
| `peripheral_req_mmio_fun3` | 3 | LSU MMIO 访问 size/类型编码。 |
| `dtlb_ptw_mem_req_valid` | 1 | DTLB PTW memory read 请求有效。 |
| `dtlb_ptw_mem_req_addr` | 32 | DTLB PTW memory read 请求地址。 |
| `dtlb_ptw_mem_resp_consumed` | 1 | DTLB 已消费 PTW memory read 响应。 |
| `dtlb_walk_req_valid` | 1 | DTLB page walk 请求有效。 |
| `dtlb_walk_req_vaddr` | 32 | DTLB page walk 的虚拟地址。 |
| `dtlb_walk_req_satp` | 32 | DTLB page walk 使用的 `satp`。 |
| `dtlb_walk_req_access_type` | 32 | DTLB page walk 访问类型。 |
| `dtlb_walk_resp_consumed` | 1 | DTLB 已消费 page walk 响应。 |
| `dtlb_walk_flush` | 1 | DTLB page walk flush 控制。 |
| `lsu2dcache_load_ports_valid` | 4 | LSU load 端口请求有效位。 |
| `lsu2dcache_load_ports_addr` | 128 | LSU load 端口地址向量。 |
| `lsu2dcache_load_ports_req_id` | 128 | LSU load 端口请求 ID 向量。 |
| `lsu2dcache_store_ports_valid` | 4 | LSU store 端口请求有效位。 |
| `lsu2dcache_store_ports_addr` | 128 | LSU store 端口地址向量。 |
| `lsu2dcache_store_ports_data` | 128 | LSU store 端口写数据向量。 |
| `lsu2dcache_store_ports_strb` | 32 | LSU store 端口写 strobe 向量。 |
| `lsu2dcache_store_ports_req_id` | 128 | LSU store 端口请求 ID 向量。 |
| `lsu2dcache_icache_req` | 3 | 被 ICache probe 借用的 DCache load port 编号；空闲值为 `LSU_LDU_COUNT`。 |
| **合计** | **983** |  |

`mem_subsystem_top -> backend_top`：

| 信号 | bits | 功能 |
| --- | ---: | --- |
| `peripheral_resp_is_mmio` | 1 | peripheral/MMIO 响应是否来自 MMIO 路径。 |
| `peripheral_resp_ready` | 1 | peripheral/MMIO 响应 ready/有效状态。 |
| `peripheral_resp_mmio_rdata` | 32 | MMIO 读响应数据。 |
| `dtlb_ptw_mem_req_ready` | 1 | PTW memory 端口可接收 DTLB 请求。 |
| `dtlb_ptw_mem_resp_valid` | 1 | DTLB PTW memory read 响应有效。 |
| `dtlb_ptw_mem_resp_data` | 32 | DTLB PTW memory read 响应数据。 |
| `dtlb_walk_req_ready` | 1 | PTW walk 端口可接收 DTLB 请求。 |
| `dtlb_walk_resp_valid` | 1 | DTLB page walk 响应有效。 |
| `dtlb_walk_resp_fault` | 1 | DTLB page walk 异常标记。 |
| `dtlb_walk_resp_vaddr` | 32 | DTLB page walk 响应对应虚拟地址。 |
| `dtlb_walk_resp_leaf_pte` | 32 | DTLB page walk 找到的 leaf PTE。 |
| `dtlb_walk_resp_leaf_level` | 8 | DTLB page walk leaf 层级。 |
| `dcache2lsu_load_resps_valid` | 4 | DCache load 响应有效位。 |
| `dcache2lsu_load_resps_data` | 128 | DCache load 响应数据向量。 |
| `dcache2lsu_load_resps_req_id` | 128 | DCache load 响应请求 ID 向量。 |
| `dcache2lsu_load_resps_replay` | 8 | DCache load replay 编码向量。 |
| `dcache2lsu_store_resps_valid` | 4 | DCache store 响应有效位。 |
| `dcache2lsu_store_resps_replay` | 8 | DCache store replay 编码向量。 |
| `dcache2lsu_store_resps_req_id` | 128 | DCache store 响应请求 ID 向量。 |
| `dcache2lsu_mshr_fill` | 1 | DCache MSHR fill 事件通知。 |
| **合计** | **552** |  |

## `mem_subsystem_top <-> axi_subsystem_top`

`mem_subsystem_top -> axi_subsystem_top`：

| 信号 | bits | 功能 |
| --- | ---: | --- |
| `read_req_valid` | 4 | axi-interconnect-kit read master 请求有效位。 |
| `read_req_addr` | 128 | read master 请求地址向量。 |
| `read_req_total_size` | 32 | read master 请求总字节数向量。 |
| `read_req_id` | 16 | read master 请求 ID 向量。 |
| `read_req_bypass` | 4 | read master 是否绕过 LLC 的标记。 |
| `read_resp_ready` | 4 | mem subsystem 可接收 read master 响应。 |
| `write_req_valid` | 2 | write master 请求有效位。 |
| `write_req_addr` | 64 | write master 请求地址向量。 |
| `write_req_wdata` | 1024 | write master 写数据向量。 |
| `write_req_wstrb` | 128 | write master 写 strobe 向量。 |
| `write_req_total_size` | 16 | write master 请求总字节数向量。 |
| `write_req_id` | 8 | write master 请求 ID 向量。 |
| `write_req_bypass` | 2 | write master 是否绕过 LLC 的标记。 |
| `write_resp_ready` | 2 | mem subsystem 可接收 write master 响应。 |
| **合计** | **1434** |  |

`axi_subsystem_top -> mem_subsystem_top`：

| 信号 | bits | 功能 |
| --- | ---: | --- |
| `read_req_ready` | 4 | AXI/LLC 子系统可接收 read master 请求。 |
| `read_req_accepted` | 4 | read master 请求已被 AXI/LLC 子系统接受。 |
| `read_req_accepted_id` | 16 | 被接受的 read master 请求 ID 向量。 |
| `read_resp_valid` | 4 | read master 响应有效位。 |
| `read_resp_data` | 8192 | read master 响应数据向量。 |
| `read_resp_id` | 16 | read master 响应 ID 向量。 |
| `write_req_ready` | 2 | AXI/LLC 子系统可接收 write master 请求。 |
| `write_req_accepted` | 2 | write master 请求已被 AXI/LLC 子系统接受。 |
| `write_resp_valid` | 2 | write master 响应有效位。 |
| `write_resp_id` | 8 | write master 响应 ID 向量。 |
| `write_resp_code` | 4 | write master 响应 code 向量。 |
| **合计** | **8254** |  |

## 四个子模块与 `rtl_top`

`rtl_top -> frontend_top`：

| 信号 | bits | 功能 |
| --- | ---: | --- |
| `aclk` | 1 | frontend 低频时钟端口，当前由 `cpu_top.cpu_clk` 驱动。 |
| `aresetn` | 1 | 低有效复位。 |
| `reset` | 1 | frontend 高有效复位，由 `cpu_top` 内部 `global_reset` 连接。 |
| `mode` | 2 | AXI/LLC 模式上下文；当前空壳不据此改写 ICache refill bypass，后续 ICache 本地 bypass 由 mapped-window 地址模式决定。 |
| **合计** | **5** |  |

`rtl_top -> backend_top`：

| 信号 | bits | 功能 |
| --- | ---: | --- |
| `aclk` | 1 | backend 低频时钟端口，当前由 `cpu_top.cpu_clk` 驱动。 |
| `aresetn` | 1 | 低有效复位。 |
| **合计** | **2** |  |

`rtl_top -> mem_subsystem_top`：

| 信号 | bits | 功能 |
| --- | ---: | --- |
| `clk` | 1 | mem subsystem 低频时钟，当前连接 `cpu_top.cpu_clk`。 |
| `rst_n` | 1 | mem subsystem 低有效复位，当前连接 `cpu_top.aresetn`。 |
| `mode` | 2 | AXI/LLC 模式上下文；LLC_OFF 不在这里强制改写 ICache/DCache 请求，后续 DCache 本地 bypass 由 mapped-window 地址模式决定。 |
| **合计** | **4** |  |

`rtl_top -> axi_subsystem_top`：

| 信号 | bits | 功能 |
| --- | ---: | --- |
| `clk` | 1 | AXI/LLC 高频时钟，当前连接 `cpu_top.aclk`。 |
| `cpu_clk` | 1 | CPU/mem subsystem 低频握手时钟，用于后续真实 AXI/LLC wrapper 按低频边界采样 CPU 侧请求/响应。 |
| `rst_n` | 1 | AXI/LLC 子系统低有效复位，当前连接 `cpu_top.aresetn`。 |
| `mode` | 2 | 传给后续 `axi_llc_subsystem_dual` 的模式请求；LLC_OFF/direct-bypass 在 AXI/LLC 子系统内部处理。 |
| `ddr_axi_awready` | 1 | DDR AXI 写地址通道 ready。 |
| `ddr_axi_wready` | 1 | DDR AXI 写数据通道 ready。 |
| `ddr_axi_bvalid` | 1 | DDR AXI 写响应通道 valid。 |
| `ddr_axi_bid` | 6 | DDR AXI 写响应 ID。 |
| `ddr_axi_bresp` | 2 | DDR AXI 写响应编码。 |
| `ddr_axi_arready` | 1 | DDR AXI 读地址通道 ready。 |
| `ddr_axi_rvalid` | 1 | DDR AXI 读数据通道 valid。 |
| `ddr_axi_rid` | 6 | DDR AXI 读响应 ID。 |
| `ddr_axi_rdata` | 256 | DDR AXI 读数据。 |
| `ddr_axi_rresp` | 2 | DDR AXI 读响应编码。 |
| `ddr_axi_rlast` | 1 | DDR AXI 读 burst 最后一拍标记。 |
| `mmio_axi_awready` | 1 | MMIO AXI 写地址通道 ready。 |
| `mmio_axi_wready` | 1 | MMIO AXI 写数据通道 ready。 |
| `mmio_axi_bvalid` | 1 | MMIO AXI 写响应通道 valid。 |
| `mmio_axi_bid` | 6 | MMIO AXI 写响应 ID。 |
| `mmio_axi_bresp` | 2 | MMIO AXI 写响应编码。 |
| `mmio_axi_arready` | 1 | MMIO AXI 读地址通道 ready。 |
| `mmio_axi_rvalid` | 1 | MMIO AXI 读数据通道 valid。 |
| `mmio_axi_rid` | 6 | MMIO AXI 读响应 ID。 |
| `mmio_axi_rdata` | 32 | MMIO AXI 读数据。 |
| `mmio_axi_rresp` | 2 | MMIO AXI 读响应编码。 |
| `mmio_axi_rlast` | 1 | MMIO AXI 读 burst 最后一拍标记。 |
| **合计** | **337** |  |

`axi_subsystem_top -> rtl_top`：

| 信号 | bits | 功能 |
| --- | ---: | --- |
| `ddr_axi_awvalid` | 1 | DDR AXI 写地址通道 valid。 |
| `ddr_axi_awid` | 6 | DDR AXI 写地址 ID。 |
| `ddr_axi_awaddr` | 32 | DDR AXI 写地址。 |
| `ddr_axi_awlen` | 8 | DDR AXI 写 burst 长度。 |
| `ddr_axi_awsize` | 3 | DDR AXI 写 beat 大小。 |
| `ddr_axi_awburst` | 2 | DDR AXI 写 burst 类型，当前 wrapper 固定为 INCR。 |
| `ddr_axi_wvalid` | 1 | DDR AXI 写数据通道 valid。 |
| `ddr_axi_wdata` | 256 | DDR AXI 写数据。 |
| `ddr_axi_wstrb` | 32 | DDR AXI 写 strobe。 |
| `ddr_axi_wlast` | 1 | DDR AXI 写 burst 最后一拍标记。 |
| `ddr_axi_bready` | 1 | DDR AXI 写响应通道 ready。 |
| `ddr_axi_arvalid` | 1 | DDR AXI 读地址通道 valid。 |
| `ddr_axi_arid` | 6 | DDR AXI 读地址 ID。 |
| `ddr_axi_araddr` | 32 | DDR AXI 读地址。 |
| `ddr_axi_arlen` | 8 | DDR AXI 读 burst 长度。 |
| `ddr_axi_arsize` | 3 | DDR AXI 读 beat 大小。 |
| `ddr_axi_arburst` | 2 | DDR AXI 读 burst 类型，当前 wrapper 固定为 INCR。 |
| `ddr_axi_rready` | 1 | DDR AXI 读数据通道 ready。 |
| `mmio_axi_awvalid` | 1 | MMIO AXI 写地址通道 valid。 |
| `mmio_axi_awid` | 6 | MMIO AXI 写地址 ID。 |
| `mmio_axi_awaddr` | 32 | MMIO AXI 写地址。 |
| `mmio_axi_awlen` | 8 | MMIO AXI 写 burst 长度。 |
| `mmio_axi_awsize` | 3 | MMIO AXI 写 beat 大小。 |
| `mmio_axi_awburst` | 2 | MMIO AXI 写 burst 类型，当前 wrapper 固定为 FIXED。 |
| `mmio_axi_wvalid` | 1 | MMIO AXI 写数据通道 valid。 |
| `mmio_axi_wdata` | 32 | MMIO AXI 写数据。 |
| `mmio_axi_wstrb` | 4 | MMIO AXI 写 strobe。 |
| `mmio_axi_wlast` | 1 | MMIO AXI 写 burst 最后一拍标记。 |
| `mmio_axi_bready` | 1 | MMIO AXI 写响应通道 ready。 |
| `mmio_axi_arvalid` | 1 | MMIO AXI 读地址通道 valid。 |
| `mmio_axi_arid` | 6 | MMIO AXI 读地址 ID。 |
| `mmio_axi_araddr` | 32 | MMIO AXI 读地址。 |
| `mmio_axi_arlen` | 8 | MMIO AXI 读 burst 长度。 |
| `mmio_axi_arsize` | 3 | MMIO AXI 读 beat 大小。 |
| `mmio_axi_arburst` | 2 | MMIO AXI 读 burst 类型，当前 wrapper 固定为 FIXED。 |
| `mmio_axi_rready` | 1 | MMIO AXI 读数据通道 ready。 |
| **合计** | **540** |  |
